export const exerciseImg =
  'https://dev.homebodylivefitness.com/storage/uploads/images/SUejgFoq80.png';

export const SOCIAL_LOGIN_TYPE = {
  FB: 'facebook',
  APPLE: 'apple',
  LINKDIN: 'linkedin',
};

export const AGORA_APP_ID = 'c3b931abbab0454a9efb9098f09326bd';
export const STRIPE_KEY =
  'pk_test_51HQGxKEcsMsf5BEKrN9Cw3l758Sj0YfXyH9RWb3qM3iVwPgPxl0iVeZiRRqcEGDijJi24ujmvEIKp6YFrLvCVkkm00fXBM0wUi';
