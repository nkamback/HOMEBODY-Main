import {
    LoginButton,
    AccessToken,
    LoginManager,
    GraphRequest,
    GraphRequestManager,
  } from 'react-native-fbsdk';

 export const  fbLogin = (resCallback) => {
    LoginManager.logInWithPermissions(['email', 'public_profile']).then(
      result => {
        // console.log(result, 'hte result of login i get are as follow');
        if (result.isCancelled) {
          // resCallback({error:})
        } else {
          const infoRequest = new GraphRequest(
            '/me?fields=email,name,picture,friends',
            null,
            resCallback,
          );
          new GraphRequestManager().addRequest(infoRequest).start();
        }
      },
      function(error) {
        // console.log('Login fail with error: ' + error);
      },
    );
  };

