import React from 'react';
import {StyleSheet, View, Image, Text} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {Login, Favourites, Explore, Home, Profile} from '../Screens';
import imagePath from '../constants/imagePath';
import colors from '../styles/colors';
import commonStyles from '../styles/commonStyles';
import fontFamily from '../styles/fontFamily';
import {textScale} from '../styles/responsiveSize';

const Tab = createBottomTabNavigator();

const TabRoutes = ({barColor = '#F6F7EB'}) => {
  const insets = useSafeAreaInsets();
  return (
    <Tab.Navigator
      tabBarOptions={{
        activeTintColor: colors.tabBlue,
        inactiveTintColor: colors.tabGrey,
        labelStyle: {
          textTransform: 'capitalize',
          fontFamily: fontFamily.regular,
          fontSize: textScale(14),
        },
        // showLabel: false,
      }}>
      <Tab.Screen
        name="home"
        options={{
          tabBarIcon: ({focused}) => {
            return (
              <Image
                source={imagePath.homebt}
                style={{tintColor: focused ? colors.tabBlue : colors.tabGrey}}
              />
            );
          },
        }}
        component={Home}
      />
      <Tab.Screen
        name="explore"
        component={Explore}
        options={{
          tabBarIcon: ({focused}) => {
            return (
              <Image
              source={imagePath.explorebt}
              style={{tintColor: focused ? colors.tabBlue : colors.tabGrey}}
            />
          );
          },
        }}
      />
      <Tab.Screen
        name="fav"
        component={Favourites}
        options={{
          tabBarIcon: ({focused}) => {
            return (
              <Image
                source={imagePath.heartbt}
                style={{tintColor: focused ? colors.tabBlue : colors.tabGrey}}
              />
            );
          },
          tabBarLabel: ({focused}) => {
            return (
              <Text
                style={{
                  ...commonStyles.fontSize14,
                  color: focused ? colors.tabBlue : colors.tabGrey,
                  
                }}>
                Favorite
              </Text>
            );
          },
        }}
      />
      <Tab.Screen
        name="profile"
        component={Profile}
        options={{
          tabBarIcon: ({focused}) => {
            return (
              <Image
              source={imagePath.profilebt}
              style={{tintColor: focused ? colors.tabBlue : colors.tabGrey}}
            />
            );
          },
        }}
      />
    </Tab.Navigator>
  );
};

export default TabRoutes;
