import * as React from 'react';
//import NavigationService from './navigation/NavigationService';
import {NavigationContainer} from '@react-navigation/native';
import {useSelector} from 'react-redux';
import {createStackNavigator} from '@react-navigation/stack';
import AuthScreen from './AuthScreen';
import MainStack from './MainStack';

const Stack = createStackNavigator();

export default function Routes() {
  const {userData,isUserExist} = useSelector((state) => state.auth);
  return (
    <NavigationContainer>
      <Stack.Navigator>
        {userData && !!userData.token ? MainStack(Stack) : AuthScreen(Stack,isUserExist)}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
