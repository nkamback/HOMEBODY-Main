import React from 'react';
import TabRoutes from './TabRoutes';
import {
  Classes,
  CoachDetails,
  Schedule,
  ClassDetails,
  Summary,
  Settings,
  Notifications,
  ContactUs,
  ChangePassword,
  TransactionHistory,
  TransactionMonthHistory,
  TransactionDetails,
  EditProfile,
  LiveStreaming,
  Ratings
} from '../Screens';
import VideoPlayer from '../components/VideoPlayer';

export default function (Stack) {
  return (
    <>
      <Stack.Screen
        name="tab"
        component={TabRoutes}
        options={{headerShown: false}}
      />
        <Stack.Screen
        name="videoPlayer"
        component={VideoPlayer}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="classes"
        component={Classes}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="coachDetails"
        component={CoachDetails}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="classDetails"
        component={ClassDetails}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="schedule"
        component={Schedule}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="summary"
        component={Summary}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="settings"
        component={Settings}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="notifications"
        component={Notifications}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="contactUs"
        component={ContactUs}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="changePassword"
        component={ChangePassword}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="transactionHistory"
        component={TransactionHistory}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="transactionMonthHistory"
        component={TransactionMonthHistory}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="transactionDetails"
        component={TransactionDetails}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="editProfile"
        component={EditProfile}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="liveStreaming"
        component={LiveStreaming}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="ratings"
        component={Ratings}
        options={{headerShown: false}}
      />
    </>
  );
}
