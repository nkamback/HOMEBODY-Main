import React from 'react';
import VideoPlayer from '../components/VideoPlayer';
import {
  Login,
  Signup,
  OuterScreen,
  EnterMobile,
  OtpVerification,
  ForgotPassword,
  Welcome,
} from '../Screens';

export default function (Stack, isUserExist) {
  return (
    <>
      
        <Stack.Screen
          name="welcome"
          component={Welcome}
          options={{headerShown: false}}
        />
      
      <Stack.Screen
        name="outer"
        component={OuterScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="login"
        component={Login}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="signup"
        component={Signup}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="enterMobile"
        component={EnterMobile}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="otpVerify"
        component={OtpVerification}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="forgotPassword"
        component={ForgotPassword}
        options={{headerShown: false}}
      />
    </>
  );
}
