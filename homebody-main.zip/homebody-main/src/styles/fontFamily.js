
export default {
    regular:"Helvetica Neue",
    bold:"HelveticaNeueBold",
    medium:"HelveticaNeue-Medium"
}



