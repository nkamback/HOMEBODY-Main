import {StyleSheet} from 'react-native';

import {
  textScale,
  moderateScale,
  moderateScaleVertical,
} from './responsiveSize';
import colors from './colors';
import fontFamily from './fontFamily';
export const hitSlopProp ={
  top:12,
  right:12,
  left:12,
  bottom:12
}
export default StyleSheet.create({
  fontSize12: {
    fontSize: textScale(12),
    color: colors.themeMain,
    fontFamily: fontFamily.regular,
  },
  fontSize11: {
    fontSize: textScale(11),
    color: colors.themeMain,
    fontFamily: fontFamily.regular,
  },
  fontSize14: {
    fontSize: textScale(14),
    color: colors.themeMain,
    fontFamily: fontFamily.regular,
  },
  fontSize13: {
    fontSize: textScale(13),
    color: colors.grey,
    fontFamily: fontFamily.regular,
  },
  fontSize15: {
    fontSize: textScale(15),
    color: colors.themeMain,
    fontFamily: fontFamily.regular,
  },

  fontSize16: {
    fontSize: textScale(16),
    color: colors.black,
    fontFamily: fontFamily.regular,
  },
  fontSize18: {
    fontSize: textScale(18),
    color: colors.black,
    fontFamily: fontFamily.regular,
  },
  fontSize20: {
    fontSize: textScale(20),
    color: colors.black,
    fontFamily: fontFamily.regular,
  },
  fontSize24: {
    fontSize: textScale(24),
    color: colors.black,
    fontFamily: fontFamily.regular,
  },
  fontBold16: {
    fontSize: textScale(16),
    color: colors.black,
    fontFamily: fontFamily.bold,
  },
  fontBold18: {
    fontSize: textScale(18),
    color: colors.black,
    fontFamily: fontFamily.bold,
  },
  fontBold24: {
    fontSize: textScale(24),
    color: colors.black,
    fontFamily: fontFamily.bold,
  },
  fontBold21: {
    fontSize: textScale(21),
    color: colors.black,
    fontFamily: fontFamily.bold,
  },
  loader: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonRect: {
    height: moderateScaleVertical(46),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.themeMain,
    borderWidth: 1,
    borderColor: colors.themeMain,
    borderRadius:4
  },
  shadowStyle: {
    backgroundColor: colors.white,
    borderRadius: 4,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 2,
    elevation: 2,
    // borderColor: colors.lightWhiteGrayColor,
    // borderWidth: 0.7,
  },
  buttonTextWhite:{
    fontFamily:fontFamily.regular,
    fontSize:textScale(16),
    color:colors.white
  },
  headingText:{
    fontFamily:fontFamily.medium,
    color:colors.blackOpacity90,
    fontSize:textScale(16),
    
  },
  badgeWhite:{
    fontSize: textScale(15),
    fontFamily: fontFamily.regular,
    color: colors.blackOpacity70,
    paddingVertical: moderateScale(6),
    backgroundColor: "rgba(255,255,255,0.7)",
    borderRadius: 5,
    paddingRight: 10,
    paddingLeft: 10,
  },
  outlinedBtnExtraStyle:{
    backgroundColor: colors.white,
    marginTop: 0,
    height: undefined,
    paddingVertical: 2,
    paddingHorizontal: 10,
  },
});
