import React, {Component} from 'react';
import {
  Text,
  View,
  ScrollView,
  Image,
  FlatList,
  StyleSheet,
  Modal,
} from 'react-native';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import GradientWrapper from '../../components/GradientWrapper';
import SearchBox from '../../components/SearchBox';
import {
  moderateScaleVertical,
  moderateScale,
  width,
} from '../../styles/responsiveSize';
import ScrollableTabView, {
  DefaultTabBar,
} from 'react-native-scrollable-tab-view';
import SearhScreen from '../../components/SearhScreen';
import colors from '../../styles/colors';
import GradientButton from '../../components/GradientButton';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import fontFamily from '../../styles/fontFamily';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import Card from '../../components/Card';
import moment from 'moment';
import CoachCard from '../../components/CoachCard';
import ClassCoachView from '../../components/ClassCoachView';
import {TouchableOpacity} from 'react-native-gesture-handler';
import actions from '../../redux/actions';
import {showError, getNextDates} from '../../utils/helperFunctions';
import ListEmptyComponent from '../../components/ListEmptyComponent';

const datesArray = getNextDates(7);
class Explore extends Component {
  state = {
    activeTab: 0,
    isClassActive: true,
    isLoading: true,
    coachesArray: [],
    classesArray: [],
    selectedDateObj: datesArray[0],
    sliderValues: [9, 18],
    searchVisbile: false,
    searchText: '',
  };

  componentDidMount() {
    this.getClassesCoachesApiHit(this.state.activeTab);
    this.focusListner = this.props.navigation.addListener('focus', () => {
      const {params} = this.props?.route || {};
      let updatedStateParams = {};
      if (
        params &&
        params.isClassActive !== undefined &&
        params.isClassActive !== this.state.isClassActive
      ) {
        updatedStateParams = {isClassActive: params.isClassActive};
      }
      if (
        params &&
        params.activeIndex !== undefined &&
        params.activeIndex !== this.state.activeTab
      ) {
        updatedStateParams.activeTab = params.activeIndex;
        this.tabViewRef.goToPage(params.activeIndex);
        this.getClassesCoachesApiHit(params.activeIndex);
      } else {
        this.getClassesCoachesApiHit(this.state.activeTab);
      }
      this.setState({...updatedStateParams});
    });
  }

  componentWillUnmount() {
    if (this.focusListner) {
      this.focusListner();
    }
  }

  getClassesCoachesApiHit = async (activeTab, isClassOnly = false) => {
    let query = '';
    if (activeTab == 0) {
      query = `?type=fitness`;
    } else if (activeTab == 1) {
      query = `?type=wellness`;
    } else {
      query = `?type=one_on_one`;
    }
    try {
      const {selectedDateObj, sliderValues} = this.state;
      const {obj, apiDate} = selectedDateObj;
      let startTimeHourApi = `${sliderValues[0]}:00`;
      if (obj.format('DD') == moment().format('DD')) {
        if (moment().format('HH') >= sliderValues[0]) {
          //IN case user has has selected today's day but time selected is of past
          // alert(moment().format("HH")+' Past time of today is selected '+sliderValues[0])
          startTimeHourApi = moment().format('HH:mm');
        }
      }

      let startDateTime = moment(
        `${apiDate} ${startTimeHourApi}`,
        'DD-MM-YYYY HH:mm',
      ).utc();
      let endDateTime = moment(
        `${apiDate} ${sliderValues[1]}:00`,
        'DD-MM-YYYY HH:mm',
      ).utc();
      // alert(apiDate,'hte api date');
      let dateTimeQuery =
        (obj &&
          `&start_date=${startDateTime.format(
            'YYYY-MM-DD',
          )}&start_time=${startDateTime.format(
            'HH:mm',
          )}&end_time=${endDateTime.format(
            'HH:mm',
          )}&end_date=${endDateTime.format('YYYY-MM-DD')}`) ||
        '';
      // alert(dateTimeQuery)
      const classRes = await actions.getClassesList(query + dateTimeQuery);
      this.setState({
        classesArray: classRes.data?.classes || [],
      });
      if (isClassOnly) {
        this.setState({isLoading: false});
        return;
      }
      const coachRes = await actions.getCoaches(query);
      this.setState({
        isLoading: false,
        coachesArray: coachRes.data?.coaches || [],
      });
    } catch (error) {
      this.setState({isLoading: false});
      showError(error.message);
    }
  };
  getClassesApiHit = async (activeTab) => {
    let query = '';
    if (activeTab == 0) {
      query = `?type=fitness`;
    } else if (activeTab == 1) {
      query = `?type=wellness`;
    } else {
      query = `?type=one_on_one`;
    }
    try {
      const classRes = await actions.getClassesList(query);
      this.setState({
        classesArray: classRes.data?.classes || [],
        isLoading: false,
      });
    } catch (error) {
      this.setState({isLoading: false});
      showError(error.message);
    }
  };
  updateClassesView = (isClassActive) => () => {
    this.setState({isClassActive});
  };

  renderCoachsData = () => {
    const {coachesArray,isLoading} = this.state;

    return (
      <FlatList
        data={coachesArray}
        renderItem={this._renderItemCoaches}
        ListHeaderComponent={<View style={{height:2}} />}
        ListFooterComponent={<View style={{height:5}} />}
        keyExtractor={(item, index) => String(index)}
        contentContainerStyle={{flexGrow:1}}
        ListEmptyComponent={<ListEmptyComponent isLoading={isLoading} withEmogi empytText="No Instructor Available" />}
      />
    );
  };

  onDateChange = (selectedDateObj) => () => {
    this.setState({selectedDateObj}, () => {
      if (this.state.isClassActive) {
        this.setState({isLoading: true});
        this.getClassesCoachesApiHit(this.state.activeTab, true);
      }
    });
  };

  renderClassData = () => {
    const {selectedDateObj, sliderValues, classesArray} = this.state;

    return (
      <>
        <View style={styles.classContainer}>
          <View style={styles.txtRow}>
            <Text style={[commonStyles.fontSize16, {color: colors.black}]}>
              {`${selectedDateObj.obj.format('dddd')}, ${moment(
                sliderValues[0],
                'hh',
              ).format('hha')}-${moment(sliderValues[1], 'hh').format('hha')}`}
            </Text>
          </View>
          <View style={styles.dateRowContainer}>
            {datesArray.map((val) => (
              <TouchableOpacity
                style={{alignItems: 'center'}}
                onPress={this.onDateChange(val)}
                key={val.apiDate}>
                <Text style={styles.dayText}>{val.dayText}</Text>
                <View
                  style={[
                    styles.unselectedContainer,
                    selectedDateObj.apiDate === val.apiDate &&
                      styles.selectedView,
                  ]}>
                  <Text
                    style={[
                      {...commonStyles.fontSize14, color: colors.lightGrey},
                      selectedDateObj.apiDate === val.apiDate && {
                        color: colors.white,
                      },
                    ]}>
                    {val.obj.format('DD')}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
          <View style={{paddingHorizontal: moderateScale(16), marginTop: 12}}>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <Text style={commonStyles.fontBold16}>
                {moment(sliderValues[0], 'hh').format('hh a')}
              </Text>
              <Text style={commonStyles.fontBold16}>
                {moment(sliderValues[1], 'hh').format('hh a')}
              </Text>
            </View>
            <MultiSlider
              values={[sliderValues[0], sliderValues[1]]}
              sliderLength={width - moderateScale(32)}
              onValuesChange={this.onSliderValueChange}
              selectedStyle={{backgroundColor: colors.themeMain}}
              markerStyle={styles.marker}
              min={0}
              max={23}
              step={1}
              allowOverlap={false}
              snapped
              minMarkerOverlapDistance={5}
            />
          </View>
        </View>
        <View
          style={{
            paddingHorizontal: moderateScale(16),
            marginTop: moderateScaleVertical(10),
          }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: moderateScale(16),
            }}>
            <Text style={commonStyles.headingText}>Explore Classes</Text>
            <TouchableOpacity
              activeOpacity={0.7}
              hitSlop={hitSlopProp}
              onPress={this.moveToNewScreen('classes', {
                data: classesArray,
                activeTab: this.state.activeTab,
                selectedDateObj: this.state.selectedDateObj,
                sliderValues: this.state.sliderValues,
              })}>
              <Text style={styles.seeAllText}>See all</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={classesArray}
            ItemSeparatorComponent={() => <View style={{width: 10}} />}
            horizontal
            renderItem={this._renderItemClasses}
            ListEmptyComponent={
              <ListEmptyComponent
                isLoading={this.state.isLoading}
                empytText="No class available"
              />
            }
            keyExtractor={(item, index) => String(index)}
          />
          <View style={{height: 20}} />
        </View>
      </>
    );
  };

  openSearch = () => {
    this.setState({searchVisbile: true});
  };
  closeSearch = () => {
    this.setState({searchVisbile: false});
  };

  onChangeSearch = (searchText) => {
    this.setState({searchText});
  };
  _renderItemClasses = ({item, index}) => {
    const {selectedDateObj, sliderValues} = this.state;
    const {obj, apiDate} = selectedDateObj;

    // converting utc time to local time
    var utcToLocal = moment(`${item.start_time}`, 'hh:mm A').format(
      'YYYY-MM-DD HH:mm:ss',
    );
    var utcToLocalTimeObj = moment.utc(utcToLocal).toDate();
    //combining local booking date and utc time converted to local time to make a local dateTime value that will be use to make utc object;
    let startDateTimeForApi = moment(
      `${apiDate} ${moment(utcToLocalTimeObj).format('HH:mm')}`,
      'DD-MM-YYYY HH:mm',
    ).utc();
    return (
      <Card
        data={item}
        subText={item.activity}
        hideBtn
        height={moderateScaleVertical(104)}
        width={moderateScale(184)}
        selectedDateUTC={startDateTimeForApi}
      />
    );
  };
  _renderItemCoaches = ({item, index}) => {
    return <CoachCard data={item} />;
  };

  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };
  onSliderValueChange = (sliderValues) => {
    this.setState({sliderValues});
    if (this.sliderTimeout) {
      clearTimeout(this.sliderTimeout);
    }

    this.sliderTimeout = setTimeout(() => {
      this.setState({isLoading: true});
      if (this.state.isClassActive) {
        this.getClassesCoachesApiHit(this.state.activeTab, true);
      }
    }, 500);
  };
  renderClasCoachBtn = () => {
    const {isClassActive, searchText} = this.state;
    return (
      <View style={styles.btnRow}>
        <GradientButton
          onPress={this.updateClassesView(true)}
          btnText="CLASSES"
          colorsArray={
            isClassActive
              ? [colors.gradientA, colors.gradientB]
              : [colors.white, colors.white]
          }
          containerStyle={
            isClassActive ? {width: '45%'} : styles.inActiveContainer
          }
          borderRadius={4}
          textStyle={{
            fontSize: 12,
            fontFamily: fontFamily.bold,
            color: isClassActive ? colors.white : colors.blackOpacity50,
          }}
        />
        <GradientButton
          onPress={this.updateClassesView(false)}
          btnText="COACHES"
          colorsArray={
            !isClassActive
              ? [colors.gradientA, colors.gradientB]
              : [colors.white, colors.white]
          }
          containerStyle={
            !isClassActive ? {width: '45%'} : styles.inActiveContainer
          }
          borderRadius={4}
          textStyle={{
            fontSize: 12,
            fontFamily: fontFamily.bold,
            color: !isClassActive ? colors.white : colors.blackOpacity50,
          }}
        />
      </View>
    );
  };
  _onChangeTab = (data) => {
    if (data.i != data.from && this.state.activeTab != data.i) {
      this.getClassesCoachesApiHit(data.i);
      this.setState({activeTab: data.i, isLoading: true});
    }
  };
  render() {
    const {isClassActive, isLoading, searchVisbile} = this.state;
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }}  isLoading={isLoading}>
        <View style={styles.searchContainer}>
          <SearchBox
            placeholder={
              isClassActive ? 'Search for class' : 'Search for instructor'
            }
            onPress={this.openSearch}
          />
        </View>
        <View style={{flex: 1,backgroundColor:colors.white}}>
          <ScrollableTabView
            tabBarActiveTextColor={colors.blueMain}
            // textStyle={{fontFamily:fontFamily.regular}}
            style={{paddingTop:5}}
            tabBarTextStyle={{fontFamily:fontFamily.regular, fontWeight: 'normal' }}
            tabBarUnderlineStyle={{
              backgroundColor: colors.blueMain,
              overflow: 'hidden',
            }}
            locked
            onChangeTab={this._onChangeTab}
            ref={(tabView) => {
              this.tabViewRef = tabView;
            }}
            tabBarInactiveTextColor={colors.headingGrey}>
            <View style={styles.tab} tabLabel="FITNESS">
              <ClassCoachView
                updateClassesView={this.updateClassesView}
                isClassActive={isClassActive}
              />
              {!isClassActive
                ? this.renderCoachsData()
                : this.renderClassData()}
            </View>

            <View tabLabel="WELLNESS" style={styles.tab}>
              <ClassCoachView
                updateClassesView={this.updateClassesView}
                isClassActive={isClassActive}
              />
              {!isClassActive
                ? this.renderCoachsData()
                : this.renderClassData()}
            </View>
          </ScrollableTabView>
        </View>
        {searchVisbile && (
          <Modal visible={searchVisbile} onRequestClose={this.closeSearch}>
            <SearhScreen
              isClassActive={isClassActive}
              activeTab={this.state.activeTab}
              onClose={this.closeSearch}
            />
          </Modal>
        )}
      </GradientWrapper>
    );
  }
}

export default Explore;

const styles = StyleSheet.create({
  marker: {
    backgroundColor: colors.white,
    borderColor: colors.blackOpacity10,
    borderWidth: 1,
    height: 20,
    width: 20,
  },
  searchContainer: {
    marginHorizontal: moderateScale(16),
    marginTop: moderateScale(30),
    marginBottom: moderateScale(20),
  },
  tab: {flex: 1, backgroundColor: colors.white},
  inActiveContainer: {
    width: '45%',
    borderColor: colors.blackOpacity40,
    borderWidth: 1,
    backgroundColor: colors.white,
    borderRadius: 4,
  },
  btnRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: moderateScale(20),
    paddingHorizontal: moderateScale(16),
    marginBottom: moderateScaleVertical(24),
  },
  seeAllText: {
    ...commonStyles.fontSize18,
    color: colors.themeMain,
    fontFamily: fontFamily.bold,
    textTransform: 'capitalize',
  },
  classContainer: {
    backgroundColor: colors.lightgreen,
    paddingBottom: 5,
    height: moderateScaleVertical(180),
  },
  txtRow: {
    marginVertical: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dateRowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: moderateScale(16),
  },
  dayText: {
    ...commonStyles.fontSize14,
    color: colors.blackOpacity90,
  },
  unselectedContainer: {
    height: 26,
    width: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedView: {
    backgroundColor: colors.themeMain,
    color: colors.white,
    borderRadius: 70,
  },
});
