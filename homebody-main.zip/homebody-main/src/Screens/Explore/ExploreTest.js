
import React, {Component, Fragment} from 'react';
import Orientation from 'react-native-orientation';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import {
  Platform,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  StyleSheet,
  Image,
  TouchableWithoutFeedback,
} from 'react-native';
import {connect} from 'react-redux';
import * as Animatable from 'react-native-animatable';
import RtcEngine, {
  RtcLocalView,
  RtcRemoteView,
  VideoRenderMode,
  ChannelProfile,
  ClientRole,
  VideoOutputOrientationMode,
  VideoDimensions,
  VideoEncoderConfiguration,
  AudioChannel
} from 'react-native-agora';
import {AGORA_APP_ID} from '../../constants/constants';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';
import {
  moderateScale,
  moderateScaleVertical,
  width,
  height,
} from '../../styles/responsiveSize';
import {requestCameraAndAudioPermission} from '../../utils/permissions';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import Loader from '../../components/Loader';
import fontFamily from '../../styles/fontFamily';
import ProgressBar from '../../libs/ProgressBar/ProgressBar';
import VideoPlayer from '../../components/VideoPlayer';
import { showMessage } from 'react-native-flash-message';

class LiveStreaming extends Component {
  constructor(props) {
    super(props);
    this.state = {
      channelName: 'test_channel',
      joinSucceed: false,
      peerIds: [],
      isLoading: true,
      streamData: {},
      hideControls: false,
      isHostAvail: false,
      isLandscape: false,
      isStreamEnd: false,
      timer: 20,
    };

    if (Platform.OS === 'android') {
      // Request required permissions from Android
      requestCameraAndAudioPermission().then(() => {
        console.log('requested!');
      });
    }

    this._engine = RtcEngine;
  }
  componentDidMount() {
    let dataParam = this.props.route?.params?.data;
    actions
      .joinStream({class: dataParam.id})
      .then((res) => {
        this.setState({streamData: res.data, isLoading: false}, () => {
          this.startCall(res.data);
        });
      })
      .catch(this.errorMethod);
    Orientation.unlockAllOrientations();
    Orientation.addOrientationListener((orientation) => {
      if (orientation === 'LANDSCAPE') {
        this.setState({isLandscape: true});
      } else {
        this.setState({isLandscape: false});
      }
    });
    // Orientation.lockToLandscape();
    this.init();
  }

  errorMethod = (error) => {
    showError(error.message);
    this.setState({isLoading: false});
  };
  init = async () => {
    this._engine = await RtcEngine.create(AGORA_APP_ID);
    const da = await this._engine.enableVideo();
    const aa = await this._engine.enableAudio();

    // console.log(da, 'the da has a value');

    this._engine.addListener('Warning', (warn) => {
      console.log('Warning', warn);
    });

    this._engine.addListener('Error', (err) => {
      console.log('Error', err);
    });

    this._engine.addListener('UserJoined', (uid, elapsed) => {
      console.log(uid, 'the uidjoiajojfoajsdofj');
      let data = this.props.route?.params?.data;
      if (uid == data?.coach?.id) {
        if (!this.state.isHostAvail) {
          this.setState({isHostAvail: true,timer:20});
          showMessage({
            type:"info",
            icon:'info',
            message:"Coach is live now!"
          })
          Orientation.unlockAllOrientations();
        }
      }

      console.log(uid, 'the uid value');
    });
    this._engine.addListener('RemoteVideoStateChanged', (uid, elapsed) => {});

    this._engine.addListener('UserOffline', (uid, reason) => {
      let data = this.props.route?.params?.data;
      if (uid === data?.coach?.id) {
        if(!this.state.isStreamEnd){
          this.endCall();
        }
        
      }
    });

    // If Local user joins RTC channel
    this._engine.addListener('JoinChannelSuccess', (channel, uid, elapsed) => {
      console.log('JoinChannelSuccess', channel, uid, elapsed);
      // Set state variable to true
      this.setState({
        joinSucceed: true,
      });
    });
    this._engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    this._engine.setClientRole(ClientRole.Audience);
    // setTimeout(()=>{
    //   this._engine.setClientRole(ClientRole.Broadcaster);
    // },4000);

    this.timerInterval = setInterval(() => {
      if (this.state.timer > 0) {
        this.setState((prevState) => ({
          ...prevState,
          timer: prevState.timer - 1,
        }));
      } else {
        if (this.timerInterval) {
          clearInterval(this.timerInterval);
        }
      }
    }, 1000);
  };

  endCall = async () => {
    const {isStreamEnd} = this.state;
    if (!!this._engine && !!this._engine.leaveChannel) {
      this._engine?.leaveChannel();
    }
    if (!isStreamEnd) {
      this.setState({isStreamEnd: true}, () => {
        this.props.navigation.goBack(null);
      });
    }
  };

  startCall = async (stramData) => {
    const {channel_id, token, uid} = stramData;
    // Join Channel using null token and channel name
    // console.log(uid, 'the token pojopjopjs');
    await this._engine?.joinChannel(token, channel_id, null, uid);
  };

  componentWillUnmount() {
    if (!!this._engine&&!!this._engine.leaveChannel) {
      this._engine?.leaveChannel();
    }

    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    Orientation.lockToPortrait();
  }

  toggleControl = () => {
    this.setState((prevState) => ({
      ...prevState,
      hideControls: !prevState.hideControls,
    }));
  };

  render() {
    const {
      streamData,
      joinSucceed,
      isLoading,
      hideControls,
      isLandscape,
      isHostAvail,
      timer,
    } = this.state;
    console.log(this.state, 'the aosjfdoijoij');
    let data = this.props.route?.params?.data;
    console.log(data,'the data has a value');
    let roomData=data.room;
    const widge=JSON.parse(roomData.widget_details);
    console.log(widge)
    if (isLoading) {
      return <Loader isLoading={true} />;
    }
    let dimensions={...widge?.clock?.dimensions};
    if(isLandscape){
      dimensions.top=dimensions.top*width/100;
      dimensions.left=dimensions.left*height/100;
    }else{
      dimensions.top=dimensions.top*height/100;
      console.log(dimensions.left,'the left dimensiongs');
      console.log(widge.clock.dimensions,'the widh clock djfijijsdifjdajf')
      dimensions.left=dimensions.left*width/100;
      console.log(dimensions.left+120,"the required one")
      if(dimensions.left+120>width){
        console.log(dimensions.left+120-width-30,'heheh')
        dimensions.left=dimensions.left-(dimensions.left+120-width);
      }
    }
    console.log(width);
    console.log(dimensions,"++++++++++++++++++++")
    // if (!joinSucceed || !isHostAvail) {
    //   return <VideoPlayer navigation={this.props.navigation} />;
    // }
    return (
      <View style={{flex: 1, backgroundColor: colors.black}}>
        <RtcRemoteView.SurfaceView
          style={
            isLandscape ? styles.fullViewLandScape : styles.fullViewPortrait
          }
          uid={data?.coach?.id}
          channelId={streamData.channel_id || ''}
          renderMode={VideoRenderMode.FILL}
        />
        <TouchableWithoutFeedback onPress={this.toggleControl}>
          <View style={{...StyleSheet.absoluteFillObject, zIndex: 99}}>
            {timer > 0 && (
              <View style={{position:"absolute",...(dimensions||{})}}>
                <AnimatedCircularProgress
                  size={120}
                  width={4}
                  duration={20}
                  fill={timer/.20}
                  backgroundWidth={2}
                  tintColor={colors.white}
                  onAnimationComplete={() => console.log('onAnimationComplete')}
                  backgroundColor={colors.whiteOpacity10}>
                  {(fill) => (
                    <Text
                      style={{
                        color: colors.white,
                        fontFamily: fontFamily.regular,
                        fontSize: 24,
                      }}>
                      {this.state.timer}
                    </Text>
                  )}
                </AnimatedCircularProgress>
              </View>
            )}
            <View
              style={{
                justifyContent: 'center',
                position: 'absolute',
                bottom: 30,
                right: 0,
                left: 0,
                flexDirection: 'row',
              }}>
              {!hideControls && (
                <Animatable.View duration={700} animation="slideInUp">
                  <TouchableOpacity
                    onPress={this.endCall}
                    style={{
                      padding: 10,
                      backgroundColor: colors.white,
                      borderRadius: 70,
                    }}>
                    <Image
                      style={{height: 32, width: 32}}
                      resizeMode="contain"
                      source={imagePath.endCall}
                    />
                  </TouchableOpacity>
                </Animatable.View>
              )}
            </View>
            {!hideControls && (
              <View
                style={{bottom: 10, position: 'absolute', left: 0, right: 10}}>
                <ProgressBar theme="white" progress={1} />
              </View>
            )}
          </View>
        </TouchableWithoutFeedback>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps)(LiveStreaming);

const styles = StyleSheet.create({
  max: {
    flex: 1,
  },
  buttonHolder: {
    height: 100,
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  button: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: '#0093E9',
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff',
  },
  fullViewLandScape: {
    width: height,
    height: width,
  },
  fullViewPortrait: {
    height,
    width,
  },
  remoteContainer: {
    width: '100%',
    height: 150,
    position: 'absolute',
    top: 5,
  },
  remote: {
    flex: 1,
    width: height,
    height: width,
  },
  noUserText: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    color: '#0093E9',
  },
});
