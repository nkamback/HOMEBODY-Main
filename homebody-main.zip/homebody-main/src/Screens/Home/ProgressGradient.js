import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import LinearGradient from 'react-native-linear-gradient';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';

export default function ProgressGradient() {
  const [timer, setTimer] = useState(21);

  useEffect(() => {
    setTimeout(() => {
      if (timer > 0) setTimer(timer - 1);
    }, 1000);
  }, [timer]);
  return (
    <View
      style={{
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        padding: 20,
        paddingTop: 190,
        position: 'absolute',
        backgroundColor: colors.black,
      }}>
      <AnimatedCircularProgress
        size={120}
        width={6}
        duration={20}
        fill={(timer / 20) * 100}
        backgroundWidth={3}
        tintColor={colors.gradientB}
        tintColorSecondary={colors.gradientA}
        backgroundColor={colors.white26}>
        {(fill) => (
          <Text style={{...commonStyles.fontBold21, color: colors.white}}>
            {timer}
          </Text>
        )}
      </AnimatedCircularProgress>
    </View>
  );
}

const styles = StyleSheet.create({
  buttonContainer: {
    width: 200,
    alignItems: 'center',
  },
  buttonText: {
    textAlign: 'center',
    color: '#4C64FF',
    padding: 15,
    marginLeft: 1,
    marginRight: 1,
    width: 198,
  },
});
