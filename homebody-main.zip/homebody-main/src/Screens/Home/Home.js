import React, {Component} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  StatusBar,
  ScrollView,
  FlatList,
  StyleSheet,
  Modal,
  Platform,
} from 'react-native';
import Carousel from 'react-native-snap-carousel';
import {
  moderateScale,
  moderateScaleVertical,
  width,
} from '../../styles/responsiveSize';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import {TextField, OutlinedTextField} from 'react-native-material-textfield';
import colors from '../../styles/colors';
import imagePath from '../../constants/imagePath';
import TextOverLine from '../../components/TextOverLine';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import GradientWrapper from '../../components/GradientWrapper';
import SearchBox from '../../components/SearchBox';
import Card from '../../components/Card';
import CirularImageWithLabel from '../../components/CircularImageWithLabel';
import HeadingImageView from '../../components/HeadingImageView';
import ProgressiveImage from '../../components/ProgressiveImage';
import {exerciseImg} from '../../constants/constants';
import SearhScreen from '../../components/SearhScreen';
import actions from '../../redux/actions';
import {connect} from 'react-redux';
import {
  checkCurrentDateDiffFromMinMaxTime,
  checkDataIfFuture,
  getSelectedDateTime,
  showError,
} from '../../utils/helperFunctions';
import moment from 'moment';
import {showMessage} from 'react-native-flash-message';
import socketServices from '../../utils/socketService';
import ListEmptyComponent from '../../components/ListEmptyComponent';
import fontFamily from '../../styles/fontFamily';
import AsyncStorage from '@react-native-community/async-storage';
import LinearGradient from 'react-native-linear-gradient';
import {color} from 'react-native-reanimated';
class Home extends Component {
  state = {
    searchVisbile: false,
    homeData: {},
    isLoading: true,
  };
  componentDidMount() {
    console.log(this.props.userData);
    socketServices.initializeSocket(this.props.userData.token);

    this.navigationListenter = this.props.navigation.addListener(
      'focus',
      () => {
        actions
          .getHomeData()
          .then((res) => {
            this.setState({isLoading: false, homeData: res.data});
          })
          .catch(this.errorMethod);
      },
    );

    AsyncStorage.getItem('fcmToken').then((token) => {
      actions.updateFcmToken({
        device_token: token,
        device_type: Platform.OS,
      });
    });

    actions.getFavCoaches();
  }
  componentWillUnmount() {
    if (this.navigationListenter) {
      this.navigationListenter();
    }
  }
  errorMethod = (error) => {
    this.setState({isLoading: false});
    showError(error.message);
  };

  streamErrorMessageBasedOnDateType = (curDateType) => {
    if (curDateType == 'before day') {
      showError("Your class hasn't started yet");
      return;
    }
  };
  _renderClasses = ({item, index}) => {
    // console.log(item, 'the item dat is as follow');
    let roomData = item.room;
    console.log(roomData, 'the data room');
    const widge = JSON.parse(roomData.widget_details);
    console.log(widge);
    let stillUtc = moment(
      `${item.start_date} ${item.start_time}`,
      'YYYY-MM-DD hh:mm A',
    ).format('YYYY-MM-DD HH:mm:ss');
    // console.log(stillUtc);
    let dateTimeObj = moment.utc(stillUtc).toDate();
    // console.log(dateTimeObj, 'the date time ojbect');
    let testD = moment(dateTimeObj);
    let shouldStream = true;
    let curClassTimeType = checkCurrentDateDiffFromMinMaxTime(testD, 5, 200);
    if (curClassTimeType !== 'start') {
      shouldStream = false;
    }
    let btnText = '';
    if (curClassTimeType == 'start') {
      btnText = `Join live`;
    } else if (curClassTimeType == 'yetToStart') {
      btnText = ``;
    } else {
      btnText = '';
    }
    return (
      <Card
        data={item}
        subText={`w/${item?.coach?.name || 'coach'}`}
        startDateText={`${testD.format(`DD-MMM hh:mm A`)}`}
        hideBtn={!btnText}
        btnText={btnText}
        onPress={() => {
          this.props.navigation.navigate('liveStreaming', {data: item});
        }}
      />
    );
  };

  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };

  _renderFavCoaches = ({item, index}) => {
    // console.log(item, 'the item value si');
    return (
      <CirularImageWithLabel
        onPress={() =>
          this.props.navigation.navigate('coachDetails', {data: item})
        }
        img={item?.avatar?.thumb_path}
        label={item.name}
      />
    );
  };
  _renderOffers = ({item, index}) => {
    console.log(item, 'the item value is as follow');
    let startDateTimeForApi;
    startDateTimeForApi = getSelectedDateTime(item);
    return (
      <TouchableOpacity
        onPress={this.moveToNewScreen('classDetails', {
          data: item,
          selectedDateUTC: startDateTimeForApi,
        })}>
        <ProgressiveImage
          source={{uri: item.image?.thumb_path || exerciseImg}}
          style={{height: moderateScale(128), width: '100%', borderRadius: 10}}
          containerStyle={{
            height: moderateScale(128),
            width: width - moderateScale(32),
            borderRadius: 10,
          }}
        />
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: 6,
            backgroundColor: colors.blackOpacity15,
            borderBottomLeftRadius: 10,
            borderBottomRightRadius: 10,
            // backgroundColor:"pink"
          }}>
          <Text
            style={{
              ...commonStyles.fontSize15,
              fontFamily: fontFamily.medium,
              color: colors.white,
            }}>
            {item.name}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  openSearch = () => {
    this.setState({searchVisbile: true});
  };
  closeSearch = () => {
    this.setState({searchVisbile: false});
  };
  render() {
    const {searchVisbile, isLoading, homeData} = this.state;
    const {favCaochLoading, favCoaches} = this.props;

    return (
      <GradientWrapper
        start={{x: 0, y: 1}}
        end={{x: 1, y: 1}}
        isLoading={isLoading || favCaochLoading}>
        <View style={{paddingTop: 20, paddingBottom: 25, alignItems: 'center'}}>
          <Image source={imagePath.logoWhite} />
        </View>

        <View style={styles.btnContainer}>
          <View style={styles.btnRow}>
            <TouchableOpacity
              onPress={this.moveToNewScreen('explore', {activeIndex: 0})}
              style={[styles.typeBadge, {marginRight: 10}]}>
              <Text style={styles.badgeText}>Fitness</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={this.moveToNewScreen('explore', {activeIndex: 1})}
              style={[styles.typeBadge, {marginLeft: 10}]}>
              <Text style={styles.badgeText}>Wellness</Text>
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView style={styles.scroll}>
          <View style={{marginTop: moderateScaleVertical(10)}}>
            <View style={styles.upcomingContainer}>
              <Text style={commonStyles.headingText}>Upcoming Classes</Text>
            </View>
            <FlatList
              data={homeData?.upcoming_classes?.list || []}
              horizontal
              ItemSeparatorComponent={() => <View style={{width: 10}} />}
              ListEmptyComponent={
                <ListEmptyComponent
                  isLoading={isLoading}
                  txtStyle={{fontFamily: fontFamily.regular}}
                  empytText="No Upcoming Class"
                />
              }
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item, index) => String(index)}
              renderItem={this._renderClasses}
            />
            <View style={{height: moderateScaleVertical(24)}} />
            {favCoaches.length > 0 && (
              <View style={styles.favContainer}>
                <View style={styles.favTextContainer}>
                  <Text style={commonStyles.headingText}>
                    Favorite Instructors
                  </Text>
                  <TouchableOpacity
                    hitSlop={hitSlopProp}
                    onPress={() => this.props.navigation.navigate('fav')}>
                    <Text style={commonStyles.fontSize14}>See all</Text>
                  </TouchableOpacity>
                </View>
                <View>
                  <FlatList
                    data={favCoaches}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    ItemSeparatorComponent={() => <View style={{width: 10}} />}
                    keyExtractor={(item, index) => String(index)}
                    renderItem={this._renderFavCoaches}
                  />
                </View>
              </View>
            )}
            <HeadingImageView
              containerStyle={{marginBottom: moderateScaleVertical(24)}}
              onPress={this.moveToNewScreen('explore', {isClassActive: true})}
              source={imagePath.virtualClasses}
            />
            <HeadingImageView
              label="World Class Instructors"
              heading="Instructors"
              containerStyle={{marginBottom: moderateScaleVertical(24)}}
              onPress={this.moveToNewScreen('explore', {isClassActive: false})}
              source={imagePath.icCoaches}
            />
            {homeData?.recommended_classes?.list&&homeData?.recommended_classes?.list?.length>0&&<View style={styles.tryContainer}>
              <Text
                style={{
                  ...commonStyles.fontSize14,
                  color: colors.headingGrey,
                  textTransform: 'uppercase',
                }}>
                Try It Out
              </Text>
            </View>}
            <Carousel
              ref={(c) => {
                this._carousel = c;
              }}
              data={homeData.recommended_classes?.list || []}
              renderItem={this._renderOffers}
              inactiveSlideScale={1}
              inactiveSlideOpacity={1}
              loop
              autoplay
              sliderWidth={width - moderateScale(32)}
              itemWidth={width - moderateScale(32)}
            />
            <View style={{height: 20}} />
          </View>
        </ScrollView>
        <Modal visible={searchVisbile} onRequestClose={this.closeSearch}>
          <SearhScreen onClose={this.closeSearch} />
        </Modal>
      </GradientWrapper>
    );
  }
}

const mapStateToProps = (state) => ({
  userData: state.auth.userData,
  favCoaches: state.coaches.favCoaches,
  favCaochLoading: state.coaches.favLoading,
});

export default connect(mapStateToProps)(Home);

const styles = StyleSheet.create({
  typeBadge: {
    ...commonStyles.shadowStyle,
    elevation: 3,
    borderRadius: 4,
    borderColor: colors.transparent,
    borderWidth: 0,
    alignSelf: 'flex-start',
    paddingVertical: 12,
    flex: 1,
    paddingHorizontal: moderateScale(18),
  },
  badgeText: {
    ...commonStyles.fontSize14,
    color: colors.textGrey,
    fontFamily: fontFamily.bold,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  scroll: {
    flex: 1,
    backgroundColor: colors.white,
    paddingHorizontal: moderateScale(16),
  },
  favContainer: {
    marginTop: moderateScaleVertical(8),
    marginBottom: moderateScaleVertical(24),
  },
  tryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // marginBottom: moderateScale(16),
  },
  btnRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: moderateScale(16),
  },
  logo: {
    marginTop: moderateScaleVertical(20),
    marginBottom: 25,
    alignItems: 'center',
  },
  btnContainer: {
    backgroundColor: colors.white,
    paddingTop: 16,
    paddingBottom: 10,
  },
  favTextContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: moderateScale(16),
  },
  upcomingContainer: {
    marginTop: moderateScaleVertical(24),
    marginBottom: moderateScaleVertical(16),
  },
});
