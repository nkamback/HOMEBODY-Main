import React, {useState, useEffect} from 'react';
import {View, Text, Image, TextInput} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {useSelector} from 'react-redux';
import {AirbnbRating} from 'react-native-ratings';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import WrapperContainer from '../../components/WrapperContainer';
import {exerciseImg} from '../../constants/constants';
import actions from '../../redux/actions';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import {showError} from '../../utils/helperFunctions';
import Orientation from 'react-native-orientation';

export default function Ratings({navigation, route}) {
  const [state, setState] = useState({
    review: '',
    rating: 0,
    isLoading: false,
  });
  const userData = useSelector((state) => state.auth.userData);
  const {data = {}} = route.params || {};
  const {coach = {}} = data;
  const _onFinishRating = (rating) => {
    console.log(rating, 'the rating has a value let see');
    setState((state) => ({...state, rating}));
  };

  useEffect(() => {
    Orientation.lockToPortrait();
    setTimeout(()=>{
      Orientation.lockToPortrait();
    },2000);
   
  }, []);

  const onSubmitRating = () => {
    const {rating, review} = state;
    if (!rating) {
      showError(`Please provide rating`);
      return;
    }
    setState((state) => ({...state, isLoading: true}));
    actions
      .rateClassCoach({
        class_id: data.id,
        rating: '' + rating,
        feedback: review,
      })
      .then((res) => {
        navigation.popToTop();
        
        setState((state) => ({...state, isLoading: false}));
        return;
      })
      .catch((error) => {
        setState((state) => ({...state, isLoading: false}));
        showError(error.message);
      });
  };

  console.log(data, 'the data vlue');

  return (
    <GradientWrapper isLoading={state.isLoading}>
      <HeaderWithCenterTextBack
        onPressLeft={() => {
          navigation.goBack();
          Orientation.lockToPortrait();
        }}
        hideLeft={false}
        centerText="Rating"
      />
      <KeyboardAwareScrollView style={{flex: 1, backgroundColor: colors.white}}>
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 25,
          }}>
          <Image
            source={{uri: coach.avatar?.thumb_path || exerciseImg}}
            style={{height: 100, width: 100, borderRadius: 50}}
          />
          <Text style={{...commonStyles.fontSize16, textAlign: 'center'}}>
            {coach.name}
          </Text>
        </View>
        <View style={{marginVertical: 12}}>
          <Text
            style={{
              ...commonStyles.fontSize24,
              color: colors.blackOpacity25,
              textAlign: 'center',
            }}>
            Great Work!
          </Text>
        </View>

        <Text
          style={{
            ...commonStyles.fontSize20,
            textAlign: 'center',
            color: colors.greenBlack,
            marginBottom: moderateScaleVertical(20),
          }}>
          {userData.name}, How was your class?
        </Text>

        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <AirbnbRating
            count={5}
            reviews={[]}
            showRating={false}
            defaultRating={-1}
            size={40}
            onFinishRating={_onFinishRating}
          />
        </View>

        <View style={{marginTop: 20}}>
          <TextInput
            style={{
              height: 100,
              paddingHorizontal: 10,
              textAlignVertical: 'top',
              backgroundColor: colors.blackOpacity10,
              marginHorizontal: moderateScale(16),
            }}
            multiline={true}
            onChangeText={(review) => setState({...state, review})}
            blurOnSubmit
          />
        </View>
      </KeyboardAwareScrollView>
      <View
        style={{
          backgroundColor: colors.white,
          paddingHorizontal: moderateScale(16),
        }}>
        <ButtonWithLoader
          onPress={onSubmitRating}
          btnStyle={{backgroundColor: colors.themeMain, marginBottom: 10}}
          btnTextStyle={{color: colors.white}}
          btnText={'Submit'}
        />
      </View>
    </GradientWrapper>
  );
}
