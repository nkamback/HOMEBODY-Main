import React, {Component} from 'react';
import {Text, View, FlatList} from 'react-native';
import NotificationCard from '../../components/NotificationCard';
import GradientWrapper from '../../components/GradientWrapper';
import colors from '../../styles/colors';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import {moderateScale} from '../../styles/responsiveSize';
import actions from '../../redux/actions';
import {showError,getMinimalisticRelativeTime} from '../../utils/helperFunctions';
import ListEmptyComponent from '../../components/ListEmptyComponent';
import moment from "moment";

export default class Notifications extends Component {
  state = {
    isLoading: true,
    notifications: [],
  };

  componentDidMount() {
    actions
      .getNotifications(``)
      .then((res) => {
        console.log(res, 'the response value');
        this.setState({
          isLoading: false,
          notifications: res?.data?.notifications,
        });
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  }
  renderItem = ({item, index}) => {
    console.log(moment(item.created_at).format('DD MM YYYY'));
    return (
      <NotificationCard
        text={item?.data?.message}
        title={item?.data?.title}
        time={getMinimalisticRelativeTime(item.created_at)}
      />
    );
  };
  render() {
    const {isLoading, notifications} = this.state;
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Notifications" />
        <View style={{flex: 1, backgroundColor: colors.white}}>
          <View style={{height: 20}} />
          <FlatList
            data={notifications}
            keyExtractor={(item, index) => String(index)}
            renderItem={this.renderItem}
            ListEmptyComponent={!isLoading && <ListEmptyComponent />}
            style={{paddingHorizontal: moderateScale(16)}}
          />
        </View>
      </GradientWrapper>
    );
  }
}
