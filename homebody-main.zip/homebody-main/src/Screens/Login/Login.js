import React, {Component} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  Platform,
  TextInput
} from 'react-native';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import {LoginManager} from 'react-native-fbsdk';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import { FilledTextField,OutlinedTextField,} from 'react-native-material-textfield';
import colors from '../../styles/colors';
import imagePath from '../../constants/imagePath';
import TextOverLine from '../../components/TextOverLine';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import validations from '../../utils/validations';
import {showError} from '../../utils/helperFunctions';
import Loader from '../../components/Loader';
import actions from '../../redux/actions';
import {fbLogin} from '../../constants/socialLogin';
import {SOCIAL_LOGIN_TYPE} from '../../constants/constants';
import GradientButton from '../../components/GradientButton';
import GradientWrapper from '../../components/GradientWrapper';
import BorderTextInput from '../../components/BorderTextInput';

class Login extends Component {
  state = {
    emailMobile: '',
    password: '',
    isLoading: false,
    isPasswordVisible:false
  };
  onChangeText = (key) => (val) => {
    this.setState({[key]: val});
  };
  isValidData = () => {
    const {emailMobile, password} = this.state;
    const error = validations({emailMobile, password});
    if (error) {
      showError(error);
      return false;
    }
    return true;
  };
  onSubmit = () => {};
  onFbLogin = () => {
    fbLogin(this._responseInfoCallback);
  };

  _responseInfoCallback = async (error, result) => {
    // return;

    if (error) {
      alert(error.message);
      return;
    } else {
      const userData = JSON.parse(JSON.stringify(result));
      if (!userData.email) {
        alert('Email is required');
        return;
      }
      console.log(userData);
      this.setState({isLoading: true});
      try {
        const checkUser = await actions.socialLogin({
          social_id: userData.id,
          social_type: SOCIAL_LOGIN_TYPE.FB,
          email: userData.email,
        });
        console.log(checkUser, 'the acheck ');
        if (checkUser.data.is_user_exist) {
          this.onUserAlreadyExist(checkUser.data.user);
          return;
        } else {
          alert(strings.PLS_SIGNUP_FIRST);
        }
        this.setState({isLoading: false});
      } catch (error) {
        this.setState({isLoading: false});
        showError(error.message);
      }
    }
    LoginManager.logOut();
  };

  onUserAlreadyExist = (user) => {
    console.log(user, 'hte user fvlau aleradojodjoj');

    this.setState({isLoading: false});

    // this.props.navigation.navigate('HomeStack');
  };

  onLogin = () => {
    const checkValid = this.isValidData();
    if (checkValid) {
      this.setState({isLoading: true});
      const {emailMobile, password} = this.state;
      actions
        .login({
          username: emailMobile,
          password,
          device_type: Platform.OS,
          device_token: '1234',
        })
        .then((res) => {
          this.setState({isLoading: false});
          console.log(res, 'the respone i get is as follow');
        })
        .catch((error) => {
          this.setState({isLoading: false});
          showError(error.message);
        });
    }
    // this.props.navigation.navigate('tab')
  };
  _onForgot = () => {
    this.props.navigation.navigate('forgotPassword');
  };
  render() {
    const {isLoading, emailMobile, password,isPasswordVisible} = this.state;
    return (
      <GradientWrapper colorsBg={[colors.gradientA,colors.gradientB]}>
        <KeyboardAwareScrollView
          style={{flex: 1, paddingHorizontal: moderateScale(16)}}>
          <View
            style={{
              marginVertical: moderateScaleVertical(24),
              alignItems: 'flex-start',
            }}>
            <TouchableOpacity
              hitSlop={hitSlopProp}
              onPress={() => this.props.navigation.goBack(null)}
              activeOpacity={0.7}>
              <Image
                style={{tintColor: colors.white}}
                source={imagePath.backblack}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              // flexDirection: 'row',
              alignItems: 'center',
              marginBottom: moderateScaleVertical(56),
            }}>
            <Image
              style={{height: 25, width: 200}}
              resizeMode="contain"
              source={imagePath.logoWhite}
            />
          </View>

          <Text
            style={{
              ...commonStyles.fontSize24,
              fontSize:textScale(28),
              color: colors.white,
              marginBottom: 20,
            }}>
            Welcome back!
          </Text>
          <BorderTextInput
              placeholder={"Email/Mobile Number"}
              onChangeText={this.onChangeText('emailMobile')}
              leftIcon={imagePath.emailSmall}
              value={emailMobile}  
          />
          <BorderTextInput
              placeholder={"Password"}
              onChangeText={this.onChangeText('password')}
              leftIcon={imagePath.lock}
              secureTextEntry={!isPasswordVisible}
              rightIcon={isPasswordVisible?imagePath.eyeClosed:imagePath.eyeOpen}
              withRef
              onPressRight={()=>this.setState({isPasswordVisible:!isPasswordVisible})}
              value={password}  
          />
       
          <View style={{alignItems: 'center'}}>
            <Text
              onPress={this._onForgot}
              style={{
                ...commonStyles.fontSize16,
                color: colors.white,
                paddingHorizontal: 10,
                marginVertical: 10,
              }}>
              Forgot your Password?
            </Text>
          </View>

          <ButtonWithLoader
            onPress={this.onLogin}
            btnStyle={{
              marginVertical: moderateScaleVertical(32),
              backgroundColor: colors.white26,
              borderColor: colors.white26,
            }}
            btnText="Log in"
          />

          <TouchableOpacity
            onPress={this.onFbLogin}
            style={{
              ...commonStyles.buttonRect,
              backgroundColor: colors.fbBlue,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              borderColor: colors.fbBlue,
              borderRadius:6,
              marginBottom: 0,
            }}>
            <Image style={{marginRight:20}} source={imagePath.fbWhite} />
            <Text
              style={{
                marginLeft: 10,
                ...commonStyles.fontSize16,
                color: colors.white,
                borderColor: colors.fbBlue,
                
              }}>
              Continue with Facebook
            </Text>
          </TouchableOpacity>
          <Loader isLoading={isLoading} />
        </KeyboardAwareScrollView>
      </GradientWrapper>
    );
  }
}

export default Login;
