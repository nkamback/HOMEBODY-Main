import React, {Component} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Image,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScaleVertical,
  moderateScale,
  textScale,
} from '../../styles/responsiveSize';
import TextInputWithLable from '../../components/TextInputWithLabel';
import colors from '../../styles/colors';
import fontFamily from '../../styles/fontFamily';
import CountryPicker, {Flag} from 'react-native-country-picker-modal';
import validations from '../../utils/validations';
import AsyncStorage from '@react-native-community/async-storage';
import {showMessage} from 'react-native-flash-message';
import actions from '../../redux/actions';
import imagePath from '../../constants/imagePath';
import strings from '../../constants/lang';
import WrapperContainer from '../../components/WrapperContainer';
import Loader from '../../components/Loader';
import {showError} from '../../utils/helperFunctions';
import GradientButton from '../../components/GradientButton';
import GradientWrapper from '../../components/GradientWrapper';
import BorderTextInput from '../../components/BorderTextInput';

class EnterMobile extends Component {
  state = {
    phoneNumber: '',
    countryPickerModalVisible: false,
    callingCode: '1',
    cca2: 'US',
    isLoading: false,
    id: '',
  };
  onChange = (text) => {
    text = text.replace(/[^0-9]/g, '');
    this.setState({phoneNumber: text});
  };
  countryChange = ({callingCode, cca2}) => {
    console.log(callingCode, 'thehoahsdo');
    this.setState({callingCode: callingCode[0], cca2});
  };

  openCountryPickerModal = () => {
    this.setState({countryPickerModalVisible: true});
  };
  onCountryPickerModalClose = () => {
    this.setState({countryPickerModalVisible: false});
  };
  isValidData = (data) => {
    const error = validations(data);
    if (error) {
      showMessage({
        type: 'danger',
        icon: 'danger',
        message: error,
      });

      return false;
    }
    return true;
  };

  onMobileEnter = async () => {
    const {phoneNumber, callingCode} = this.state;
    const checkValid = this.isValidData({phoneNumber});
    if (checkValid) {
      const {params} = this.props.route;
      this.setState({isLoading: true});
      actions
        .signup({
          name: params.firstName,
          email: params.email,
          password: params.password,
          phone: phoneNumber,
          phone_code: callingCode,
          device_token: '1333',
          device_type: Platform.OS,
        })
        .then((res) => {
          this.setState({isLoading: false});
          this.props.navigation.navigate('otpVerify', {user: res.data?.user});
        })
        .catch((error) => {
          this.setState({isLoading: false});
          showError(error.msg || error.message);
        });

      return;
    }
    return;
    this.props.navigation.navigate('otpVerify');

    const {} = this.state;
    if (this.isValidData({phoneNumber: phoneNumber})) {
      const provider = this.props.navigation.getParam('provider');
      if (provider && provider === 'social') {
        const apiData = this.props.navigation.getParam('apiData');
        apiData.phone_number = phoneNumber;
        apiData.phone_code = callingCode;
        if (this.state.id !== '') {
          apiData.user_id = this.state.id;
        }
        console.log(apiData, 'hte apjfaojsof');
        this.setState({isLoading: true});
        actions
          .updateUserPhone(apiData)
          .then((res) => {
            console.log(res, 'the user data response update phione');
            this.setState({id: apiData.user_id, isLoading: false});
            this.props.navigation.navigate('otpVerification', {
              id: apiData.user_id,
              phoneNumber: phoneNumber,
              callingCode: callingCode,
            });
          })
          .catch((error) => {
            this.setState({isLoading: false});
            // console.log(error,'hhth error i get is as follow')
            showMessage({
              type: 'danger',
              icon: 'danger',
              message: error.message
                ? error.message
                : error.error || 'Network error',
            });
          });
        return;
      }
      let fcmToken = await AsyncStorage.getItem('fcmToken');
      const signupData = this.props.navigation.getParam('signupData');
      const apiData = {
        first_name: signupData.firstName,
        last_name: signupData.lastName,
        email: signupData.email,
        password: signupData.password,
        phone: phoneNumber,
        phone_code: callingCode,
        device_token: fcmToken ? fcmToken : '',
        device_type: Platform.OS,
      };
      if (this.state.id !== '') {
        apiData.user_id = this.state.id;
      }
      console.log(apiData, 'the apidojoij');
      this.setState({isLoading: true});
      actions
        .signup(apiData)
        .then((res) => {
          console.log(res, 'the resoponse');
          this.setState({
            isLoading: false,
            id: res.user_detail ? res.user_detail.id : '',
          });
          this.props.navigation.navigate('otpVerification', {
            id: res.user_detail ? res.user_detail.id : '',
            phoneNumber: phoneNumber,
            callingCode: callingCode,
          });
        })
        .catch((error) => {
          this.setState({isLoading: false});
          showMessage({
            type: 'danger',
            icon: 'danger',
            message: error.message ? error.message : error.error,
          });
        });
    }
  };

  render() {
    const {
      phoneNumber,
      countryPickerModalVisible,
      callingCode,
      cca2,
      isLoading,
    } = this.state;
    console.log(this.state);

    return (
      <GradientWrapper
        colorsBg={[colors.gradientA, colors.gradientB]}
        pointerEvents={isLoading ? 'none' : 'auto'}
        style={{flex: 1}}>
        <ScrollView showsVerticalScrollIndicator={false} style={{flex: 1}}>
          <View style={{marginHorizontal: moderateScale(24)}}>
            <View style={styles.backContainer}>
              <TouchableOpacity
                onPress={() => this.props.navigation.goBack(null)}
                hitSlop={{top: 12, bottom: 12, right: 12, left: 12}}>
                <Image style={{tintColor:colors.white}} source={imagePath.backblack} />
              </TouchableOpacity>
            </View>
            <View style={{marginBottom: moderateScaleVertical(27)}}>
              <Text
                style={[
                  commonStyles.fontBold24,
                  {
                    color: colors.white,
                    fontFamily: fontFamily.regular,
                    fontSize: textScale(28),
                  },
                ]}>
                Enter your phone number
              </Text>
              <View style={{marginTop: moderateScaleVertical(8)}}>
                {/* <Text style={{...commonStyles.fontSize14, color: colors.grey}}>
                  {strings.ENTER_YOUR_TEN_DIGIT_MOBILE}
                </Text> */}
              </View>
            </View>
            <View
              style={{
                borderWidth: 1.5,
                borderColor: colors.white26,
                borderRadius: 5,
                flexDirection: 'row',
                height: 56,
                paddingVertical: 4,
                paddingHorizontal: 4,
              }}>
              <TouchableOpacity
                style={{minWidth: 120}}
                onPress={this.openCountryPickerModal}>
                {/* <Text
                    style={{
                      ...commonStyles.fontSize14,
                      color: colors.black,
                      marginBottom: moderateScaleVertical(8),
                    }}>
                    {strings.COUNTRY}
                  </Text> */}
                <View
                  style={{
                    ...styles.countryPickerInput,
                    alignItems: 'center',
                    flexDirection: 'row',
                    justifyContent: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: moderateScaleVertical(15.5),
                      color: colors.white,
                      fontFamily: fontFamily.regular,
                    }}>
                    +{callingCode}
                  </Text>
                  <View style={{marginLeft: 15, padding: 0}}>
                    <Flag flagSize={18} countryCode={cca2} />
                  </View>
                  <Image
                    style={{marginLeft: 10}}
                    source={imagePath.downArrowSmall}
                  />
                </View>
              </TouchableOpacity>

              <View
                style={{
                  flex: 1,
                  borderLeftWidth: 1,
                  borderLeftColor: colors.whiteOpacity10,
                  marginLeft: moderateScaleVertical(6),
                }}>
                <TextInput
                  placeholder={'Phone Number'}
                  keyboardType="numeric"
                  selectionColor={colors.white}
                  maxLength={15}
                  placeholderTextColor={colors.white}
                  style={{
                    ...commonStyles.fontSize15,
                    color: colors.white,
                    flex: 1,
                    paddingTop: 0,
                    paddingBottom: 0,
                  }}
                  onChangeText={this.onChange}
                  value={phoneNumber}
                />
              </View>
            </View>
            <View style={{marginTop: moderateScaleVertical(70)}}>
              <TouchableOpacity
                onPress={this.onMobileEnter}
                style={[commonStyles.buttonRect,{backgroundColor:colors.white26,borderColor:colors.white26}]}>
                {isLoading ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <Text style={commonStyles.buttonTextWhite}>
                    {strings.CONTINUE}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
        {countryPickerModalVisible && (
          <CountryPicker
            cca2={cca2}
            visible={countryPickerModalVisible}
            withFlagButton={false}
            withFilter
            onClose={this.onCountryPickerModalClose}
            onSelect={this.countryChange}
          />
        )}
        {/* <Loader isLoading={isLoading} /> */}
      </GradientWrapper>
    );
  }
}

export default EnterMobile;

const styles = StyleSheet.create({
  backContainer: {
    marginTop: moderateScaleVertical(36),
    marginBottom: moderateScaleVertical(24),
  },
  countryPickerInput: {
    height: moderateScaleVertical(48),
    borderColor: colors.textInputBorderColor,
    paddingVertical: 0,
    textAlignVertical: 'center',
  },
});
