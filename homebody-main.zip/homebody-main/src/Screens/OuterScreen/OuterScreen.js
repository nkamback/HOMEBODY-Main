import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  TouchableOpacity,
  Pressable,
  ImageBackground,
  StatusBar,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import colors from '../../styles/colors';
import imagePath from '../../constants/imagePath';
import {
  moderateScaleVertical,
  width,
  moderateScale,
} from '../../styles/responsiveSize';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import GradientWrapper from '../../components/GradientWrapper';

export default function OuterScreen({navigation}) {
  const insets = useSafeAreaInsets();
  const moveToScreen = (screenName) => () => {
    navigation.navigate(screenName);
  };
  return (
    <ImageBackground
      style={{height: '100%', width: '100%'}}
      source={imagePath.outer}>
      <StatusBar
        backgroundColor={colors.transparent}
        translucent
        barStyle="light-content"
      />
      <SafeAreaView style={{flex: 1}}>
        <View style={{flex: 1, justifyContent: 'flex-end'}}>
          <View
            style={{
              marginLeft: moderateScale(16),
              marginVertical: moderateScaleVertical(40),
            }}>
            <Image source={imagePath.logoWhiteBig} />
          </View>

          <View style={{paddingHorizontal: moderateScale(16)}}>
            <Text
              style={{
                ...commonStyles.fontSize14,
                color: colors.white,
                // textAlign: 'center',
                marginBottom: moderateScaleVertical(50),
              }}>
              Welcome to HOMEBODY. where you can access live workouts with your
              favorite worldclass instructors in all health & wellness
              categories. Create an account to get started.
            </Text>
            <ButtonWithLoader
              btnStyle={{
                backgroundColor: colors.white26,
                borderColor: colors.white26,
              }}
              onPress={moveToScreen('signup')}
              btnText="Create your free account"
            />
          </View>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              paddingVertical: 10,
              flexDirection: 'row',
            }}>
            <Text
              style={{
                ...commonStyles.fontSize14,
                color: colors.white,
                marginTop: 10,
              }}>
              Already have an account?
            </Text>
            <TouchableOpacity
              hitSlop={hitSlopProp}
              onPress={moveToScreen('login')}
              style={{marginLeft: 5}}>
              <Text
                style={{
                  ...commonStyles.fontSize14,
                  color: colors.progressblue,
                  marginTop: 10,
                }}>
                Login
              </Text>
            </TouchableOpacity>
            <View style={{height: insets.bottom + 10}} />
          </View>
        </View>
        <View style={{height: 50}} />
      </SafeAreaView>
    </ImageBackground>
  );
}
