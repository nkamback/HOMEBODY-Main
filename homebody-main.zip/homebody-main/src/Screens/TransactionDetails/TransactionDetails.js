import React, {Component} from 'react';
import {Text, View, Image} from 'react-native';
import WrapperContainer from '../../components/WrapperContainer';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import GradientWrapper from '../../components/GradientWrapper';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import {exerciseImg} from '../../constants/constants';
import ListItemHorizontal from '../../components/ListItemHorizontal';
import fontFamily from '../../styles/fontFamily';

export default class TransactionDetails extends Component {


  render() {
    const {data={}}=this.props.route?.params||{};
    return (
      <GradientWrapper  start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }}>
        <HeaderWithCenterTextBack centerText="Transaction Details" />
        <View
          style={{
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <Text
            style={{
              ...commonStyles.fontSize14,
              color: colors.blackOpacity50,
              marginVertical: 10,
            }}>
            {/* 27 May 2020 at 12:35pm */}
          </Text>
          <View style={{flexDirection: 'row'}}>
            <Image
              source={{uri:data?.class?.banner_image|| exerciseImg}}
              style={{
                height: moderateScaleVertical(104),
                width: moderateScaleVertical(104),
                marginRight: moderateScale(16),
                borderRadius: 4,
              }}
            />
            <View style={{justifyContent: 'space-between'}}>
              <View>
                <Text style={commonStyles.headingText}>{data?.class?.name}</Text>
                <Text
                  style={{
                    ...commonStyles.fontSize14,
                    color: colors.blackOpacity40,
                  }}>
                  
                </Text>
              </View>
              <View>
                <Text style={{...commonStyles.fontSize15, color: colors.black}}>
                  Class ID: {data?.class?.id}
                </Text>
                <Text
                  style={{
                    ...commonStyles.fontSize14,
                    color: colors.blackOpacity40,
                  }}>
                  Payment method: Card
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={{flex: 1, backgroundColor: colors.white}}>
          <View
            style={{
              backgroundColor: colors.blackImgOverlay,
              height: 2,
              marginVertical: 20,
            }}
          />
          <View style={{paddingHorizontal: moderateScale(16)}}>
            <Text style={commonStyles.headingText}>Reciept</Text>
            <View style={{marginTop: moderateScaleVertical(15)}}>
              <ListItemHorizontal
                continerStyle={{justifyContent: 'space-between'}}
                label="Live Session Fee"
                labelStyle={{color: colors.blackOpacity70}}
                valueStyle={{color: colors.blackOpacity70}}
                value={`$${data?.amount||""}`}
              />
              <ListItemHorizontal
                continerStyle={{justifyContent: 'space-between'}}
                label="Tax"
                labelStyle={{color: colors.blackOpacity70}}
                valueStyle={{color: colors.blackOpacity70}}
                value={`$${data?.tax||"0"}`}
              />
              <ListItemHorizontal
                continerStyle={{justifyContent: 'space-between'}}
                label="Total"
                labelStyle={{
                  color: colors.blackOpacity70,
                  fontFamily: fontFamily.bold,
                }}
                valueStyle={{
                  color: colors.blackOpacity70,
                  fontFamily: fontFamily.bold,
                }}
                value={`$${data?.total||"0"}`}
              />
            </View>
            <Text
              style={{
                marginTop: 20,
                ...commonStyles.fontSize12,
                color: colors.blackOpacity40,
              }}>
              Payment Through
            </Text>
            <Text
              style={{
                marginTop: moderateScaleVertical(8),
                ...commonStyles.fontSize15,
                color: colors.gradientB,
              }}>
              CARD
            </Text>
          </View>
          <View
            style={{
              backgroundColor: colors.blackImgOverlay,
              height: 2,
              marginVertical: 15,
            }}
          />
          <Text
            style={{
              ...commonStyles.fontSize14,
              marginTop: 15,
              paddingHorizontal: moderateScale(16),
            }}>
            
          </Text>
        </View>
      </GradientWrapper>
    );
  }
}
