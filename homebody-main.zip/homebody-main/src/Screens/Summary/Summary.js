import React, {Component} from 'react';
import {
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';
import stripe from 'tipsi-stripe';
import moment from 'moment';
import GradientWrapper from '../../components/GradientWrapper';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import Card from '../../components/Card';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import fontFamily from '../../styles/fontFamily';
import ListItemHorizontal from '../../components/ListItemHorizontal';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import actions from '../../redux/actions';
import {showError, showSuccess} from '../../utils/helperFunctions';
import {STRIPE_KEY} from '../../constants/constants';
import GradientButton from '../../components/GradientButton';
stripe.setOptions({
  publishableKey: STRIPE_KEY,
});
export default class Classes extends Component {
  state = {
    isLoading: true,
    paymentDetails: {},
  };

  componentDidMount() {
    const {params = {}} = this.props.route;

    actions
      .bookingDetails({
        class_id: params?.data?.id,
      })
      .then((res) => {
        this.setState({
          paymentDetails: res.data?.billing_details,
          isLoading: false,
        });
      })
      .catch(this.errorMethod);
  }
  errorMethod = (error) => {
    this.setState({isLoading: false});
    showError(error.message);
  };

  onPressBooking = async (screenName, data = {}) => {
    try {
      const payData = await stripe.paymentRequestWithCardForm();

      this.setState({isLoading: true});
      actions
        .saveCard({
          card_token: payData.tokenId,
          is_default: true,
        })
        .then((res) => {
          const {params = {}} = this.props.route;
          const {selectedDateUTC, data} = params || {};
          console.log(payData);
          // alert(moment(selectedDateUTC).format("YYYY-MM-DD"));
          // return;
          let extraData = {};
          if (data.type !== 'one_time') {
            extraData.date = moment(selectedDateUTC).format('YYYY-MM-DD');
          }
          actions
            .bookClass({
              class_id: params?.data?.id,
              card_id: payData?.card?.cardId || '',
              ...extraData,
            })
            .then((res) => {
              console.log(res, 'the result value');
              showSuccess('Class booked successfully');
              this.props.navigation.navigate('home')
              // this.props.navigation.popToTop();
              this.setState({isLoading: false});
            })
            .catch(this.errorMethod);
        })
        .catch(this.errorMethod);
    } catch (error) {}

    return;
    this.setState({isLoading: true});

    // alert('comming soon');
    return;
    this.props.navigation.navigate(screenName, data);
  };
  render() {
    const {params = {}} = this.props.route;
    const {data = {}} = params;
    const {paymentDetails, isLoading} = this.state;
    console.log(data,'the data has a specific value')
    return (
      <GradientWrapper
        start={{x: 0, y: 1}}
        end={{x: 1, y: 1}}
        isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Summary" />
        <View style={{flex: 1, backgroundColor: colors.white}}>
          <ScrollView
            style={{
              flex: 1,
              backgroundColor: colors.white,
              paddingTop: moderateScale(16),
            }}>
            <View style={{paddingHorizontal: moderateScale(16)}}>
              <Text
                style={{
                  ...commonStyles.fontSize15,
                  color: colors.blackOpacity40,
                }}>
                You’re about to book
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingBottom: 10,
                  borderBottomColor: colors.borderLight,
                  borderBottomWidth: 0.7,
                }}>
                <Text
                  style={{
                    ...commonStyles.fontSize20,
                    fontFamily: fontFamily.bold,
                    color: colors.blackOpacity90,
                  }}>
                  {data.name}
                </Text>
                <Text
                  style={{
                    ...commonStyles.fontBold16,
                    color: colors.blackOpacity60,
                  }}>
                  {paymentDetails?.total_details?.price}
                </Text>
              </View>
              <View
                style={{
                  marginTop: moderateScaleVertical(10),
                  paddingHorizontal: moderateScale(16),
                  borderWidth: 0.7,
                  borderColor: colors.borderLight,
                  borderRadius: 4,
                  paddingVertical: 10,
                }}>
                <ListItemHorizontal
                  continerStyle={{flexDirection: 'column'}}
                  labelStyle={{...commonStyles.fontBold16}}
                  valueStyle={{marginLeft: 0}}
                  label="Instructor "
                  value={data.name}
                  disabled={false}
                  onPress={()=>this.props.navigation.navigate('coachDetails',{data:data.coach})}
                />
                <ListItemHorizontal
                  continerStyle={{flexDirection: 'column'}}
                  labelStyle={{...commonStyles.fontBold16}}
                  valueStyle={{marginLeft: 0}}
                  label="Activity"
                  value={data.activity}
                />
                <ListItemHorizontal
                  continerStyle={{flexDirection: 'column'}}
                  labelStyle={{...commonStyles.fontBold16}}
                  valueStyle={{marginLeft: 0}}
                  label="Body Focus "
                  value={data.body_focus}
                />
              </View>
            </View>
            <View
              style={{
                marginVertical: moderateScaleVertical(20),
                backgroundColor: colors.lightestGrey,
                height: 4,
              }}
            />
            <View style={{paddingHorizontal: moderateScale(16)}}>
              <Text
                style={{
                  ...commonStyles.headingText,
                  fontFamily: fontFamily.bold,
                  marginBottom: moderateScaleVertical(16),
                }}>
                You Pay
              </Text>
              <View
                style={{
                  paddingBottom: 10,
                  borderBottomColor: colors.borderLight,
                  borderBottomWidth: 0.7,
                }}>
                <ListItemHorizontal
                  continerStyle={{justifyContent: 'space-between'}}
                  labelStyle={{color: colors.blackOpacity40}}
                  valueStyle={{marginLeft: 0}}
                  label="Live Session Fee"
                  value={
                    !!paymentDetails.fee_details &&
                    paymentDetails?.fee_details[0]?.price
                  }
                />
                <ListItemHorizontal
                  continerStyle={{justifyContent: 'space-between'}}
                  labelStyle={{color: colors.blackOpacity40}}
                  valueStyle={{marginLeft: 0}}
                  label="Tax"
                  value={
                    !!paymentDetails.fee_details &&
                    paymentDetails.fee_details[1]?.price
                  }
                />
              </View>
              <ListItemHorizontal
                continerStyle={{
                  justifyContent: 'space-between',
                  marginTop: moderateScaleVertical(15),
                }}
                labelStyle={{
                  marginLeft: 0,
                  fontFamily: fontFamily.medium,
                  color: colors.black,
                }}
                valueStyle={{
                  marginLeft: 0,
                  fontFamily: fontFamily.medium,
                  color: colors.black,
                }}
                label="Total"
                value={paymentDetails?.total_details?.price}
              />
            </View>
            <View
            style={{
              marginTop: 20,
              marginHorizontal: moderateScale(16),
            }}>
            <GradientButton
            colorsArray={[colors.btnBlue,colors.btnBlueB]}
              btnText="Continue"
              onPress={this.onPressBooking}
              btnStyle={{borderRadius: 4}}
            />
          </View>
          </ScrollView>
         
        </View>
      </GradientWrapper>
    );
  }
}
