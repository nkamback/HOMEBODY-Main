import React, {Component} from 'react';
import {Text, View} from 'react-native';
import WrapperContainer from '../../components/WrapperContainer';
import {OutlinedTextField} from 'react-native-material-textfield';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import TextInputWithLabel from '../../components/TextInputWithLabel';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import validations from '../../utils/validations';
import {showError, showSuccess} from '../../utils/helperFunctions';
import actions from '../../redux/actions';
import GradientButton from '../../components/GradientButton';

export default class ContactUs extends Component {
  state = {
    name: '',
    email: '',
    message: '',
    isLoading: false,
  };

  _onChangeText = (key) => (val) => {
    this.setState({[key]: val});
  };

  _isValidData = (data) => {
    let {name, email, message} = data;
    name = name.trim();
    email = email.trim();
    message = message.trim();
    if (!name) {
      showError(`Please enter your name`);
      return;
    }
    const emailError = validations({email});
    if (emailError) {
      showError(emailError);
      return;
    }

    if (!message) {
      showError('Please enter your message');
      return;
    }
    return true;
  };

  _onContactUs = () => {
    const {name, email, message} = this.state;
    const checkValid = this._isValidData({name, email, message});
    if (!checkValid) {
      return;
    }
    this.setState({isLoading: true});
    actions
      .contactUs({name, email, message})
      .then((res) => {
        this.setState({isLoading: false});
        console.log(res);
        showSuccess('Your request has been received.Thank you');
        this.props.navigation.popToTop();
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  };
  render() {
    const {isLoading, name, email, message} = this.state;
    return (
      <GradientWrapper
        start={{x: 0, y: 1}}
        end={{x: 1, y: 1}}
        isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Contact Us" />
        <View
          style={{
            flex: 1,
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <Text
            style={{
              ...commonStyles.fontSize14,
              marginVertical: 10,
              color: colors.blackOpacity70,
            }}>
            You can connect with admin through mail.
          </Text>
          <TextInputWithLabel
            value={name}
            onChangeText={this._onChangeText('name')}
            label="Name"
          />
          <TextInputWithLabel
            value={email}
            onChangeText={this._onChangeText('email')}
            label="Email"
            keyboardType="email-address"
          />

          <TextInputWithLabel
            label="Message"
            multiline={true}
            value={message}
            onChangeText={this._onChangeText('message')}
            blurOnSubmit={true}
            inputStyle={{
              height: moderateScaleVertical(112),
              textAlignVertical: 'top',
            }}
          />
          <View style={{marginTop: moderateScaleVertical(48)}}>
            <GradientButton
             colorsArray={[colors.btnBlue,colors.btnBlueB]}
              onPress={this._onContactUs}
              btnStyle={{borderRadius: 4}}
              btnText="Send Message"
            />
          </View>
        </View>
      </GradientWrapper>
    );
  }
}
