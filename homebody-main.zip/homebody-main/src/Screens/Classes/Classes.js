import React, {Component} from 'react';
import {Text, View, FlatList, TouchableOpacity, Image} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import Card from '../../components/Card';
import {moderateScale} from '../../styles/responsiveSize';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';
import moment from 'moment';
import ListEmptyComponent from '../../components/ListEmptyComponent';
export default class Classes extends Component {
  state = {
    classArray: [],
    isLoading: true,
    daysToAdd: 1,
    dateToShow: moment().format('DD MMM'),
  };

  componentDidMount() {
    const {activeTab = 0, selectedDateObj, sliderValues} =
      this.props.route?.params || {};
    let query = '';
    if (activeTab == 0) {
      query = `?type=fitness`;
    } else if (activeTab == 1) {
      query = `?type=wellness`;
    } else {
      query = `?type=one_on_one`;
    }
    if (!!selectedDateObj) {
      const {obj, apiDate} = selectedDateObj;
      let startDateTime = moment().utc();
      let endDateTime = moment().endOf('day').utc();
      // alert(apiDate,'hte api date');
      let dateTimeQuery = `&start_date=${startDateTime.format(
        'YYYY-MM-DD',
      )}&start_time=${startDateTime.format(
        'HH:mm',
      )}&end_time=${endDateTime.format('HH:mm')}&end_date=${endDateTime.format(
        'YYYY-MM-DD',
      )}`;

      query += dateTimeQuery;
    }
    // alert(query);
    actions
      .getClassesList(query)
      .then((res) => {
        this.setState({
          classArray: res.data?.classes || [],
          isLoading: false,
        });
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  }
  _renderClass = ({item, index}) => {
    const {daysToAdd} = this.state;
    const {selectedDateObj} = this.props.route?.params || {};
    let startDateTimeForApi;
    if (!!selectedDateObj) {
      const {obj, apiDate} = selectedDateObj;

      // converting utc time to local time
      var utcToLocal = moment(`${item.start_time}`, 'hh:mm A').format(
        'YYYY-MM-DD HH:mm:ss',
      );
      var utcToLocalTimeObj = moment.utc(utcToLocal).toDate();
      //combining local booking date and utc time converted to local time to make a local dateTime value that will be use to make utc object;
      let startDay = daysToAdd - 1; //days to add is the next day from selected day
      startDateTimeForApi = moment(
        `${moment().add(startDay, 'd').format('DD-MM-YYYY')} ${moment(
          utcToLocalTimeObj,
        ).format('HH:mm')}`,
        'DD-MM-YYYY HH:mm',
      ).utc();
    }
    return (
      <Card
        data={item}
        btnFilled={false}
        subText={item.activity}
        hideBtn
        width="100%"
        selectedDateUTC={startDateTimeForApi}
      />
    );
  };

  onPressNext = () => {
    const {activeTab = 0} = this.props.route?.params || {};
    const {daysToAdd} = this.state;
    let query = '';
    if (activeTab == 0) {
      query = `?type=fitness`;
    } else if (activeTab == 1) {
      query = `?type=wellness`;
    } else {
      query = `?type=one_on_one`;
    }
    let dateObj = moment().add(daysToAdd, 'd');
    let startDateTime = dateObj.startOf('d').utc();
    let endDateTime = moment().add(daysToAdd, 'd').endOf('day').utc();
    let dateTimeQuery = `&start_date=${startDateTime.format(
      'YYYY-MM-DD',
    )}&start_time=${startDateTime.format(
      'HH:mm',
    )}&end_time=${endDateTime.format('HH:mm')}&end_date=${endDateTime.format(
      'YYYY-MM-DD',
    )}`;
    // alert(dateTimeQuery)
    query += dateTimeQuery;
    this.setState({isLoading: true});
    actions
      .getClassesList(query)
      .then((res) => {
        this.setState({
          classArray: res.data?.classes || [],
          isLoading: false,
          daysToAdd: daysToAdd + 1,
          dateToShow: moment().add(daysToAdd, 'd').format('DD MMM'),
        });
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  };

  render() {
    const {classArray, isLoading, dateToShow, daysToAdd} = this.state;
    const {selectedDateObj, sliderValues} = this.props.route?.params || {};

    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack
          leftStyle={{marginRight: 10}}
          centerText="Classes"
          customRight={() => {
            if (!selectedDateObj) {
              return <View style={{width: 20}} />;
            }
            return (
              <View>
                <Text
                  style={{
                    textAlign: 'center',
                    ...commonStyles.fontSize12,
                    color: colors.white,
                  }}>
                  {dateToShow}{' '}
                </Text>
                {daysToAdd < 7 && (
                  <TouchableOpacity
                    hitSlop={hitSlopProp}
                    onPress={this.onPressNext}
                    style={{alignItems: 'center'}}>
                    <Image source={imagePath.arrowForward} />
                  </TouchableOpacity>
                )}
              </View>
            );
          }}
        />
        <View
          style={{
            flex: 1,
            backgroundColor: colors.white,
          }}>
          <FlatList
            data={classArray}
            ListHeaderComponent={() => <View style={{height: 20}} />}
            keyExtractor={(item, index) => String(index)}
            renderItem={this._renderClass}
            contentContainerStyle={{flexGrow: 1}}
            style={{paddingHorizontal: moderateScale(16)}}
            ListEmptyComponent={<ListEmptyComponent isLoading={isLoading} />}
            ItemSeparatorComponent={() => <View style={{height: 10}} />}
            ListFooterComponent={() => <View style={{height: 20}} />}
          />
        </View>
      </GradientWrapper>
    );
  }
}
