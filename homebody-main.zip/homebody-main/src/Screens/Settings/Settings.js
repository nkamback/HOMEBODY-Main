import React, {Component} from 'react';
import {Alert, View, StyleSheet} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import ListItemHorizontal from '../../components/ListItemHorizontal';
import imagePath from '../../constants/imagePath';
import {moderateScale} from '../../styles/responsiveSize';
import AsyncStorage from '@react-native-community/async-storage';
import { connect } from 'react-redux';
import types from '../../redux/types';
import actions from '../../redux/actions';

 class Settings extends Component {
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };
  openLogoutAlert = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {
          text: 'Yes',
          onPress: () => {
            actions.logout();
            this.props.logout();
            
          AsyncStorage.removeItem('userData');
          },
        },
        {text: 'No'},
      ],
      {cancelable: true},
    );
  };
  render() {
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }}>
        <HeaderWithCenterTextBack centerText="Settings" />
        <View style={{flex: 1, backgroundColor: colors.white}}>
          <ListItemHorizontal
            continerStyle={styles.containerStyle}
            iconLeft={imagePath.notificatons}
            valueStyle={styles.valueStyle}
            tintColor={colors.btnBlueB}
            value="Notifications"
            activeOpacity={0.7}
            onPress={this.moveToNewScreen('notifications')}
            disabled={false}
          />
          {/* <ListItemHorizontal
            continerStyle={styles.containerStyle}
            iconLeft={imagePath.payments}
            valueStyle={styles.valueStyle}
            tintColor={colors.btnBlueB}
            value="Payment Methods"
            activeOpacity={0.7}
            disabled={false}
          /> */}
          <ListItemHorizontal
            continerStyle={styles.containerStyle}
            iconLeft={imagePath.transac}
            valueStyle={styles.valueStyle}
            tintColor={colors.btnBlueB}
            value="Transaction History"
            onPress={this.moveToNewScreen('transactionHistory')}
            activeOpacity={0.7}
            disabled={false}
          />
          <ListItemHorizontal
            continerStyle={styles.containerStyle}
            iconLeft={imagePath.changePwd}
            tintColor={colors.btnBlueB}
            valueStyle={styles.valueStyle}
            onPress={this.moveToNewScreen('changePassword')}
            value="Change Password"
            activeOpacity={0.7}
            disabled={false}
          />
          <ListItemHorizontal
            continerStyle={styles.containerStyle}
            iconLeft={imagePath.contactUs}
            valueStyle={styles.valueStyle}
            value="Contact Us"
            tintColor={colors.btnBlueB}
            onPress={this.moveToNewScreen('contactUs')}
            activeOpacity={0.7}
            disabled={false}
          />
          <ListItemHorizontal
            continerStyle={{...styles.containerStyle, borderBottomWidth: 0}}
            iconLeft={imagePath.logout}
            tintColor={colors.btnBlueB}
            onPress={this.openLogoutAlert}
            valueStyle={styles.valueStyle}
            value="Logout"
            activeOpacity={0.7}
            disabled={false}
          />
        </View>
      </GradientWrapper>
    );
  }
}
const mapStateToProps=(state)=>({
  userData:state.auth.userData
})
const mapDispatchToProps=(dispatch)=>({
  logout:()=>dispatch({
    type:types.CLEAR_REDUX_STATE
  })
})
export default connect(mapStateToProps,mapDispatchToProps)(Settings);
const styles = StyleSheet.create({
  containerStyle: {
    padding: moderateScale(16),
    borderBottomWidth: 0.7,
    borderBottomColor: colors.blackImgOverlay,
    alignItems: 'center',
  },
  valueStyle: {
    color: colors.gradientB,
  },
});
