import React, {Component} from 'react';
import {Text, View, FlatList, StyleSheet, Image} from 'react-native';
import {connect} from 'react-redux';
import GradientWrapper from '../../components/GradientWrapper';
import {moderateScale, textScale} from '../../styles/responsiveSize';
import colors from '../../styles/colors';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import Card from '../../components/Card';
import CoachCard from '../../components/CoachCard';
import actions from '../../redux/actions';
import ListEmptyComponent from '../../components/ListEmptyComponent';
import imagePath from '../../constants/imagePath';
import GradientButton from '../../components/GradientButton';
import ButtonWithLoader from '../../components/ButtonWithLoader';

class Favourites extends Component {
  state = {
    activeTab: 0,
    isClassActive: true,
  };

  componentDidMount() {
    this.focusListener = this.props.navigation.addListener('focus', () => {
      actions.getFavCoaches();
    });
  }
  componentWillUnmount() {
    if (this.focusListener) {
      this.focusListener();
    }
  }
  updateClassesView = (isClassActive) => () => {
    this.setState({isClassActive});
  };
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };

  renderCoachsData = () => {
    const {favCaochLoading, favCoaches} = this.props;

    if (favCoaches.length < 1 && !favCaochLoading) {
      return (
        <View style={{flex: 1, justifyContent: 'center'}}>
          <View style={{alignItems: 'center'}}>
            <Image source={imagePath.noData} />
            <Text style={{...commonStyles.fontBold21, color: colors.blueMain}}>
              you have no favorite instructors
            </Text>
            <Text
              style={{
                marginHorizontal: moderateScale(70),
                textAlign: 'center',
                marginTop: 10,
                color: colors.headingGrey,
              }}>
              add an instructor by tapping on the heart icon in their profile
            </Text>
          </View>
          <GradientButton
            containerStyle={{
              marginTop: 20,
              marginHorizontal: moderateScale(16),
              borderRadius: 5,
            }}
            onPress={this.moveToNewScreen('explore', {isClassActive: false})}
            btnStyle={{borderRadius: 5, backgroundColor: colors.white}}
            colorsArray={['rgba(141,153,178,.27)', 'rgba(141,153,178,.27)']}
            btnText={'Browse Instructor'}
          />
        </View>
      );
    }

    return (
      <FlatList
        data={favCoaches}
        ListHeaderComponent={() => <View style={{height: 20}} />}
        contentContainerStyle={{flexGrow: 1}}
        renderItem={this._renderItemCoaches}
        ListEmptyComponent={!favCaochLoading && <ListEmptyComponent />}
        keyExtractor={(item, index) => String(index)}
      />
    );
  };

  _renderItemCoaches = ({item, index}) => {
    return <CoachCard data={item} key={String(item.id)} />;
  };

  renderClassData = () => {
    return (
      <>
        <View style={{paddingHorizontal: moderateScale(16)}}>
          <Card btnFilled={false} width="100%" />
        </View>
      </>
    );
  };

  render() {
    const {isClassActive} = this.state;
    const {favCaochLoading, favCoaches} = this.props;
    return (
      <GradientWrapper
        start={{x: 0, y: 1}}
        end={{x: 1, y: 1}}
        isLoading={favCaochLoading}>
        <View style={styles.favContainer}>
          <Text style={styles.favTxt}>Favorites</Text>
        </View>
        <View style={{flex: 1, backgroundColor: colors.white}}>
          {this.renderCoachsData()}
        </View>
      </GradientWrapper>
    );
  }
}
const mapStateToProps = (state) => ({
  favCoaches: state.coaches.favCoaches,
  favCaochLoading: state.coaches.favLoading,
});
export default connect(mapStateToProps)(Favourites);

const styles = StyleSheet.create({
  favTxt: {
    ...commonStyles.fontBold16,
    fontSize: textScale(18),
    color: colors.white,
    textAlign: 'center',
  },
  favContainer: {
    marginHorizontal: moderateScale(16),
    marginTop: moderateScale(30),
    marginBottom: moderateScale(20),
  },
});
