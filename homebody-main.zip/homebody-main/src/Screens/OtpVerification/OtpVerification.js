import React, {useState, useEffect, useRef} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Image} from 'react-native';
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import colors from '../../styles/colors';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import fontFamily from '../../styles/fontFamily';
import imagePath from '../../constants/imagePath';
import commonStyles from '../../styles/commonStyles';
import strings from '../../constants/lang';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import {otpTimerCounter, showError} from '../../utils/helperFunctions';
import validations from '../../utils/validations';
import actions from '../../redux/actions';
import Loader from '../../components/Loader';
import GradientWrapper from '../../components/GradientWrapper';

const CELL_COUNT = 4;
const OtpVerification = (props) => {
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [timer, setTimer] = useState(120);
  const timeoutRef = useRef(null);
  const ref = useBlurOnFulfill({otp, cellCount: CELL_COUNT});
  const [isTimerActive, setIsTimer] = useState(true);
  const [propsOtp = props, getCellOnLayoutHandler] = useClearByFocusCell({
    value: otp,
    setValue: setOtp,
  });

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (timer > 0) setTimer(timer - 1);
    }, 1000);
    return () => {
      if (timeout) {
        clearTimeout(timeout);
      }
    };
  }, [timer]);

  const resendOtp = () => {
    setTimer(120);
  };

  const isValidData = () => {
    if (!otp.trim()) {
      showError('Please enter OTP');
      return;
    }
    if (otp.length == 4) {
      return true;
    }
    showError('Please enter valid OTP');
    return false;
  };

  const onOtpSubmit = () => {
    const {route} = props;
    const {user} = route?.params || {};
    console.log(otp, 'the otp value');
    console.log(route, 'the route param');
    const checkValid = isValidData();
    if (checkValid) {
      setIsLoading(true);
      actions
        .verifyOtp({
          phone: user.phone,
          code: otp,
          phone_code: user.phone_code,
        })
        .then((res) => {
          // setIsLoading(false);
          setTimeout(()=>{
            alert(
              'Email verfication link has been sent to your email id.Please verify your email also'
            );
          },1200)
         
          // props.navigation.popToTop();
          // props.navigation.navigate("login");
          console.log(res, 'the response value is as follow');
        })
        .catch((error) => {
          setIsLoading(false);
          showError(error.message);
        });
    }
  };
  const {route} = props;
  const {user} = route?.params || {};
  console.log(user,'the user has specific value');
  
  return (
    <GradientWrapper colorsBg={[colors.gradientA, colors.gradientB]}>
      <View style={styles.backContainer}>
        <TouchableOpacity
          onPress={() => props.navigation.goBack(null)}
          hitSlop={{top: 12, bottom: 12, right: 12, left: 12}}>
          <Image
            style={{tintColor: colors.white}}
            source={imagePath.backblack}
          />
        </TouchableOpacity>
      </View>
      <View style={{paddingHorizontal: moderateScale(16)}}>
        <Text style={[commonStyles.fontBold24,{color:colors.white,fontFamily:fontFamily.regular,fontSize:textScale(28)}]}>Enter the 4-digit</Text>
        <Text style={[commonStyles.fontBold24,{color:colors.white,fontFamily:fontFamily.regular,fontSize:textScale(28)}]}>code sent to you at</Text>
        <Text style={[commonStyles.fontBold24, {color:colors.blueGreen,fontFamily:fontFamily.regular,fontSize:textScale(28)}]}>
          {`+${user.phone_code} ${user.phone}`}
        </Text>
        
      </View>
      <CodeField
        ref={ref}
        {...propsOtp}
        value={otp}
        onChangeText={setOtp}
        cellCount={CELL_COUNT}
        rootStyle={styles.root}
        blurOnSubmit
        keyboardType="number-pad"
        textContentType="oneTimeCode"
        selectionColor={colors.themeMain}
        renderCell={({index, symbol, isFocused}) => (
          <Text
            key={index}
            style={[styles.cell, isFocused && styles.focusCell]}
            onLayout={getCellOnLayoutHandler(index)}>
            {symbol || (isFocused ? <Cursor /> : null)}
          </Text>
        )}
      />
      <View style={{flex: 1, marginHorizontal: moderateScale(16)}}>
        <ButtonWithLoader btnStyle={{backgroundColor:colors.white26,borderColor:colors.white26}} onPress={onOtpSubmit} btnText="Submit" />
        <Text
          style={{
            ...commonStyles.fontSize14,
            color: colors.white,
            marginTop: moderateScaleVertical(24),
          }}>
          Didn't Received OTP?
          {timer < 1 ? (
            <Text onPress={resendOtp} style={[commonStyles.fontSize14,{color:colors.blueGreen}]}>
              {' ' + strings.RESEND_OTP}
            </Text>
          ) : (
            <Text
              style={{
                ...commonStyles.fontSize14,
                // backgroundColor:'green',
                color: colors.white,
                marginTop: moderateScaleVertical(24),
              }}>
              {` Request for OTP in ${otpTimerCounter(timer)} min`}
            </Text>
          )}
        </Text>
      </View>
      <Loader isLoading={isLoading} />
    </GradientWrapper>
  );
};

export default OtpVerification;

const styles = StyleSheet.create({
  root: {
    marginHorizontal: moderateScale(16),
    marginVertical: 30,
    justifyContent: 'space-between',
  },
  backContainer: {
    marginTop: moderateScaleVertical(36),
    marginBottom: moderateScaleVertical(24),
  },
  title: {textAlign: 'center', fontSize: 30},
  codeFieldRoot: {marginTop: 20},
  cell: {
    width: textScale(60),
    height: textScale(60),
    fontFamily: fontFamily.regular,
    lineHeight:textScale(57),
    fontSize: 24,
    borderWidth: 2,
    borderRadius:textScale(30),
    borderColor:colors.white,
    color:colors.white,
    textAlign: 'center',
    marginRight: 10,
  },
  focusCell: {
    borderColor: colors.blueGreen,
  },
});
