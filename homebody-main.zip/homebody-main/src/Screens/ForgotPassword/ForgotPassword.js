import React, {Component} from 'react';
import {Text, View} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import TextInputWithLabel from '../../components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import {OutlinedTextField} from 'react-native-material-textfield';
import actions from '../../redux/actions';
import validations from '../../utils/validations';
import {showError, showSuccess} from '../../utils/helperFunctions';
import BorderTextInput from '../../components/BorderTextInput';

export default class ForgotPassword extends Component {
  state = {
    email: '',
    isLoading: false,
  };

  onChangeText = (email) => {
    this.setState({email});
  };

  isValidData = () => {
    const {email} = this.state;
    const error = validations({email});
    if (error) {
      showError(error);
      return;
    }

    return true;
  };

  _onSubmit = () => {
    const {email} = this.state;
    const checkValid = this.isValidData();

    if (!checkValid) {
      return;
    }
    this.setState({isLoading: true});
    actions
      .forgotPassword({
        email: email,
      })
      .then((res) => {
        console.log(res, 'the reuslt ');
        this.setState({isLoading: false});
        this.props.navigation.goBack(null);
        showSuccess('Verification link has been sent to your email');
        return false;
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  };
  render() {
    const {email, isLoading} = this.state;
    return (
      <GradientWrapper colorsBg={[colors.gradientA,colors.gradientB]} isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="" />
        <View
          style={{
            flex: 1,

            paddingHorizontal: moderateScale(16),
          }}>
          <View style={{marginTop: moderateScale(56)}}>
            <Text
              style={{
                ...commonStyles.fontSize14,
                color: colors.white,
                fontSize: textScale(30),
              }}>
              Forgot password?
            </Text>
          </View>
          <Text
            style={{
              ...commonStyles.fontSize16,
              marginVertical: 10,
              marginBottom: moderateScaleVertical(24),
              color: colors.white,
            }}>
            Enter your email associated with your account. You will get a
            verification link on your email
          </Text>
          <BorderTextInput
            placeholder={'Email'}
            keyboardType="email-address"
            onChangeText={this.onChangeText}
            leftIcon={imagePath.emailSmall}
            value={email}
          />

          <ButtonWithLoader
            btnStyle={{
              backgroundColor: colors.white26,
              borderColor: colors.white26,
            }}
            onPress={this._onSubmit}
            btnText="Recover Password"
          />
        </View>
      </GradientWrapper>
    );
  }
}
