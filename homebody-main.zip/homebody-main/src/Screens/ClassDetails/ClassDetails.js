import React, {Component} from 'react';
import {
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image,
  ImageBackground,
  ScrollView,
} from 'react-native';
import {
  initialWindowMetrics,
  SafeAreaView,
} from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import moment from 'moment';
import GradientWrapper from '../../components/GradientWrapper';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import Card from '../../components/Card';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import {exerciseImg} from '../../constants/constants';
import WrapperContainer from '../../components/WrapperContainer';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import ListItemHorizontal from '../../components/ListItemHorizontal';
import fontFamily from '../../styles/fontFamily';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';
import Loader from '../../components/Loader';
import GradientButton from '../../components/GradientButton';

export default class Classes extends Component {
  state = {
    classDetails: {},
    isLoading: true,
  };
  componentDidMount() {
    const {data} = this.props.route?.params || {};
    console.log(data, 'the data value');
    actions
      .getClassDetails(`/${data.id}`)
      .then((res) => {
        this.setState({
          classDetails: res?.data?.coach,
          isLoading: false,
        });
      })
      .catch(this.errorMethod);
  }
  errorMethod = (error) => {
    this.setState({isLoading: false});
    showError(error.message);
  };
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };
  render() {
    const {classDetails, isLoading} = this.state;

    console.log(classDetails, '--------------------99999999999');
    let durationText = '';
    if (!!classDetails.duration) {
      durationText = classDetails.duration.split(' ')[0];
    }
    console.log(durationText, '---------------');
    console.log(initialWindowMetrics, 'th inijojjojojo');
    // const {insets}=initialWindowMetrics
    // alert(classDetails.start_time);
    //selectedDateUTC in case USER has selected a date
    const {data,selectedDateUTC} = this.props.route?.params || {};
    let dateTimeObj=null;
    if(classDetails.start_date){
    var stillUtc = moment(
      `${classDetails?.start_date} ${classDetails.start_time}`,
      'YYYY-MM-DD hh:mm A',
    ).format('YYYY-MM-DD HH:mm:ss');
    if(!!selectedDateUTC&&classDetails.type=="recurring"){
      // alert('hell')
      stillUtc=selectedDateUTC
    }
    dateTimeObj = moment.utc(stillUtc).toDate();
    }
    // alert(moment(selectedDateUTC).format("HH:mm"))
    // console.log(times, 'the times time value');
    // alert(classDetails.id)
    return (
      <SafeAreaView edges={['bottom']} style={{flex: 1}}>
        <ImageBackground
          source={{uri: classDetails?.image?.thumb_path || exerciseImg}}
          imageStyle={{overlayColor: 'red'}}
          style={{
            width: '100%',
            height: moderateScaleVertical(240),
            backgroundColor: colors.black,
          }}>
          <View
            style={{
              marginBottom: moderateScaleVertical(16),
              justifyContent: 'space-between',
              flex: 1,
            }}>
            <LinearGradient
              style={{paddingTop: 20}}
              colors={[colors.bgGradientA, colors.bgGradientB]}>
              <HeaderWithCenterTextBack />
            </LinearGradient>
            <View style={{alignItems: 'flex-end'}}>
              <View
                style={{
                  marginRight: moderateScale(16),
                }}>
                <Text style={commonStyles.badgeWhite}>
                  {classDetails?.duration}
                </Text>
              </View>
            </View>
          </View>
          <View
            style={{
              position: 'absolute',
              top: 0,
              right: 0,
              left: 0,
              bottom: 0,
              backgroundColor: colors.blackImgOverlay,
              zIndex: -19,
            }}
          />
        </ImageBackground>
        <ScrollView style={{paddingHorizontal: moderateScale(16)}}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: moderateScaleVertical(24),
            }}>
            <Text style={{...commonStyles.fontBold21}}>
              {classDetails.name}{' '}
            </Text>
            {classDetails.is_promoted&&false ? (
              <ButtonWithLoader
                btnStyle={commonStyles.outlinedBtnExtraStyle}
                btnTextStyle={{
                  color: colors.themeMain,
                  fontSize: textScale(12),
                }}
                btnText="Promoted"
              />
            ) : (
              <View />
            )}
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: 10,
              paddingBottom: 10,
              borderBottomWidth: 0.7,
              borderBottomColor: colors.borderLight,
              marginBottom: moderateScaleVertical(18),
            }}>
            <Text
              style={{
                ...commonStyles.fontSize14,
                color: colors.blackOpacity40,
              }}>
              Live on{' '}
              {!!dateTimeObj&&moment(dateTimeObj).format(
                'ddd, DD MMM  hh:mm A',
              )}{' '}
              
            </Text>
            <Text style={{...commonStyles.headingText}}>
              ${classDetails.price}{' '}
            </Text>
          </View>
          <View
            style={{
              paddingBottom: 10,
              borderBottomWidth: 0.7,
              borderBottomColor: colors.borderLight,
              marginBottom: moderateScaleVertical(18),
            }}>
            <ListItemHorizontal
              label="Instructor:"
              value={classDetails.coach?.name}
            />
            <ListItemHorizontal
              label="Activity:"
              value={classDetails.activity}
            />
            <ListItemHorizontal
              label="Equipment Needed:"
              value={classDetails.equipment_needed}
            />
            {/* <ListItemHorizontal
              label="Body Focus:"
              value={classDetails.body_focus}
            />
            <ListItemHorizontal
              label="Slots Left:"
              value={classDetails.slots_left}
            /> */}
          </View>
          <View>
            <Text
              style={{
                ...commonStyles.fontSize16,
                fontFamily: fontFamily.medium,
              }}>
              About Full Body
            </Text>

            <Text
              style={{
                ...commonStyles.fontSize15,
                color: colors.blackOpacity40,
              }}>
              {classDetails.about}
            </Text>
          </View>
        </ScrollView>
        <View style={{
            marginTop: 0,
            marginBottom: 16,
            marginHorizontal: moderateScale(16),
          }}>
        <GradientButton
          colorsArray={[colors.btnBlue,colors.btnBlueB]}
          btnText="Book"
          onPress={this.moveToNewScreen('summary', {data: classDetails,selectedDateUTC})}
          borderRadius={4}
          
        />
        </View>
        <Loader isLoading={isLoading} />
      </SafeAreaView>
    );
  }
}
