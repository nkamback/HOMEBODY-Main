import AsyncStorage from '@react-native-community/async-storage';
import React, {useState, useEffect, useRef} from 'react';
import LinearGradient from 'react-native-linear-gradient';
import {Pagination} from 'react-native-snap-carousel';
import {
  View,
  Text,
  ImageBackground,
  Image,
  StyleSheet,
  TouchableOpacity,
  TouchableWithoutFeedback,
  FlatList,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import GradientWrapper from '../../components/GradientWrapper';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import {
  height,
  moderateScaleVertical,
  width,
  moderateScale,
} from '../../styles/responsiveSize';

const dotArray = [...Array(3)];
export default function Welcome({navigation}) {
  const animateRef = useRef();
  const insets = useSafeAreaInsets();
  const [curIndex, setIndex] = useState(0);

  const _onPressNext = () => {
    // if (curIndex < 2) {
    //   setIndex(curIndex + 1);
    //   return;
    // }
    navigation.navigate('outer');
    AsyncStorage.setItem('isUserExist', 'Yes');
  };

  useEffect(() => {
    let timeout = setTimeout(() => {
      if (curIndex < 2) {
        setIndex(curIndex + 1);
        if (animateRef.current) {
          animateRef.current.fadeIn(1000, 200);
        }
      } else {
        setIndex(0);
      }
    }, 3500);

    return () => clearTimeout(timeout);
  }, [curIndex]);

  const _onLogin = () => {
    navigation.navigate('login');
    AsyncStorage.setItem('isUserExist', 'Yes');
  };

  const _renderSelectedItem = () => {
    if (curIndex == 0)
      return (
        <View>
          <Text
            style={{
              ...commonStyles.fontSize20,
              textTransform: 'uppercase',
              color: colors.white,
            }}>
            Welcome to
          </Text>
          <Image source={imagePath.logoWhiteBig} />
          <View style={{marginTop: moderateScaleVertical(100)}} />
          <Text style={{...commonStyles.fontBold21, color: colors.white}}>
            Live Workouts
          </Text>
          <Text
            style={{
              ...commonStyles.fontSize20,
              color: colors.white,
              marginTop: 3,
            }}>
            with your favorite trainers from{' '}
          </Text>
          <Text style={{...commonStyles.fontSize20, color: colors.white}}>
            around the world
          </Text>
        </View>
      );
    else if (curIndex == 1) {
      return (
        <View>
          <View style={{marginTop: moderateScaleVertical(80)}} />
          <Image source={imagePath.getStartedIcon} />
          <View style={{height: 20}} />
          <Text style={{...commonStyles.fontBold21, color: colors.white}}>
            Health & Wellness Classes
          </Text>
          <Text
            style={{
              ...commonStyles.fontSize20,
              color: colors.white,
              marginTop: 3,
            }}>
            in every category, for all your needs
          </Text>
          <Text style={{...commonStyles.fontSize20, color: colors.white}}>
            {/* from anytime, anywhere */}
          </Text>
        </View>
      );
    } else {
      return (
        <View>
          <View style={{marginTop: moderateScaleVertical(120)}} />

          <Text style={{...commonStyles.fontBold21, color: colors.white}}>
            Join World Class Trainers
          </Text>
          <Text style={{...commonStyles.fontSize20, color: colors.white}}>
            from anytime, anywhere
          </Text>
          <View style={{height: moderateScaleVertical(35)}} />
        </View>
      );
    }
  };
  return (
    <ImageBackground
      style={{height: '100%', width: width}}
      blurRadius={!!curIndex ? 4 : 0}
      source={imagePath.startedBgImg}>
      <SafeAreaView style={{flex: 1}}>
        <StatusBar
          backgroundColor={colors.transparent}
          translucent
          barStyle="light-content"
          // hidden
        />
        <View
          style={{
            flex: 1,
            justifyContent: 'flex-end',
            marginHorizontal: moderateScale(24),
          }}>
          <Animatable.View
            ref={animateRef}
            easing="ease-out"
            animation="fadeIn"
            delay={500}>
            {_renderSelectedItem()}
          </Animatable.View>
          <View style={{flexDirection: 'row', marginTop: 15}}>
            {dotArray.map((val, index) => {
              let selected = index == curIndex;
              if (true) {
                return (
                  <TouchableOpacity
                    hitSlop={hitSlopProp}
                    onPress={() => setIndex(index)}
                    key={String(index)}>
                    <View
                      style={[
                        {...styles.badge},
                        selected && styles.badgeSelected,
                      ]}
                    />
                  </TouchableOpacity>
                );
              }
            })}
          </View>
          <View
            style={{
              flexDirection: 'row',
              marginTop: moderateScaleVertical(35),
            }}>
            <TouchableOpacity
              onPress={_onPressNext}
              style={styles.btnOpacityWhite}>
              <Text style={styles.btnText}>Get Started</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={_onLogin} style={styles.btnOutlined}>
              <Text style={styles.btnText}>Login</Text>
            </TouchableOpacity>
          </View>
          <View style={{height: 25 + insets.bottom}} />
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  badge: {
    backgroundColor: colors.white,
    height: 5,
    width: 30,
    borderRadius: 20,
    opacity: 0.4,
    marginRight: 10,
  },
  badgeSelected: {
    backgroundColor: colors.white,
    height: 5,
    width: 30,
    borderRadius: 20,
    marginLeft: 0,
    alignSelf: 'flex-start',
    marginRight: 10,
    opacity: 1,
  },
  btnOpacityWhite: {
    // paddingHorizontal: moderateScale(18),
    width: moderateScale(118),
    height: moderateScaleVertical(40),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
    backgroundColor: colors.white26,
    marginRight: 10,
  },
  btnOutlined: {
    width: moderateScale(118),
    height: moderateScaleVertical(40),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
    borderWidth: 1,
    borderColor: colors.white,
  },
  btnText: {
    ...commonStyles.fontSize16,
    color: colors.white,
  },
});
