import React, {Component} from 'react';
import {Text, View, FlatList, TouchableOpacity, Image} from 'react-native';
import {connect} from 'react-redux';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import GradientWrapper from '../../components/GradientWrapper';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import ProgressiveImage from '../../components/ProgressiveImage';
import {exerciseImg} from '../../constants/constants';
import fontFamily from '../../styles/fontFamily';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import ScheduleCard from '../../components/ScheduleCard';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';
import moment from 'moment';
class Profile extends Component {
  state = {
    isLoading: true,
    isScheduleVisible: false,
    upcomingClasses: [],
  };

  componentDidMount() {
    this.focusListener = this.props.navigation.addListener('focus', () => {
      actions
        .getBookedUpcomingClasses()
        .then((res) => {
          console.log(res, 'the result');
          this.setState({
            isLoading: false,
            upcomingClasses: res?.data?.upcoming_classes?.list || [],
          });
        })
        .catch((error) => {
          this.setState({isLoading: false});
          showError(error.message);
        });
    });
  }
  componentWillUnmount() {
    if (this.focusListener) {
      this.focusListener();
    }
  }
  openSchedule = () => {
    this.setState({isScheduleVisible: true});
  };
  renderScheduleBody = () => {
    const {upcomingClasses} = this.state;
    if (upcomingClasses.length > 0) {
      return (
        <FlatList
          data={upcomingClasses}
          ListHeaderComponent={() => <View style={{height: 20}} />}
          keyExtractor={(item, index) => String(index)}
          renderItem={({item, index}) => {
            var stillUtc = moment(
              `${item?.start_date} ${item.start_time}`,
              'YYYY-MM-DD hh:mm A',
            ).format('YYYY-MM-DD HH:mm:ss');

            let dateTimeObj = moment.utc(stillUtc).toDate();
            return (
              <ScheduleCard
                onPress={() => {
                  this.props.navigation.navigate('liveStreaming', {data: item});
                }}
                startDate={`${moment(dateTimeObj).format('DD MMM')}`}
                startTime={`${moment(dateTimeObj).format('HH:mm')}`}
                data={item}
                containerStyle={{marginBottom: 10}}
              />
            );
          }}
        />
      );
    }

    return (
      <View style={{justifyContent: 'center', alignItems: 'center', flex: 1}}>
        <Text
          style={{
            ...commonStyles.fontSize18,
            fontFamily: fontFamily.bold,
          }}>
          Looking for something to book?
        </Text>
        <Text
          style={{
            ...commonStyles.fontSize14,
            color: colors.blackOpacity40,
            marginVertical: moderateScaleVertical(10),
          }}>
          Let’s explore your options.
        </Text>
        <ButtonWithLoader
          onPress={this.moveToNewScreen('explore')}
          btnStyle={{
            ...commonStyles.outlinedBtnExtraStyle,
            borderColor: colors.blackOpacity40,
            height: moderateScaleVertical(48),
            borderRadius: 0,
            paddingHorizontal: moderateScale(70),
          }}
          btnTextStyle={{color: colors.blackOpacity40}}
          btnText="Explore"
        />
      </View>
    );
  };
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, data);
  };
  render() {
    const {isLoading,upcomingClasses} = this.state;
    const {userData} = this.props;
    console.log(userData, 'the value of user data');
    return (
      <GradientWrapper
        start={{x: 0, y: 1}}
        end={{x: 1, y: 1}}
        isLoading={isLoading}>
        <HeaderWithCenterTextBack
          hideLeft
          centerText="Profile"
          rightIcon={imagePath.settings}
          onPressRight={() => this.props.navigation.navigate('settings')}
        />
        <View style={{backgroundColor: colors.white, flex: 1}}>
          <View
            style={{
              ...commonStyles.shadowStyle,
              flexDirection: 'row',
              paddingHorizontal: moderateScale(16),
              paddingVertical: moderateScaleVertical(20),
            }}>
            <View
              style={{
                flex: 1,
                marginRight: 10,
                justifyContent: 'space-evenly',
              }}>
              <View style={{flexDirection: 'row'}}>
                <Text style={{...commonStyles.fontBold21}}>
                  {userData.name}
                </Text>
              </View>
             {upcomingClasses.length>0&& <Text style={{...commonStyles.fontSize14}}>{upcomingClasses.length} Upcoming {upcomingClasses.length>1?"Classes":"Class"}</Text>}
            </View>

            <TouchableOpacity onPress={this.moveToNewScreen('editProfile')}>
              <View>
              <ProgressiveImage
                isCircular
                source={{uri: userData?.avatar?.thumb_path || exerciseImg}}
                height={moderateScale(96)}
                width={moderateScale(96)}
              />
                <View
                style={{
                  position: 'absolute',
                  top: 0,
                  bottom: 0,
                  right: 0,
                  left: 0,
                  height: moderateScale(96),
                  width: moderateScale(96),
                  backgroundColor: colors.blackOpacity10,
                  borderRadius: 50,
                }}
              />
              </View>
            
              <View style={{position: 'absolute', bottom: 14, right: 20}}>
                <Image
                  style={{tintColor: colors.themeMain}}
                  source={imagePath.editIcon}
                />
              </View>
            </TouchableOpacity>
          </View>
          <View style={{height: 10}} />
          <View
            style={{
              ...commonStyles.shadowStyle,
              flex: 1,
              paddingTop: moderateScaleVertical(16),
            }}>
            <Text
              style={{
                ...commonStyles.fontBold21,
                paddingHorizontal: moderateScale(16),
              }}>
              My Schedule
            </Text>
            {this.renderScheduleBody()}
          </View>
        </View>
      </GradientWrapper>
    );
  }
}

const mapStateToProps = (state) => ({
  userData: state.auth.userData,
});
export default connect(mapStateToProps)(Profile);
