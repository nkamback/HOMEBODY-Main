import React, {Component} from 'react';
import {Text, View} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import TextInputWithLabel from '../../components/TextInputWithLabel';
import imagePath from '../../constants/imagePath';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import validations from '../../utils/validations';
import {showError, showSuccess} from '../../utils/helperFunctions';
import actions from '../../redux/actions';
import GradientButton from '../../components/GradientButton';

export default class ChangePassword extends Component {
  state = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
    isLoading: false,
  };
  _onChangeText = (key) => (val) => {
    this.setState({[key]: val});
  };
  isValidData =  ({newPassword, oldPassword, confirmPassword}) => {
    if (oldPassword.length < 1) {
      showError('Please enter your old password');
      return false;
    } else if (oldPassword.length < 6) {
      showError('Old password requires minimum 6 characters');
      return false;
    } else if (newPassword.length < 1) {
      showError('Please enter your new password');
      return false;
    } else if (newPassword.length < 6) {
      showError('New password requires minimum 6 characters');
      return false;
    } else if (confirmPassword.length < 1) {
      showError('Please enter confirm password');
      return false;
    } else if (newPassword !== confirmPassword) {
      showError("New Password didn't matched with confirm password");
      return false;
    } else {
      return true;
    }
  };

  _onSubmit = () => {
    const {oldPassword, newPassword, confirmPassword} = this.state;
    const checkValid=this.isValidData({oldPassword,newPassword,confirmPassword});
    if(checkValid){
      this.setState({isLoading:true});
      actions.changePassword({
        old_password:oldPassword,
        new_password:newPassword
      }).then(res=>{
        console.log(res,'the result value');
        this.setState({isLoading:false});
        showSuccess("Password update successfully");
        this.props.navigation.popToTop();
        
      }).catch(error=>{
          this.setState({isLoading:false});
          showError(error.message);
      })
    }

  };

  render() {
    const {oldPassword, newPassword, confirmPassword, isLoading} = this.state;
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Change Password" />
        <View
          style={{
            flex: 1,
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <Text
            style={{
              ...commonStyles.fontSize14,
              marginVertical: 10,
              marginBottom: moderateScaleVertical(24),
              color: colors.blackOpacity70,
            }}>
            Change your current password
          </Text>
          <TextInputWithLabel
            value={oldPassword}
            secureTextEntry
            onChangeText={this._onChangeText('oldPassword')}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
            }}
            // rightIcon={imagePath.verify}
            label="CURRENT PASSWORD"
          />
          <TextInputWithLabel
            value={newPassword}
            secureTextEntry
            onChangeText={this._onChangeText('newPassword')}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
            }}
            // rightIcon={imagePath.verify}
            label="NEW PASSWORD"
          />
          <TextInputWithLabel
            value={confirmPassword}
            secureTextEntry
            onChangeText={this._onChangeText('confirmPassword')}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
            }}
            // rightIcon={imagePath.verify}
            label="RE-ENTER NEW PASSWORD"
          />
          <GradientButton colorsArray={[colors.btnBlue,colors.btnBlueB]} btnStyle={{borderRadius:4}} onPress={this._onSubmit} btnText="Save Changes" />
        </View>
      </GradientWrapper>
    );
  }
}
