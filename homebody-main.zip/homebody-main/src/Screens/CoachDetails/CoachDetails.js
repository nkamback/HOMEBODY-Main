import React, {Component} from 'react';
import {
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image,
  StyleSheet,
} from 'react-native';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles from '../../styles/commonStyles';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import WrapperContainer from '../../components/WrapperContainer';
import ProgressiveImage from '../../components/ProgressiveImage';
import {exerciseImg} from '../../constants/constants';
import {ScrollView} from 'react-native-gesture-handler';
import RatingCard from '../../components/RatingCard';
import {showError} from '../../utils/helperFunctions';
import actions from '../../redux/actions';
import ToogleFavCoach from '../../components/ToogleFavCoach';
import LinearGradient from 'react-native-linear-gradient';
import fontFamily from '../../styles/fontFamily';

export default class CoacheDetails extends Component {
  state = {
    coachDetails: {},
    isLoading: true,
  };
  componentDidMount() {
    const {route = {}} = this.props;
    const {params} = route;
    let query = '';
    if (params?.data) {
      query = `/${params.data?.id}`;
    }
    actions
      .getCoaches(`${query}`)
      .then((res) => {
        console.log(res, 'the respnse');
        this.setState({coachDetails: res.data?.coach || {}, isLoading: false});
      })
      .catch(this.errorMethod);
  }
  errorMethod = (error) => {
    this.setState({isLoading: false});
    showError(error.message);
  };
  render() {
    const {isLoading, coachDetails} = this.state;
    console.log(coachDetails, 'the coach details value is as follow');
    return (
      <WrapperContainer
        
        statusBarColor={colors.white}
        barStyle={'dark-content'}
        isLoading={isLoading}>
        <HeaderWithCenterTextBack leftStyle={{tintColor: undefined}} />

        <ScrollView
          contentContainerStyle={{paddingTop: moderateScale(16)}}
          style={styles.scroll}>
          <View style={styles.imgRow}>
            <ProgressiveImage
              source={{uri: coachDetails?.avatar?.thumb_path || exerciseImg}}
              isCircular
              height={moderateScale(136)}
              width={moderateScale(136)}
            />
            <View style={styles.nameContainer}>
              <View>
                <View style={styles.nameRow}>
                  <Text numberOfLines={1} style={styles.nameText}>
                    {coachDetails.name}
                  </Text>
                  <ToogleFavCoach marginTop={-10} isLarge data={coachDetails} />
                </View>
                <Text style={styles.profileTitle}>
                  {coachDetails.profile_title}
                </Text>
              </View>
              <View style={styles.nameRow}>
                <Text numberOfLines={1} style={styles.nameRatingTxt}>
                  <Image style={{tintColor:colors.gradientA}} source={imagePath.star} />
                  {`  `}
                  {coachDetails?.review_details?.avg_rating}
                </Text>
              </View>
            </View>
          </View>
          <View style={styles.aboutContainer}>
            <Text style={commonStyles.headingText}>About</Text>
            <Text style={styles.aboutValue}>{coachDetails.about}</Text>
          </View>
          <View style={styles.schedStoreRow}>
            <LinearGradient
              colors={[colors.scheduleBlue, colors.blueMain]}
              style={styles.btnSchedStore}>
              <TouchableOpacity
                onPress={() =>
                  this.props.navigation.navigate('schedule', {coachDetails})
                }
                style={{alignItems: 'center'}}>
                <Text style={styles.btnText}>VIEW SCHEDULE</Text>
              </TouchableOpacity>
            </LinearGradient>
            <LinearGradient
              colors={[colors.scheduleBlue, colors.blueMain]}
              style={styles.btnSchedStore}>
              <TouchableOpacity
                onPress={() => alert('Coming soon')}
                style={{alignItems: 'center'}}>
                <Text style={styles.btnText}>STORE FRONT</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>
          <View style={{paddingHorizontal: moderateScale(16)}}>
            <View style={styles.reviewRatingRow}>
              <Text style={commonStyles.headingText}>
                Reviews ({coachDetails?.review_details?.reviews.length})
              </Text>
              {!!coachDetails?.review_details?.avg_rating ? (
                <View style={styles.avgRatContainer}>
                  <Text style={styles.avgRatingText}>
                    <Image style={{tintColor:colors.themeMain}} source={imagePath.star} />{' '}
                    {coachDetails?.review_details?.avg_rating}
                  </Text>
                </View>
              ) : (
                <View />
              )}
            </View>
            <View style={{marginTop: 20}}>
              <View>
                {coachDetails?.review_details?.reviews.map((val, i) => (
                  <RatingCard data={val} key={String(i)} />
                ))}
              </View>
            </View>
          </View>
        </ScrollView>
      </WrapperContainer>
    );
  }
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: colors.white,
  },
  imgRow: {
    flexDirection: 'row',
    paddingHorizontal: moderateScale(16),
  },
  nameContainer: {
    flex: 1,
    marginLeft: moderateScale(16),
    justifyContent: 'space-between',
  },
  nameRow: {flexDirection: 'row', alignItems: 'center'},
  nameText: {
    ...commonStyles.fontBold21,
    flex: 1,
    marginRight: 8,
  },
  profileTitle: {
    ...commonStyles.fontSize16,
    color: colors.blackOpacity40,
  },
  nameRatingTxt: {
    ...commonStyles.fontSize14,
    color: colors.blackOpacity70,
    // lineHeight: 24,
  },
  aboutContainer: {
    paddingHorizontal: moderateScale(16),
    marginTop: moderateScaleVertical(20),
  },
  aboutValue: {
    ...commonStyles.fontSize15,
    color: colors.blackOpacity40,
  },
  schedStoreRow: {
    marginVertical: moderateScaleVertical(24),
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: moderateScale(16),
    borderRadius: 4,
    // backgroundColor: colors.bgLight,
    // paddingVertical: moderateScaleVertical(20),
  },
  btnSchedStore: {
    // flex: 1,
    width: '46%',
    // paddingTop: 3,
    height: 40,
    borderRadius: 5,
    borderColor: colors.blackOpacity40,
    justifyContent: 'center',
  },
  btnText: {
    ...commonStyles.fontSize15,
    color: colors.white,
    textAlign: 'right',
    fontFamily: fontFamily.bold,
    marginRight: 6,

    // flex:.8
  },
  imgCart: {
    height: 15,
    width: 15,
    tintColor: colors.blackOpacity50,
  },
  reviewRatingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  avgRatContainer: {
    paddingVertical: moderateScale(6),
    // backgroundColor: colors.bgLight,
    borderRadius: 5,
  },
  avgRatingText: {
    ...commonStyles.fontSize14,
    color: colors.blackOpacity70,
    paddingRight: 10,
    paddingLeft: 10,
  },
});
