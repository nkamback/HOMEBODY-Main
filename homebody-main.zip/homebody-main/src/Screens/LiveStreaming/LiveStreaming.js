import React, {Component, Fragment} from 'react';
import Orientation from 'react-native-orientation';
import KeepAwake from 'react-native-keep-awake';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import {
  Platform,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  StatusBar,
  TouchableWithoutFeedback,
  ActivityIndicator,
} from 'react-native';
import {connect} from 'react-redux';
import RtcEngine, {
  RtcRemoteView,
  VideoRenderMode,
  ChannelProfile,
  ClientRole,
} from 'react-native-agora';
import {AGORA_APP_ID} from '../../constants/constants';
import actions from '../../redux/actions';
import {fmtMSS, showError} from '../../utils/helperFunctions';
import {
  moderateScale,
  moderateScaleVertical,
  width,
  height,
  textScale,
} from '../../styles/responsiveSize';
import {requestCameraAndAudioPermission} from '../../utils/permissions';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import Loader from '../../components/Loader';
import fontFamily from '../../styles/fontFamily';
import ProgressBar from '../../libs/ProgressBar/ProgressBar';
import {showMessage} from 'react-native-flash-message';
import commonStyles from '../../styles/commonStyles';
import WaitingRoom from '../../components/WaitingRoom';
import socketServices from '../../utils/socketService';
let userAllowd = false;
function getColorText(currentActiveInterval, widge) {
  let colorToshow = colors.blackOpacity10;
  let textColorWork = colors.blackOpacity10;
  if (currentActiveInterval.type == 'work') {
    colorToshow = widge?.clock?.settings?.color;
    textColorWork = widge?.clock?.settings?.text_color;
  } else if (currentActiveInterval.type == 'warmup') {
    colorToshow = widge['warm-up']?.settings?.color;
    textColorWork = widge['warm-up']?.settings?.text_color;
  } else {
    colorToshow = widge['rest']?.settings?.color;
    textColorWork = widge['warm-up']?.settings?.text_color;
  }

  return {colorToshow, textColorWork};
}
class LiveStreaming extends Component {
  constructor(props) {
    super(props);
    this.state = {
      channelName: 'test_channel',
      joinSucceed: false,
      peerIds: [],
      isLoading: true,
      streamData: {},
      hideControls: false,
      isHostAvail: false,
      isLandscape: false,
      landscapeLoading: false,
      isStreamEnd: false,
      timer: 0,
      initialTime: 0,
      intervalIndex: 0,
      totalTimePassed: 0,
      totalClassDuration: 0,
      startCounter: 5,
      userAllowd: false,
      isCounterStarted: false,
      intervals: this.props.route?.params?.data?.intervals || [],
    };

    if (Platform.OS === 'android') {
      // Request required permissions from Android
      requestCameraAndAudioPermission().then(() => {
        console.log('requested!');
      });
    }

    this._engine = RtcEngine;
  }
  componentDidMount() {
    let dataParam = this.props.route?.params?.data;
    this.setState({totalClassDuration: dataParam?.duration_in_seconds || 1});
    socketServices.on('startClass', () => {
      this.setState({isCounterStarted: true}); //to show counter 5=>4=>3=>2=>1
      this._startCounterInterval = setInterval(() => {
        if (this.state.startCounter > 1) {
          this.setState((prevState) => ({
            startCounter: prevState.startCounter - 1,
          }));
          return;
        }
        clearInterval(this._startCounterInterval);
        setTimeout(() => {
          this.timerInit();
        }, 300);
      }, 1000);
      // KeepAwake.activate();
    });

    socketServices.emit('userJoined', {class_id: dataParam.id});
    socketServices.on('getData', (data) => {
      // alert(`get Data` + JSON.stringify(data || {}));
      if (!!data && data.message) {
        this.setState({intervals: data.message || [], startCounter: 0});
        setTimeout(() => {
          this.timerInit();
        }, 100);
      }
    });
    actions
      .joinStream({class: dataParam.id})
      .then((res) => {
        this.setState({streamData: res.data, isLoading: false}, () => {
          this.startCall(res.data);
        });
      })
      .catch(this.errorMethod);
    Orientation.unlockAllOrientations();
    Orientation.addOrientationListener((orientation) => {
      if (orientation === 'LANDSCAPE') {
        this.setState({isLandscape: true});
      } else {
        this.setState({isLandscape: false});
      }
    });
    // Orientation.lockToLandscape();
    this.init();
  }

  errorMethod = (error) => {
    showError(error.message);
    this.setState({isLoading: false});
  };
  intervalHandler = () => {
    if (this.state.timer > 0) {
      this.setState((prevState) => ({
        timer: prevState.timer - 1,
        totalTimePassed: prevState.totalTimePassed + 1,
      }));
      return;
    }
    if (this.state.timer < 1) {
      clearInterval(this._timeInterval);
      let data = this.props.route?.params?.data;
      let currentInterval = this.state.intervalIndex + 1;
      if (!!this.state.intervals[currentInterval]) {
        if (this.timerInterval) {
          clearInterval(this._timeInterval);
        }
        let newIntrval = this.state.intervals[currentInterval];
        let timeInit = newIntrval.duration;
        if (newIntrval?.duration_type === 'mins') {
          timeInit *= 60;
        }
        this.setState(
          {
            isHostAvail: true,
            timer: timeInit,
            initialTime: timeInit,
            intervalIndex: currentInterval,
            totalTimePassed: this.state.totalTimePassed + 1,
          },
          () => {
            this._timeInterval = setInterval(this.intervalHandler, 1000);
          },
        );
      }
    }
  };
  init = async () => {
    this._engine = await RtcEngine.create(AGORA_APP_ID);
    const da = await this._engine.enableVideo();
    const aa = await this._engine.enableAudio();

    // console.log(da, 'the da has a value');

    this._engine.addListener('Warning', (warn) => {
      console.log('Warning', warn);
    });

    this._engine.addListener('Error', (err) => {
      console.log('Error', err);
    });

    this._engine.addListener('RemoteVideoStateChanged', (val) => {
      if (!this.state.userAllowd) {
        this.setState({
          isHostAvail: true,
          userAllowd: true,
          landscapeLoading: true,
        });
        ///added to test
        // setTimeout(()=>{
        //   Orientation.lockToLandscape();
        // },2000)
        // StatusBar.setHidden(false, 'none'); // don't remove
        // StatusBar.setTranslucent(false); // don't remove
        // StatusBar.setBackgroundColor('#000000'); // you can remove
        // StatusBar.setBarStyle('light-content'); // you can remove
        setTimeout(() => {
          Orientation.lockToLandscape();
        }, 1000);
        setTimeout(() => {
          this.setState({landscapeLoading: false,hideControls:true});
        }, 2000);
      }
    });
    this._engine.addListener('UserJoined', (uid, elapsed) => {
      console.log(uid, 'the uidjoiajojfoajsdofj');
      let data = this.props.route?.params?.data;
      if (uid == data?.coach?.id) {
        setTimeout(() => {
          socketServices.emit('userdetail', {
            [data.id]: [this.props.userData.id, this.props.userData.name],
          });
          // this.timerInit();
        }, 2000);
      }

      console.log(uid, 'the uid value');
    });

    this._engine.addListener('UserOffline', (uid, reason) => {
      let data = this.props.route?.params?.data;
      if (uid === data?.coach?.id) {
        if (!this.state.isStreamEnd) {
          let dataParam = this.props.route?.params?.data;
          this.props.navigation.replace('ratings', {data: dataParam});
          // this.endCall();
        }
      }
    });

    // If Local user joins RTC channel
    this._engine.addListener('JoinChannelSuccess', (channel, uid, elapsed) => {
      console.log('JoinChannelSuccess', channel, uid, elapsed);

      // Set state variable to true
      this.setState({
        joinSucceed: true,
      });
    });
    this._engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    this._engine.setClientRole(ClientRole.Audience);
  };

  timerInit = () => {
    let data = this.props.route?.params?.data;
    let firstIntrval = this.state.intervals[0];
    let timeInit = firstIntrval.duration;
    if (firstIntrval?.duration_type === 'mins') {
      timeInit *= 60;
    }
    this.setState(
      {
        isHostAvail: true,
        timer: timeInit,
        initialTime: timeInit,
        intervalIndex: 0,
      },
      () => {
        if (this._timeInterval) {
          clearInterval(this._timeInterval);
        }
        this._timeInterval = setInterval(this.intervalHandler, 1000);
      },
    );
    showMessage({
      type: 'info',
      icon: 'info',
      message: 'Coach is live now!',
    });
    // Orientation.unlockAllOrientations();
  };

  endCall = async () => {
    const {isStreamEnd} = this.state;
    if (!!this._engine && !!this._engine.leaveChannel) {
      this._engine?.leaveChannel();
    }
    if (!isStreamEnd) {
      this.setState({isStreamEnd: true}, () => {
        this.props.navigation.goBack(null);
      });
    }
  };

  startCall = async (stramData) => {
    const {channel_id, token, uid} = stramData;
    // Join Channel using null token and channel name
    // console.log(uid, 'the token pojopjopjs');
    await this._engine?.joinChannel(token, channel_id, null, uid);
  };

  componentWillUnmount() {
    if (!!this._engine && !!this._engine.leaveChannel) {
      this._engine?.leaveChannel();
    }

    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    Orientation.lockToPortrait();
    socketServices.removeListener('start_call');
    socketServices.removeListener('getData');
    let data = this.props.route?.params?.data;
    socketServices.emit('userLeave', {
      [data.id]: [this.props.userData.id, this.props.userData.name],
    });
    // KeepAwake.deactivate();
    // setTimeout(()=>{
    //   Orientation.lockToPortrait();
    // },2000);
  }

  toggleControl = () => {
    this.setState((prevState) => ({
      ...prevState,
      hideControls: !prevState.hideControls,
    }));
  };

  render() {
    const {
      streamData,
      joinSucceed,
      isLoading,
      hideControls,
      isLandscape,
      isHostAvail,
      timer,
      totalClassDuration,
      totalTimePassed,
      startCounter,
      isCounterStarted,
      landscapeLoading,
      intervals,
    } = this.state;
    let data = this.props.route?.params?.data;
    let roomData = data.room;
    const widge = JSON.parse(roomData.widget_details);
    if (isLoading) {
      return <Loader isLoading={true} />;
    }
    if (!joinSucceed || !isHostAvail) {
      return <WaitingRoom data={data} />;
    }
    const currentActiveInterval = this.state.intervals[
      this.state.intervalIndex
    ];
    const {colorToshow, textColorWork} = getColorText(
      currentActiveInterval,
      widge,
    );

    console.log(intervals, 'the ajsdoj');
    return (
      <View style={{flex: 1}}>
        <RtcRemoteView.SurfaceView
          style={
            isLandscape ? styles.fullViewLandScape : styles.fullViewPortrait
          }
          uid={data?.coach?.id}
          channelId={streamData.channel_id || ''}
          renderMode={VideoRenderMode.FILL}
        />
        <TouchableWithoutFeedback onPress={this.toggleControl}>
          <View style={{...StyleSheet.absoluteFillObject, zIndex: 99}}>
            {timer > 0 && !(startCounter > 1) && hideControls && (
              <View style={styles.timerRow}>
                <View>
                  <AnimatedCircularProgress
                    size={100}
                    width={5}
                    duration={this.state.initialTime}
                    fill={(timer / this.state.initialTime) * 100}
                    backgroundWidth={4}
                    tintColor={colors.progressblue}
                    backgroundColor={colors.blackOpacity40}>
                    {(fill) => (
                      <Text style={styles.timerText}>
                        {fmtMSS(this.state.timer)}
                      </Text>
                    )}
                  </AnimatedCircularProgress>
                  <Text
                    style={[
                      styles.activityText,
                      {
                        color: colors.white,
                        maxWidth: 140,
                        textTransform: 'lowercase',
                        fontSize: 14,
                      },
                    ]}>
                    {!!currentActiveInterval &&
                      (currentActiveInterval?.description ||
                        currentActiveInterval.activity)}
                  </Text>
                </View>
                <View>
                  <Text
                    style={{
                      ...commonStyles.fontBold21,
                      color: colors.white,
                      paddingHorizontal: 10,
                      paddingVertical: 14,
                      borderRadius: 4,
                      maxWidth: 165,
                    }}>
                    {!!currentActiveInterval &&
                      (currentActiveInterval?.description ||
                        currentActiveInterval.activity)}
                  </Text>
                </View>
              </View>
            )}

            {!hideControls && (
              <View
                style={{
                  top: -20,
                  bottom: 0,
                  left: -20,
                  right: -20,
                  position: 'absolute',
                  backgroundColor: 'rgba(255,255,255,.55)',
                }}>
                <View style={{flex: 1, backgroundColor: 'rgba(0,0,0,.36)'}} />
              </View>
            )}

            {startCounter > 1 && isCounterStarted && (
              <View style={styles.counterContainer}>
                <Text style={styles.counterTxt}>{this.state.startCounter}</Text>
                <Text style={{...commonStyles.fontSize18, color: colors.white}}>
                  Your class will start in...
                </Text>
              </View>
            )}
            <View style={styles.counterContainer}>
              {!hideControls && (!(startCounter > 1) || !isCounterStarted) && !landscapeLoading&&(
                <TouchableOpacity onPress={this.endCall} style={styles.endBtn}>
                  <Text style={styles.endText}>exit live stream</Text>
                </TouchableOpacity>
              )}
            </View>

            {landscapeLoading && (
              <View style={styles.counterContainer}>
               <ActivityIndicator size="large" color={colors.progressblue} />
              </View>
            )}

            {!hideControls && (
              <View
                style={{bottom: 50, position: 'absolute', left: 30, right: 30}}>
                <ProgressBar
                  bgColor={colors.white}
                  theme={colors.progressblue}
                  progress={totalTimePassed / totalClassDuration}
                />
              </View>
            )}
          </View>
        </TouchableWithoutFeedback>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  userData: state.auth.userData,
});

export default connect(mapStateToProps)(LiveStreaming);

const styles = StyleSheet.create({
  max: {
    flex: 1,
  },
  buttonHolder: {
    height: 100,
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  button: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: '#0093E9',
    borderRadius: 25,
  },
  buttonText: {
    color: '#fff',
  },
  fullViewLandScape: {
    width: height,
    height: width,
  },
  fullViewPortrait: {
    height,
    width,
  },
  remoteContainer: {
    width: '100%',
    height: 150,
    position: 'absolute',
    top: 5,
  },
  remote: {
    flex: 1,
    width: height,
    height: width,
  },
  noUserText: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    color: '#0093E9',
  },
  counterContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  endBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: colors.white26,
    borderRadius: 56,
  },
  endText: {...commonStyles.fontSize15, color: colors.white},
  counterTxt: {
    // color: textColorWork,
    color: colors.white,
    fontFamily: fontFamily.bold,
    fontSize: 36,
  },
  timerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'absolute',
    bottom: 30,
    left: 50,
    right: 50,
    alignItems: 'center',
    margin: 10,
  },
  activityText: {
    ...commonStyles.fontSize24,
    textAlign: 'center',
    marginTop: 10,
  },
  timerText: {
    // color: textColorWork,
    fontFamily: fontFamily.bold,
    fontSize: 18,
    color: colors.white,
  },
});
