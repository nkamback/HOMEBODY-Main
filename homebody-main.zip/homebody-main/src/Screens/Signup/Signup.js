import React, {Component} from 'react';
import {Text, View, SafeAreaView, TouchableOpacity, Image} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {
  moderateScale,
  moderateScaleVertical,
} from '../../styles/responsiveSize';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import {OutlinedTextField} from 'react-native-material-textfield';
import colors from '../../styles/colors';
import imagePath from '../../constants/imagePath';
import TextOverLine from '../../components/TextOverLine';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import strings from '../../constants/lang';
import styles from './SignupStyles';
import validations from '../../utils/validations';
import {showError} from '../../utils/helperFunctions';
import GradientWrapper from '../../components/GradientWrapper';
import BorderTextInput from '../../components/BorderTextInput';

class Signup extends Component {
  state = {
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    confirmPassword: '',
  };
  onChangeText = (key) => (val) => {
    this.setState({[key]: val});
  };
  isValidData = (data) => {
    const error = validations(data);
    if (error) {
      showError(error);
      return;
    }
    return true;
  };
  onSignup = () => {
    const {firstName, lastName, password, confirmPassword, email} = this.state;
    const checkValid = this.isValidData({
      firstName,
      lastName,
      email,
      password,
      confirmPassword,
    });
    if (checkValid) {
      this.props.navigation.navigate('enterMobile', {...this.state});
    }
  };
  render() {
    const {email, firstName, lastName, password, confirmPassword} = this.state;

    return (
      <GradientWrapper colorsBg={[colors.gradientA, colors.gradientB]}>
        <KeyboardAwareScrollView
          keyboardShouldPersistTaps="handled"
          style={{flex: 1, paddingHorizontal: moderateScale(16)}}>
          <View style={styles.headerRow}>
            <TouchableOpacity
              hitSlop={hitSlopProp}
              onPress={() => this.props.navigation.goBack(null)}
              activeOpacity={0.7}>
              <Image
                style={{tintColor: colors.white}}
                source={imagePath.backblack}
              />
            </TouchableOpacity>
          </View>
          <View style={{marginBottom: 26}}>
            <Text
              style={{
                ...commonStyles.fontSize24,
                color: colors.white,
                textAlign: 'center',
              }}>
              Create an Account{' '}
            </Text>
            <Text style={[styles.fbBtnText, {textAlign: 'center'}]}>
              Already have an account?{' '}
              <Text
                onPress={() => this.props.navigation.navigate('login')}
                style={{color: colors.blueGreen}}>
                Login
              </Text>
            </Text>
          </View>
          <TouchableOpacity style={styles.fbBtn}>
            <Image source={imagePath.fbWhite} />
            <Text style={styles.fbBtnText}>Continue with Facebook</Text>
          </TouchableOpacity>
          <View style={{marginVertical: moderateScaleVertical(14)}}>
            <Text style={[styles.fbBtnText, {textAlign: 'center'}]}>or</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <View style={{flex: 1, marginRight: 5}}>
              <BorderTextInput
                placeholder={'First name'}
                onChangeText={this.onChangeText('firstName')}
                // leftIcon={imagePath.emailSmall}
                value={firstName}
              />
            </View>
            <View style={{flex: 1, marginLeft: 5}}>
              <BorderTextInput
                placeholder={'Last name'}
                onChangeText={this.onChangeText('lastName')}
                // leftIcon={imagePath.emailSmall}
                value={lastName}
              />
            </View>
          </View>
          <BorderTextInput
            placeholder={'Email address'}
            onChangeText={this.onChangeText('email')}
            keyboardType="email-address"
            value={email}
          />

          <BorderTextInput
            placeholder={'Create Password'}
            onChangeText={this.onChangeText('password')}
            secureTextEntry
            value={password}
          />
          <BorderTextInput
            placeholder={'Confirm Password'}
            onChangeText={this.onChangeText('confirmPassword')}
            secureTextEntry
            keyboardType="default"
            value={confirmPassword}
          />

          <ButtonWithLoader
            onPress={this.onSignup}
            btnStyle={{
              marginVertical: moderateScaleVertical(24),
              backgroundColor: colors.white26,
              borderColor: colors.white26,
            }}
            btnText="Signup"
          />
          <View style={{alignItems: 'center'}}>
            <Text
              style={{
                ...commonStyles.fontSize14,
                color: colors.textGrey,
                textAlign: 'center',
              }}>
              By signing up you agree to our
              <Text
                style={{color: colors.white, textDecorationLine: 'underline'}}>
                {' '}
                Terms of Use
              </Text>{' '}
              and
            </Text>
            <Text
              style={{
                ...commonStyles.fontSize14,
                textAlign: 'center',
                color: colors.white,
                textDecorationLine: 'underline',
              }}>
              {' '}
              Privacy Notice{' '}
            </Text>
          </View>
        </KeyboardAwareScrollView>
      </GradientWrapper>
    );
  }
}

export default Signup;
