import {StyleSheet} from "react-native";
import { moderateScale, moderateScaleVertical, textScale } from "../../styles/responsiveSize";
import colors from "../../styles/colors";
import fontFamily from "../../styles/fontFamily";
import commonStyles from "../../styles/commonStyles";


export default StyleSheet.create({
    headerRow:{
        marginVertical: moderateScaleVertical(16),
        alignItems: 'flex-start',
      },
      logoText:{
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: moderateScaleVertical(26),
      },
      fbBtn:{
        ...commonStyles.buttonRect,
        backgroundColor: colors.fbBlue,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: colors.fbBlue,
        marginBottom: 0,
      },
      fbBtnText:{
        marginLeft: 10,
        ...commonStyles.fontSize15,
        color: colors.white,
        borderColor: colors.fbBlue,
      }
})