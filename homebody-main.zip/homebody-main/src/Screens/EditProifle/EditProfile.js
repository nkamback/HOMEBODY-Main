import React, {Component} from 'react';
import {
  Text,
  View,
  Image,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Alert,
} from 'react-native';
import {connect} from 'react-redux';
import TextInputWithLabel from '../../components/TextInputWithLabel';
import ImagePicker from 'react-native-image-crop-picker';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import actions from '../../redux/actions';
import {showError, showSuccess} from '../../utils/helperFunctions';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import commonStyles from '../../styles/commonStyles';
import {exerciseImg} from '../../constants/constants';
import {androidCameraPermission} from '../../utils/permissions';
import GradientButton from '../../components/GradientButton';

class EditProfile extends Component {
  state = {
    name: this.props?.userData?.name,
    image: this.props?.userData?.avatar,
    isLoading: false,
  };
  componentDidMount() {}
  _onChangeText = (key) => (val) => {
    this.setState({[key]: val});
  };
  onCamera = () => {
    ImagePicker.openCamera({
      width: 100,
      height: 100,
      useFrontCamera: true,
      multiple: false,
      mediaType: 'photo',
    })
      .then((image) => {
        this.uploadImageApi(image);
      })
      .catch((error) => console.log('Image Picker error: ', error));
  };
  onGallery = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      multiple: false,
      cropping: true,
      mediaType: 'photo',
      smartAlbums: [
        'UserLibrary',
        'PhotoStream',
        'Panoramas',
        'Favorites',
        'AllHidden',
        'CloudShared',
        'RecentlyAdded',
        'SyncedAlbum',
        'Screenshots',
        'Imported',
        'Regular',
        'Bursts',
      ],
    })
      .then((image) => {
        this.uploadImageApi(image);
      })
      .catch((error) => console.log('Image Picker error: ', error));
  };

  uploadImageApi = (image) => {
    this.setState({isLoading: true});
    let imgData = new FormData();

    imgData.append('image[]', {
      uri: image.path,
      type: image.mime,
      name: 'img.png',
    });
    actions
      .uploadImage(imgData)
      .then((res) => {
        console.log(res);
        const resImg = res?.data?.images[0];
        this.setState({
          image: {
            orig_path: resImg?.orig_path_url,
            thumb_path: resImg?.thumb_path_url,
            origApiUrl: resImg?.orig_path,
            thumbPathUrl: resImg?.thumb_path,
          },
          isLoading: false,
        });
        console.log('the image has been uploaded succesfully');
      })
      .catch((error) => {
        this.setState({isLoading: false});
        console.log(error, 'the iamge upauosdfoafo faiild=[');
      });
  };
  onImageChange = async () => {
    const permissionStatus = await androidCameraPermission();
    if (permissionStatus || Platform.OS === 'ios') {
      Alert.alert(
        'Profile Picture',
        'Choose an option',
        [
          {text: 'Camera', onPress: this.onCamera},
          {text: 'Gallery', onPress: this.onGallery},
          {text: 'Cancel', onPress: () => {}},
        ],
        {cancelable: true},
      );
    }
  };
  isValidData = () => {
    let {name} = this.state;
    name = name.trim();
    if (!name) {
      showError(`Please enter  name`);
      return;
    }
    return true;
  };

  _onSubmit = () => {
    const {name, image} = this.state;
    const checkValid = this.isValidData();
    if (!checkValid) {
      return;
    }
    const apiData = {
      name,
    };
    if (!!image.origApiUrl) {
      apiData.image = {
        orig_path: image.origApiUrl,
        thumb_path: image.thumbPathUrl,
      };
    }
    console.log(apiData, 'hte api data uaoisdfjoj thats been sent');
    this.setState({isLoading: true});
    actions
      .updateProfile(apiData)
      .then((res) => {
        this.setState({isLoading: false});
        showSuccess('Profile updated successfully');
        this.props.navigation.popToTop();
        console.log(res, 'ther aofdojoasjfdojofjpojsdfojoj');
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  };
  render() {
    const {name, image, isLoading} = this.state;
    const {userData} = this.props;
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack
          centerText="Edit Profile"
          leftIcon={imagePath.crossWhite}
        />
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: moderateScale(20),
            paddingHorizontal: moderateScale(16),
          }}>
          <TouchableOpacity
            onPress={this.onImageChange}
            activeOpacity={1}
            style={{
              ...styles.imgBg,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={{uri: image?.thumb_path || exerciseImg}}
              style={styles.img}
            />
          </TouchableOpacity>

          <Text
            onPress={this.onImageChange}
            style={{
              ...commonStyles.fontSize15,
              color: colors.white,
              marginLeft: moderateScale(18),
            }}>
            {'Change your profile image'}
          </Text>
        </View>
        <View
          style={{
            flex: 1,
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <View style={{height: 20}} />
          <TextInputWithLabel
            value={name}
            onChangeText={this._onChangeText('name')}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
            }}
            // rightIcon={imagePath.verify}
            label="Name"
          />
          <TextInputWithLabel
            value={userData?.email}
            editable={false}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
              color: colors.blackOpacity40,
            }}
            // rightIcon={imagePath.verify}
            label="Email"
          />
          <TextInputWithLabel
            value={`${userData?.phone_code} ${userData.phone}`}
            editable={false}
            inputStyle={{
              borderWidth: 0,
              borderBottomWidth: 1,
              marginBottom: 10,
              color: colors.blackOpacity40,
            }}
            // rightIcon={imagePath.verify}
            label="Mobile Number"
          />
           <GradientButton
          colorsArray={[colors.btnBlue,colors.btnBlueB]}
          containerStyle={{marginTop:moderateScaleVertical(26)}}
            btnStyle={{borderRadius: 5}}
            onPress={this._onSubmit}
            btnText="Submit"
          />
        </View>
        <View style={{backgroundColor: colors.white}}>
         
        </View>
      </GradientWrapper>
    );
  }
}

const mapStateToProps = (state) => ({
  userData: state.auth.userData,
});

export default connect(mapStateToProps)(EditProfile);
const styles = StyleSheet.create({
  imgBg: {
    height: moderateScale(72),
    width: moderateScale(72),
    borderRadius: moderateScale(36),
    borderWidth: 3,
    borderColor: colors.themeMain,
    overflow: 'hidden',
  },
  img: {
    height: moderateScale(72),
    width: moderateScale(72),
  },
  imgBgContainer: {height: moderateScale(72), width: moderateScale(72)},
  headerContainer: {
    flexDirection: 'row',
    paddingHorizontal: moderateScale(16),
    marginVertical: moderateScaleVertical(28),
  },
});
