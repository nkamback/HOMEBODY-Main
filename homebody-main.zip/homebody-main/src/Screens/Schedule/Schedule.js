import React, {useEffect, useState} from 'react';
import {Text, View, FlatList, TouchableOpacity, Image} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import imagePath from '../../constants/imagePath';
import colors from '../../styles/colors';
import commonStyles, {hitSlopProp} from '../../styles/commonStyles';
import Card from '../../components/Card';
import {
  moderateScale,
  moderateScaleVertical,
  textScale,
} from '../../styles/responsiveSize';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import fontFamily from '../../styles/fontFamily';
import ButtonWithLoader from '../../components/ButtonWithLoader';
import ScheduleCard from '../../components/ScheduleCard';
import {getSelectedDateTime, showError} from '../../utils/helperFunctions';
import moment from 'moment';
import ListEmptyComponent from '../../components/ListEmptyComponent';
import actions from '../../redux/actions';
const Schedule = ({navigation, route}) => {
  const [state, setState] = useState({
    daysToAdd: 1,
    dateToShow: moment().format('DD MMM'),
    classesArray: [],
    isLoading: true,
  });

  useEffect(() => {
    let startDateTime = moment().utc();
    let endDateTime = moment().endOf('day').utc();
    let dateTimeQuery = `&start_date=${startDateTime.format(
      'YYYY-MM-DD',
    )}&start_time=${startDateTime.format(
      'HH:mm',
    )}&end_time=${endDateTime.format('HH:mm')}&end_date=${endDateTime.format(
      'YYYY-MM-DD',
    )}`;
    apiCall(dateTimeQuery);
  }, []);

  const apiCall = (dateTimeQuery = '') => {
    const {coachDetails} = route.params || {};
    updateState({isLoading: true});
    actions
      .coachSchedule(
        `/${coachDetails.id}?coach_id=${coachDetails.id}${dateTimeQuery}`,
      )
      .then((res) => {
        const {coach} = res.data;
        console.log(res);
        console.log(coach?.schedule);
        updateState({
          isLoading: false,
          classesArray: coach?.schedule[0]?.slots || [],
        });
      })
      .catch((error) => {
        console.log(error, 'the error');
        showError(error.message);
        updateState({isLoading: false});
      });
  };

  const moveToNewScreen = (screenName, data = {}) => () => {
    navigation.navigate(screenName, data);
  };

  const renderItemSchedule = ({item, index}) => {
    const {daysToAdd, dateToShow} = state;
    const slot = item;
    let startDateTimeForApi;
    console.log(item, 'the josjdofjoajojoj');
    var utcToLocal = moment(`${item.start_time}`, 'hh:mm A').format(
      'YYYY-MM-DD HH:mm:ss',
    );
    var utcToLocalTimeObj = moment.utc(utcToLocal).toDate();
    //combining local booking date and utc time converted to local time to make a local dateTime value that will be use to make utc object;
    let startDay = daysToAdd - 1; //days to add is the next day from selected day
    startDateTimeForApi = moment(
      `${moment().add(startDay, 'd').format('DD-MM-YYYY')} ${moment(
        utcToLocalTimeObj,
      ).format('HH:mm')}`,
      'DD-MM-YYYY HH:mm',
    ).utc();
  

    return (
      <ScheduleCard
        data={slot}
        key={String(index)}
        onPress={moveToNewScreen('classDetails', {
          data: slot,
          selectedDateUTC: startDateTimeForApi,
        })}
        containerStyle={{marginBottom: 10}}
      />
    );
  };

  const onPressNext = () => {
    const {daysToAdd} = state;
    let dateObj = moment().add(daysToAdd, 'd');
    let startDateTime = dateObj.startOf('d').utc();
    let endDateTime = moment().add(daysToAdd, 'd').endOf('day').utc();
    let dateTimeQuery = `&start_date=${startDateTime.format(
      'YYYY-MM-DD',
    )}&start_time=${startDateTime.format(
      'HH:mm',
    )}&end_time=${endDateTime.format('HH:mm')}&end_date=${endDateTime.format(
      'YYYY-MM-DD',
    )}`;
    let query = dateTimeQuery;
    apiCall(dateTimeQuery);
    updateState({
      daysToAdd: daysToAdd + 1,
      dateToShow: moment().add(daysToAdd, 'd').format('DD MMM'),
    });
  };

  const updateState = (data = {}) => {
    setState((state) => ({...state, ...data}));
  };

  const {coachDetails} = route.params || {};
  const {daysToAdd, dateToShow, classesArray} = state;
  console.log(classesArray, 'the class arrey');
  return (
    <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={state.isLoading}>
      <HeaderWithCenterTextBack
        centerText="Schedule"
        customRight={() => {
          if (daysToAdd >= 7) {
            return <View />;
          }
          return (
            <View>
              <Text
                style={{
                  textAlign: 'center',
                  ...commonStyles.fontSize12,
                  color: colors.white,
                }}>
                Next Day
              </Text>

              <TouchableOpacity
                hitSlop={hitSlopProp}
                onPress={onPressNext}
                style={{alignItems: 'center'}}>
                <Image source={imagePath.arrowForward} />
              </TouchableOpacity>
            </View>
          );
        }}
      />
      <View
        style={{
          flex: 1,
          backgroundColor: colors.white,
          paddingTop: moderateScale(16),
        }}>
        <FlatList
          data={classesArray || []}
          keyExtractor={(item, index) => String(index)}
          ListHeaderComponent={() => (
            <View style={{justifyContent:'center',alignItems:'center',marginBottom:10}}>
              <Text
                style={{...commonStyles.fontSize18, color: colors.themeMain}}>
                {daysToAdd == 1 ? 'Today' : dateToShow}
              </Text>
            </View>
          )}
          contentContainerStyle={{flexGrow: 1}}
          ListEmptyComponent={() => (
            <ListEmptyComponent isLoading={state.isLoading} />
          )}
          renderItem={renderItemSchedule}
        />
        {/* <Text style={{...commonStyles.fontSize14, textAlign: 'center'}}>
          Today
        </Text>
        <ScheduleCard
          onPress={moveToNewScreen('classDetails')}
          containerStyle={{marginBottom: 10}}
        />
        <ScheduleCard containerStyle={{marginBottom: 10}} /> */}
      </View>
    </GradientWrapper>
  );
};

export default Schedule;
