import React, {Component} from 'react';
import {Text, View} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import TransactionCard from '../../components/TransactionCard';
import commonStyles from '../../styles/commonStyles';
import fontFamily from '../../styles/fontFamily';
import {moderateScale} from '../../styles/responsiveSize';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';
import moment from 'moment';
import { ScrollView } from 'react-native-gesture-handler';

export default class TransactionMonthHistory extends Component {
  state = {
    transactionsArray: [],
    isLoading: true,
    data: {},
  };
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, {data});
  };
  componentDidMount() {
    const {data = {}} = this.props.route?.params || {};
    actions
      .getTransactionsList(`?month_id=${data.month_id}`)
      .then((res) => {
        console.log(res, 'ther reuslt');
        const {transactions} = res.data;
        this.setState({
          isLoading: false,
          transactionsArray: transactions[0]?.transactions || [],
          data: transactions[0],
        });
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  }
  render() {
    const {data, transactionsArray,isLoading} = this.state;
    return (
      <GradientWrapper  start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Transaction History" />
        <ScrollView
          style={{
            flex: 1,
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <Text
            style={{
              ...commonStyles.headingText,
              fontFamily: fontFamily.bold,
              marginVertical: 10,
            }}>
            {data.formatted_month}
          </Text>
          {transactionsArray.map((item, index) => {
            return (
              <TransactionCard
                key={String(index)}
                centerLowerText=""
                data={item}
                centerHeading={item?.class?.name||""}
                onPress={this.moveToNewScreen('transactionDetails', item)}
              />
            );
          })}
        </ScrollView>
      </GradientWrapper>
    );
  }
}
