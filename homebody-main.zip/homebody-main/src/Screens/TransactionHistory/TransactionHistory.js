import React, {Component} from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import GradientWrapper from '../../components/GradientWrapper';
import HeaderWithCenterTextBack from '../../components/HeaderWithCenterTextBack';
import colors from '../../styles/colors';
import {moderateScale, textScale} from '../../styles/responsiveSize';
import commonStyles from '../../styles/commonStyles';
import {exerciseImg} from '../../constants/constants';
import imagePath from '../../constants/imagePath';
import TransactionCard from '../../components/TransactionCard';
import moment from 'moment';
import actions from '../../redux/actions';
import {showError} from '../../utils/helperFunctions';

export default class TransactionHistory extends Component {
  state = {
    isLoading: true,
    currentMonthTransactions: {},
    transactionsMonthArray: [],
  };
  componentDidMount() {
    actions
      .getTransactionsList('')
      .then((res) => {
        console.log(res, 'ther reuslt');
        const {transactions} = res.data;
        this.setState({
          isLoading: false,
          currentMonthTransactions: transactions[0],
          transactionsMonthArray: transactions.slice(1),
        });
      })
      .catch((error) => {
        this.setState({isLoading: false});
        showError(error.message);
      });
  }
  moveToNewScreen = (screenName, data = {}) => () => {
    this.props.navigation.navigate(screenName, {data});
  };
  renderTransaction = ({item, index}) => {
    return (
      <TransactionCard
        centerLowerText=""
        data={item}
        key={String(index)}
        centerHeading={item?.class?.name||""}
        onPress={this.moveToNewScreen('transactionDetails', item)}
      />
    );
  };
  render() {
    const {
      isLoading,
      currentMonthTransactions,
      transactionsMonthArray,
    } = this.state;
    const curTransactions = currentMonthTransactions?.transactions || [];
    console.log(transactionsMonthArray);
    return (
      <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }} isLoading={isLoading}>
        <HeaderWithCenterTextBack centerText="Transaction History" />
        <ScrollView
          style={{
            flex: 1,
            backgroundColor: colors.white,
            paddingHorizontal: moderateScale(16),
          }}>
          <Text style={{...commonStyles.fontBold16, marginVertical: 10}}>
            This Month
          </Text>

          {curTransactions.map((val, index) =>
            this.renderTransaction({item: val, index}),
          )}
          {transactionsMonthArray.length > 0 && (
            <View>
              <Text style={{...commonStyles.fontBold16, marginVertical: 10}}>
                Previous
              </Text>
              {transactionsMonthArray.map((month, index) => {
                return (
                  <TransactionCard
                    centerHeading={`${moment(month.month_id, 'YYYY-MM').format(
                      'MMM',
                    )}`}
                    onPress={() =>
                      this.props.navigation.navigate(
                        'transactionMonthHistory',
                        {data: month},
                      )
                    }
                    key={String(index)}
                    centerLowerText={`${month.transactions} Transactions`}
                    isStatic
                  />
                );
              })}
            </View>
          )}
        </ScrollView>
      </GradientWrapper>
    );
  }
}
