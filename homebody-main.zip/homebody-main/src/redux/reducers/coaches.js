import types from "../types";
import actions from "../actions";

const initial_state = {
    favCoaches:[],
    favLoading:false,
    likesObj:{}

}

export default function (state = initial_state, action) {

    switch (action.type) {
        case types.FAV_COACH_LOADING: {
         
            return {...state,favLoading:true };
        }

        case types.GET_FAV_COACHES: {
            const data = action.payload;
            return { ...state, favCoaches:data,favLoading:false }
        }

        case types.FAV_COACH_LOADING_END:{
            return {...state,favLoading:false };
        }

        case types.TOGGLE_LIKE_UNLIKE:{
            console.log(action.payload,'the data value is')
            return {...state,likesObj:action.payload}
        }

        default: {
            return { ...state }
        }
    }
}