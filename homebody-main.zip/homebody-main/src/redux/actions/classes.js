import store from '../store';
import {setUserData, apiPost, apiGet} from '../../utils/utils';
import types from '../types';
import {
  CLASS_DETAILS,
  BOOKING_DETAILS,
  BOOK_CLASS,
  CLASSES_LIST,
  STREAM_JOIN,
  UPCOMING_CLASSES
} from '../../config/urls';

const {dispatch} = store;

export function getClassDetails(query = '') {
  return apiGet(CLASS_DETAILS + query);
}

export function bookingDetails(data) {
  return apiPost(BOOKING_DETAILS, data);
}

export function bookClass(data) {
  return apiPost(BOOK_CLASS, data);
}

export function getClassesList(query) {
  return apiGet(CLASSES_LIST + query);
}
export function joinStream(data) {
  return apiPost(STREAM_JOIN, data);
}
export function getBookedUpcomingClasses(query="") {
    return apiGet(UPCOMING_CLASSES + query);
  }