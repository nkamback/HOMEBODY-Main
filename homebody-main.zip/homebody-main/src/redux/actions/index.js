import * as auth from "./auth";
import * as coaches from "./coaches";
import * as home from "./home";
import * as classes from "./classes";
import * as payments from './payments';
import * as notifications from "./notififications";
import * as common from "./common";
export default {
    ...auth,
    ...coaches,
    ...home,
    ...classes,
    ...payments,
    ...notifications,
    ...common


}