import store from '../store';
import { setUserData, apiPost,apiGet } from '../../utils/utils';
import types from '../types';
import {HOME_API,UPDATE_API_TOKEN } from '../../config/urls';

const {dispatch}=store;


export function getHomeData(query=""){
    return apiGet(HOME_API+query);
}

export function updateFcmToken(data){
    return apiPost(UPDATE_API_TOKEN,data);
}