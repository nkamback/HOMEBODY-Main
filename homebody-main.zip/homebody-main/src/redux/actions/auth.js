import store from '../store';
import {setUserData, apiPost, getUserData} from '../../utils/utils';
import types from '../types';
import {
  LOGIN_API,
  SIGNUP_API,
  VERIFY_OTP,
  SOCAIL_LOGIN,
  FORGOT_PASSWORD,
  CHANGE_PASSWORD,
  UPDATE_PROFILE,
  LOGOUT,
} from '../../config/urls';
const {dispatch} = store;

const saveUserData = (data) => {
  dispatch({
    type: types.LOGIN,
    payload: data,
  });
};

export function signup(data) {
  return apiPost(SIGNUP_API, data);
}

export function verifyOtp(data) {
  return new Promise((resolve, reject) => {
    apiPost(VERIFY_OTP, data)
      .then((res) => {
        setUserData(res.data.user).then((suc) => {
          saveUserData(res.data.user);
          resolve(res);
        });
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function login(data) {
  return new Promise((resolve, reject) => {
    apiPost(LOGIN_API, data)
      .then((res) => {
        setUserData(res.data.user).then((suc) => {
          saveUserData(res.data.user);
          resolve(res);
        });
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function updateProfile(data) {
  return new Promise((resolve, reject) => {
    apiPost(UPDATE_PROFILE, data)
      .then((res) => {
        console.log(res, 'the result value');
        getUserData().then((userData) => {
          const updatedData = {...userData, ...res?.data?.profile};
          saveUserData(updatedData);
          console.log(updatedData)
          setUserData(updatedData).then((suc) => {
            resolve(res);
          });
        });
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function socialLogin(data) {
  return new Promise((resolve, reject) => {
    apiPost(SOCAIL_LOGIN, data)
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export const forgotPassword = (data) => {
  return apiPost(FORGOT_PASSWORD, data);
};

export const changePassword = (data) => {
  return apiPost(CHANGE_PASSWORD, data);
};


export function logout() {
  return apiPost(LOGOUT);
}

export const updateInternetConnection = (data) => {
  dispatch({
    type: types.NO_INTERNET,
    payload: data,
  });
};
