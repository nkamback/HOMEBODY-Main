import store from '../store';
import { setUserData, apiPost,apiGet } from '../../utils/utils';
import types from '../types';
import { GET_COACHES,FAVORITE_COACHES_LIST,SET_UNSET_FAV_COACH,COACH_SCHEDULE } from '../../config/urls';

const {dispatch}=store;


export function getCoaches(query=""){
    return apiGet(GET_COACHES+query);
}

export function getFavCoaches(query=""){
    dispatch({type:types.FAV_COACH_LOADING});
    return new Promise((resolve,reject)=>{
        apiGet(FAVORITE_COACHES_LIST+query).then(res=>{
            dispatch({
                type:types.GET_FAV_COACHES,
                payload:res.data.favorite_coaches.list
            })
            resolve(res);

        }).catch(error=>{
            dispatch({type:types.FAV_COACH_LOADING_END})
            reject(error);

        })
    })
}

export function setUnsetFavCoach(data){
    return apiPost(SET_UNSET_FAV_COACH,data);
}


export function coachSchedule(query){
    return apiGet(COACH_SCHEDULE+query);
}