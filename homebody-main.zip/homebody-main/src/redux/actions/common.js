import store from '../store';
import { setUserData, apiPost,apiGet } from '../../utils/utils';
import types from '../types';
import {CONTACT_US,UPLOAD_IMAGE,RATINGS } from '../../config/urls';

const {dispatch}=store;


export function contactUs(data){
    return apiPost(CONTACT_US,data);
}
export function rateClassCoach(data){
    return apiPost(RATINGS,data);
}
export function uploadImage(data={}){
    const headers = {'Content-Type': 'multipart/form-data'};
    return apiPost(UPLOAD_IMAGE,data,headers);
}
