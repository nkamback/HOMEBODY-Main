import store from '../store';
import { setUserData, apiPost,apiGet } from '../../utils/utils';
import types from '../types';
import { SAVE_CARD,TRANSACTIONS_LIST } from '../../config/urls';

const {dispatch}=store;


export function saveCard(data){
    return apiPost(SAVE_CARD,data);
}

export function getTransactionsList(query="") {
    return apiGet(TRANSACTIONS_LIST + query);
  }

