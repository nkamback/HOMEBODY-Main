import store from '../store';
import { setUserData, apiPost,apiGet } from '../../utils/utils';
import types from '../types';
import {GET_NOTIFICATIONS } from '../../config/urls';

const {dispatch}=store;


export function getNotifications(query=""){
    return apiGet(GET_NOTIFICATIONS+query);
}
