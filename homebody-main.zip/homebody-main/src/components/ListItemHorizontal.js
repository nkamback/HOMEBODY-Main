import React from 'react';
import {View,TouchableOpacity, Text,Image} from 'react-native';
import commonStyles from '../styles/commonStyles';
import colors from '../styles/colors';
import { moderateScaleVertical } from '../styles/responsiveSize';

export default function ListItemHorizontal({label,  iconLeft, disabled=true, activeOpacity=1,onPress=()=>{}, value,continerStyle={},labelStyle={},valueStyle={},tintColor}) {
  return (
    <TouchableOpacity disabled={disabled} onPress={onPress} activeOpacity={activeOpacity} style={{flexDirection: 'row',marginBottom:moderateScaleVertical(8),...continerStyle}}>
      {!!iconLeft?<Image style={[!!tintColor&&{tintColor}]} source={iconLeft}/>:
      <Text style={{...commonStyles.fontSize14, color: colors.blackOpacity90,...labelStyle}}>
        {label}
      </Text>}
      <Text
        style={{
          ...commonStyles.fontSize14,
          color: colors.blackOpacity40,
          flex:1,
          marginLeft: 5,
          ...valueStyle
        }}>
        {value}
      </Text>
    </TouchableOpacity>
  );
}
