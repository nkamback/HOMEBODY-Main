import React, {Component} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  Dimensions,
  StyleSheet,

} from 'react-native';
import Orientation from 'react-native-orientation';
// import {} from 'react-native-video'
import Video from "../libs/af-video"
import colors from '../styles/colors';


const {width, height} = Dimensions.get('window');
class VideoPlayer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      videoUrl:
       props.url|| "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"
    };
  }
  
  handleBackPress = () => {
    Orientation.lockToPortrait();
    if(this.props.onPress){
      this.props.onPress();
      return;
    }
    this.props.navigation.goBack(null);
  };
  componentWillUnmount(){
    
  }

  render() {
    return (
      <SafeAreaView style={{flex: 1, backgroundColor: colors.black}}>
        <View style={{flex: 1, justifyContent: 'center'}}>
          <Video
            autoPlay
            fullScreenOnly
            onMorePress={this.handleBackPress}
            // rotateToFullScreen
            lockPortraitOnFsExit
            url={this.state.videoUrl} // Can be a URL or a local file.
            ref={(ref) => {
              this.player = ref;
            }} // Store reference
            // onBuffer={this.onBuffer} // Callback when remote video is buffering
            ignoreSilentSwitch={"ignore"}
            onError={this.handleBackPress} // Callback when video cannot be loaded
            style={styles.backgroundVideo}
            // onFullScreen={(fullscreen)=>{
            //   if(!fullscreen){
            //     this.handleBackPress()
            //   }
            // }}
          />
        </View>
      </SafeAreaView>
    )
  }
}

export default VideoPlayer;

const styles = StyleSheet.create({
  backgroundVideo: {},
});
