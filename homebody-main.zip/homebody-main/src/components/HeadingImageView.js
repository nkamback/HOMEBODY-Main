import React from 'react';
import {View, Text, ImageBackground, TouchableOpacity} from 'react-native';
import commonStyles from '../styles/commonStyles';
import {moderateScaleVertical} from '../styles/responsiveSize';
import colors from '../styles/colors';
import ButtonWithLoader from './ButtonWithLoader';
export default function HeadingImageView({
  source,
  label = 'Virtual Classes',
  btnText = 'View',
  heading = 'VIRTUAL CLASSES',
  containerStyle = {},
  onPress = () => {},
}) {
  var w = Math.floor(Math.random() * 256);
  var x = Math.floor(Math.random() * 256);
  var y = Math.floor(Math.random() * 256);
  var z = 0.3;
  var rgbaColor = 'rgba(' + w + ',' + x + ',' + y + ',' + z + ')';
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={containerStyle}>
      {/* <Text
        style={{
          ...commonStyles.fontSize14,
          color: colors.headingGrey,
          textTransform: 'uppercase',
        }}>
        {heading}
      </Text> */}
      <ImageBackground
        style={{
          backgroundColor: rgbaColor,
          minHeight: moderateScaleVertical(152),
          justifyContent: 'center',
          alignItems: 'center',
          // marginTop: 16,
          borderRadius: 10,
        }}
        imageStyle={{borderRadius: 10}}
        source={source}>
        <View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: colors.blackOpacity25,
            borderRadius: 10,
          }}
        />
        <Text style={{...commonStyles.fontBold18, color: colors.white}}>
          {label}
        </Text>

        {/* <View
          style={{
            backgroundColor: colors.white,
            height: undefined,
            paddingVertical: 5,
            borderColor: colors.white,
            borderRadius:4,
            marginTop:15,
            paddingHorizontal: 15,
          }}>
          <Text
            style={{...commonStyles.fontSize15, color: colors.blackOpacity90}}>
            {btnText}
          </Text>
        </View> */}
      </ImageBackground>
    </TouchableOpacity>
  );
}
