import React from 'react';
import {View, Text, SafeAreaView, StatusBar} from 'react-native';
import Loader from './Loader';
import colors from '../styles/colors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const WrapperContainer = ({children, isLoading,statusBarColor=colors.blueMain,barStyle="light-content"}) => {
  const insets=useSafeAreaInsets();
  return (
    <SafeAreaView style={{flex: 1,backgroundColor:statusBarColor}}>
      <StatusBar backgroundColor={statusBarColor} barStyle={barStyle} />
      <View style={{height:insets.top}}/>
      <View style={{backgroundColor:colors.white,flex:1}}>
      {children}
      </View>
      <Loader isLoading={isLoading} />
    </SafeAreaView>
  );
};

export default WrapperContainer;
