import React from 'react';
import {View, Text} from 'react-native';
import { moderateScaleVertical, moderateScale, textScale } from '../styles/responsiveSize';
import commonStyles from '../styles/commonStyles';
import colors from '../styles/colors';
import fontFamily from '../styles/fontFamily';


const NotificationCard = ({title,time,text}) => {
	return (
		<View style={{marginBottom: moderateScaleVertical(24)}}>
            <View style={{flexDirection: 'row',justifyContent:'space-between',alignItems:'center'}}>
			<Text
				style={{
					...commonStyles.fontSize16,
					color: colors.black ,
					fontFamily:fontFamily.medium
				}}>
				{title}
			</Text>
            <Text style={{...commonStyles.fontSize12, textAlignVertical: 'top', color: colors.blackOpacity40}}>
					{time}
				</Text>
			</View>
				<Text
					style={{
                        marginTop:4,
						...commonStyles.fontSize14,
						color: colors.blackOpacity60,
						lineHeight: textScale(20),
					}}>
					{text}
				</Text>
		
			
		</View>
	);
};

export default NotificationCard;
