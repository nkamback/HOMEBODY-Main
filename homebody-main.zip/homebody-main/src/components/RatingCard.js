import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import ProgressiveImage from './ProgressiveImage';
import {
  textScale,
  moderateScale,
  moderateScaleVertical,
} from '../styles/responsiveSize';
import imagePath from '../constants/imagePath';
import colors from '../styles/colors';
import commonStyles from '../styles/commonStyles';
import { exerciseImg } from '../constants/constants';


export default function RatingCard({data}) {
  console.log(data,'the data user name')
  return (
    <View style={{flexDirection: 'row',marginBottom:10}}>
      <View>
        <ProgressiveImage
          source={{uri:data?.user?.profile_image|| exerciseImg}}
          isCircular
          height={32}
          width={32}
        />
      </View>
      <View style={{flex: 1, marginLeft: moderateScale(12)}}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <Text style={{...commonStyles.headingText, fontSize: textScale(13)}}>
            {data?.user?.name}
          </Text>
          <Text
            style={{...commonStyles.fontSize13, color: colors.blackOpacity70}}>
            {/* 10m 32s */}
          </Text>
        </View>
        <Text
          style={{
            ...commonStyles.fontSize14,
            color: colors.blackOpacity70,
          }}>
          <Image style={{tintColor:colors.themeMain}} source={imagePath.star} /> {data.rating}
        </Text>
        <Text
          style={{
            ...commonStyles.fontSize12,
            lineHeight: textScale(20),
            color: colors.blackOpacity40,
          }}>
         {data?.comment}
        </Text>
      </View>
    </View>
  );
}
