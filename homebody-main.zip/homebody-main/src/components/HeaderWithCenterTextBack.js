import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import colors from '../styles/colors';
import imagePath from '../constants/imagePath';
import commonStyles, {hitSlopProp} from '../styles/commonStyles';
import { moderateScale } from '../styles/responsiveSize';

export default function HeaderWithCenterTextBack({
  onPressLeft = null,
  leftIcon=imagePath.backblack,
  customRight,
  leftStyle = {},
  rightIcon = null,
  centerText,
  hideLeft=false,
  onPressRight=()=>{}
}) {
  const navigation = useNavigation();
  return (
    <View
      style={{
        flexDirection: 'row',
        minHeight: 56,
        paddingHorizontal:moderateScale(16),
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
     {hideLeft?<View style={{width:30}} />: <TouchableOpacity
        activeOpacity={0.7}
        style={{minWidth:30}}
        hitSlop={hitSlopProp}
        onPress={onPressLeft ? onPressLeft : () => navigation.goBack(null)}>
        <Image
          style={{tintColor: colors.white, ...leftStyle}}
          source={leftIcon}
        />
      </TouchableOpacity>}
     {!!centerText&& <Text
        style={{
          flex: 1,
          ...commonStyles.fontBold18,
          textAlign: 'center',
          color: colors.white,
        }}>
       {centerText}
      </Text>}

      {!!rightIcon ? (
        <TouchableOpacity
          activeOpacity={0.7}
          hitSlop={hitSlopProp}
          onPress={onPressRight}>
          <Image source={rightIcon} />
        </TouchableOpacity>
      ) : (
       customRight?customRight(): <View style={{width: 30}} />
      )}
    </View>
  );
}
