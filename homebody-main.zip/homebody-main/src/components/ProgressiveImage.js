import React from 'react';
import { View, StyleSheet, Animated, ActivityIndicator,Image } from 'react-native';
import FastImage from 'react-native-fast-image'
import { DotIndicator as Bubbles, } from 'react-native-indicators';
import { moderateScaleVertical,moderateScale } from '../styles/responsiveSize';
import colors from '../styles/colors';

const AnimatedFastImage=Animated.createAnimatedComponent(FastImage);
class ProgressiveImage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showIndicator: true,
      randomColors: ''
    };
  }

  componentDidMount() {
    var w = Math.floor(Math.random() * 256);
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = 0.3
    var rgbaColor = "rgba(" + w + "," + x + "," + y + "," + z + ")";
    //console.log(rgbaColor)
    
    this.setState({
      randomColors: rgbaColor
    })
  }
  thumbnailAnimated = new Animated.Value(0);

  imageAnimated = new Animated.Value(0);

  handleThumbnailLoad = () => {

      Animated.timing(this.thumbnailAnimated, {
        toValue: 1,
        useNativeDriver:false
      }).start();
      this.setState({
        showIndicator: false
      })
    
  }

  onImageLoad = () => {

      Animated.timing(this.imageAnimated, {
        toValue: 1,
        useNativeDriver:false
      }).start();
      this.setState({
        showIndicator: false
      })
    

  }

  render() {
    const {
      thumbnailSource,
      source,
      style={},
      bgStyle = {},
      resizeMode=FastImage.resizeMode.cover,
      height,
      width,
      containerStyle={},
      isCircular=false,
      ...props
    } = this.props;
   if(isCircular){
     containerStyle.borderRadius=100;
     style.borderRadius=100;
   }
    const {randomColors,showIndicator}=this.state;
    let extraProp={};
    if(height){
      extraProp.height=height
    }
    if(width){
      extraProp.width=width;
    }

    return (
      <View style={{ ...styles.container ,backgroundColor: this.state.randomColors,...extraProp, ...containerStyle, }}>

        {
          showIndicator?
            <View style={{flex: 1, alignItems: 'center',justifyContent:'center' }}>
              {isCircular?<ActivityIndicator color={colors.themeMain} />:<Bubbles size={10} color="#73B8C1" />}
            </View>
            : <View />

        }
        <AnimatedFastImage
          resizeMode={resizeMode}
          source={source}
          style={[{...extraProp},style, {...styles.imageOverlay, opacity: this.thumbnailAnimated }]}
          onLoad={this.handleThumbnailLoad}
          blurRadius={1}
        />
        <AnimatedFastImage
          resizeMode={resizeMode}
          source={source}
          style={[styles.imageOverlay, { opacity: this.imageAnimated,...extraProp }, style]}
          onLoad={this.onImageLoad}
        />


      </View>
    );
  }
}

const styles = StyleSheet.create({
  imageOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    top: 0,
    borderRadius:4,
  },
  container: {
    borderRadius:4,
    overflow: 'hidden',
    height: moderateScale(152),
    width:moderateScale(264),
    // flex: 1
    //height: 160,
  },
});

export default ProgressiveImage;