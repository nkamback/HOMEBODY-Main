import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import colors from '../styles/colors';
import {
  moderateScaleVertical,
  moderateScale,
  textScale,
} from '../styles/responsiveSize';
import commonStyles from '../styles/commonStyles';
import imagePath from '../constants/imagePath';
import {exerciseImg} from '../constants/constants';

export default function TransactionCard({
  isStatic = false,
  data={},
  onPress = () => {},
  centerHeading = 'Core Killer',
  centerLowerText="4 Transactions"
}) {
  const classData=data.class||{};
  
  return (
    <TouchableOpacity
    onPress={onPress}
      activeOpacity={0.7}
      style={{
        flexDirection: 'row',
        borderBottomColor: colors.blackImgOverlay,
        borderBottomWidth: 1,
        paddingBottom: moderateScale(20),
        marginBottom: moderateScale(20),
      }}>
      {isStatic ? (
        <Image
          source={imagePath.transactionBox}
          style={{
            marginRight: moderateScale(16),
          }}
        />
      ) : (
        <Image
          source={{uri: data?.class?.banner_image||exerciseImg}}
          style={{
            height: moderateScale(64),
            width: moderateScale(64),
            marginRight: moderateScale(16),
            borderRadius: 4,
          }}
        />
      )}
      <View style={{justifyContent: 'space-between', flex: 1}}>
        <Text style={{...commonStyles.headingText, fontSize: textScale(14)}}>
          {centerHeading}
        </Text>
        {!isStatic && (
          <Text style={{...commonStyles.fontSize13, color: colors.black}}>
            Payment method: Card
          </Text>
        )}
        <Text
          style={{...commonStyles.fontSize13, color: colors.blackOpacity40}}>
         {centerLowerText}
        </Text>
      </View>
      <View style={{justifyContent: 'space-between'}}>
        {!isStatic && (
          <Text style={{...commonStyles.headingText, fontSize: textScale(14)}}>
            ${classData.price}
          </Text>
        )}
        <Image style={{alignSelf: 'flex-end'}} source={imagePath.arrowNext} />
      </View>
    </TouchableOpacity>
  );
}
