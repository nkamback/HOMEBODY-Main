import React from 'react';
import { StyleSheet, TouchableOpacity, Image } from 'react-native';
import { moderateScale } from '../styles/responsiveSize';
import { spacing } from '../styles/spacing';



const RoundImgComp = ({
    circularImgStyle = {},
    circularImg = {},

}) => {
    return (
        <Image
            style={{ ...styles.img, ...circularImgStyle }}
            source={{ uri: circularImg }}
        />
    )
};

const styles = StyleSheet.create({

    img: {
        width: moderateScale(38),
        height: moderateScale(38),
        borderRadius: moderateScale(38 / 2)
    }
});

export default RoundImgComp;