import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import commonStyles from '../styles/commonStyles';
import {moderateScale, moderateScaleVertical} from '../styles/responsiveSize';
import fontFamily from '../styles/fontFamily';
import colors from '../styles/colors';
import imagePath from '../constants/imagePath';
import ProgressiveImage from './ProgressiveImage';
import {exerciseImg} from '../constants/constants';
import ToogleFavCoach from './ToogleFavCoach';

function CoachCard({data = {}, onPress}) {
  const navigation = useNavigation();
  console.log(data, 'COCOCOCOCOthe data value');
  return (
    <TouchableOpacity
      onPress={() => {
        navigation.navigate('coachDetails', {data});
        if (onPress) {
          onPress();
        }
      }}
      style={{
        ...commonStyles.shadowStyle,
        paddingHorizontal: moderateScale(10),
        marginHorizontal: moderateScale(16),
        paddingVertical: moderateScaleVertical(16),
        flexDirection: 'row',
        marginBottom: 5,
      }}>
      <ProgressiveImage
        source={{uri: data?.avatar?.thumb_path || exerciseImg}}
        isCircular
        containerStyle={{
          height: moderateScale(88),
          width: moderateScale(88),
        }}
        style={{height: moderateScale(88), width: moderateScale(88)}}
      />
      <View
        style={{
          flex: 1,
          marginLeft: moderateScale(16),
          justifyContent: 'space-between',
        }}>
        <View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            <Text style={commonStyles.headingText}>{data?.name}</Text>
            <ToogleFavCoach data={data} />
          </View>
          <Text
            numberOfLines={1}
            style={{...commonStyles.fontSize13, color: colors.blackOpacity40,lineHeight:20}}>
            <Image style={{tintColor:colors.gradientA}} source={imagePath.star} />
            <Text style={{color: colors.blackOpacity70}}>
              {' '}
              {data.avg_rating}
            </Text>
          </Text>
        </View>
        <Text
          numberOfLines={1}
          style={{...commonStyles.fontSize14, color: colors.blackOpacity40}}>
          {data?.about}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

export default CoachCard;
