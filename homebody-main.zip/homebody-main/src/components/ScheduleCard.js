import React from 'react'
import { View, Text,TouchableOpacity } from 'react-native'
import ButtonWithLoader from './ButtonWithLoader'
import commonStyles from '../styles/commonStyles'
import colors from '../styles/colors'
import fontFamily from '../styles/fontFamily'
import { moderateScale, moderateScaleVertical, textScale } from '../styles/responsiveSize'
import { fmtMSS } from '../utils/helperFunctions'
 
export default function ScheduleCard({containerStyle={},onPress=()=>{},data={},startDate}) {
  console.log(data,'the data value schedule care')
    return (
        <TouchableOpacity
            onPress={onPress}
        style={{
          ...commonStyles.shadowStyle,
          flexDirection: 'row',
          marginHorizontal: moderateScale(16),
          paddingHorizontal: moderateScale(12),
          paddingVertical: moderateScale(8),
          ...containerStyle
        }}>
        <View
          style={{
            alignItems: 'center',
            paddingRight: moderateScale(8),
            borderRightWidth: 0.7,
            borderRightColor: colors.blackOpacity25,
          }}>
            {!!startDate&&<Text style={{...commonStyles.fontSize14,color:colors.black}}>
              {startDate}
              </Text>}
          <Text
            style={{
              ...commonStyles.fontSize14,
              fontFamily: fontFamily.medium,
              color: colors.blackOpacity90,
            }}>
            {data.time}
          </Text>
          <Text
            style={{
              ...commonStyles.fontSize12,
              color: colors.blackOpacity40,
            }}>
            ({fmtMSS(data?.duration_in_seconds)} min)
          </Text>
        </View>
        <View style={{flex: 1, paddingLeft: moderateScale(8)}}>
          <View
            style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <Text style={{...commonStyles.fontSize11, color: colors.black}}>
              {data?.activity}
            </Text>
            <Text
              style={{
                ...commonStyles.fontSize16,
                color: colors.black,
                fontFamily: fontFamily.medium,
              }}>
              ${data.price}
            </Text>
          </View>
          <View
            style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <View>
              <Text
                style={{
                  ...commonStyles.fontSize14,
                  color: colors.black,
                  fontFamily: fontFamily.medium,
                }}>
                {data?.name}
              </Text>
              <Text
                style={{
                  ...commonStyles.fontSize11,
                  color: colors.blackOpacity25,
                }}>
                w/ {`${data?.coach?.name}`}
              </Text>
            </View>

            <Text
              style={{
                ...commonStyles.fontSize11,
                color: colors.blackOpacity25,
              }}>
              DROP-IN
            </Text>
          </View>
          <View style={{alignItems: 'flex-end'}}>
            <ButtonWithLoader
              btnStyle={{
                backgroundColor: colors.white,
                marginTop: 0,
                height: undefined,
                paddingVertical: 2,
                paddingHorizontal: 10,
              }}
              onPress={onPress}
              btnTextStyle={{color: colors.themeMain,fontSize:textScale(12)}}
              btnText="View"
            />
          </View>
        </View>
      </TouchableOpacity>
    )
}
