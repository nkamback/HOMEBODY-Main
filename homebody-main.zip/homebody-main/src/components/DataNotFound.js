import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import commonStyles from '../styles/commonStyles';
import { textScale } from '../styles/responsiveSize';
import { fontFamily } from '../styles/fontFamily';
import colors from '../styles/colors';


const DataNotFound = ({ }) => {
    return (

        <View style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center'

        }}>
            <Text style={styles.textStyle}>Data not found</Text>
        </View>

    );
};

const styles = StyleSheet.create({
    textStyle: {
        fontSize: textScale(18),
        fontFamily: fontFamily.SEMI_BOLD_ITALIC,
        color: colors.redColor
    }
});

export default DataNotFound;
