import React from 'react';
import { View, Text, TextInput, StyleSheet, Image, I18nManager, TouchableOpacity } from 'react-native';
import { textScale, moderateScale, moderateScaleVertical } from '../styles/responsiveSize';
import colors from '../styles/colors';
import fontFamily from '../styles/fontFamily';
import commonStyles from '../styles/commonStyles';


const TextInputWithLabel
    = ({
        label,
        value,
        onChangeText,
        placeholder,
        inputStyle,
        rightIcon,
        onPress,
        imageStyle,
        inputImgStyle,
        showHidePassword,
        secureTextEntry,
        isRequired = false,
        containerStyle={},
        ...props

    }) => {
        return (
            <View style={{marginBottom:moderateScaleVertical(16), ...containerStyle}}>
                <Text
                    style={styles.labelTextStyle} >
                    {isRequired ? <Text>{label} <Text style={{ color: colors.redColor }}>* </Text> </Text> : label}</Text>
                {
                    rightIcon ?
                        <View style={{ ...styles.imgInputStyle, ...inputStyle }}>
                            <TextInput
                                style={{ flex: 1 }}
                                placeholder={placeholder}
                                value={value}
                                onChangeText={onChangeText}
                                secureTextEntry={secureTextEntry}
                                {...props}
                            />
                            <TouchableOpacity
                                onPress={showHidePassword}
                                style={{ justifyContent: 'center' }}>
                                <Image source={rightIcon} />
                            </TouchableOpacity>
                        </View>
                        :
                        <TextInput
                            placeholder={placeholder}
                            style={{ ...styles.inputStyle, ...inputStyle }}
                            value={value}
                            secureTextEntry={secureTextEntry}
                            onChangeText={onChangeText}
                            {...props}
                        />
                }
            </View>
        )
    }
const styles = StyleSheet.create({
    inputStyle: {
        backgroundColor: colors.whiteColor,
        borderRadius: 4,
        height: moderateScaleVertical(48),
        borderColor: colors.textInputBorderColor,
        paddingHorizontal: moderateScale(10),
        fontFamily: fontFamily.r,
        fontSize: textScale(16),
        color: colors.blackOpacity90,
        borderWidth: 1

    },
    passwordFieldStyle: {
        flexDirection: 'row',
        alignItems: 'center',
    },

    imgInputStyle: {
        justifyContent: 'center',
        backgroundColor: colors.whiteColor,
        borderRadius: 4,
        height: moderateScaleVertical(48),
        borderColor: colors.textInputBorderColor,
        paddingHorizontal: moderateScale(10),
        fontFamily: fontFamily.regular,
        fontSize: textScale(16),
        color: colors.blackOpacity90,
        flexDirection: 'row',
        borderWidth: 1
    },

    labelTextStyle: {
        fontSize: textScale(14),
        fontFamily: fontFamily.regular,
        color: colors.themeColor,
        marginBottom: moderateScaleVertical(8)
    }

});




export default TextInputWithLabel;