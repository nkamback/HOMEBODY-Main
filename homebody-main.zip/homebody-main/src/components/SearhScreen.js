import React, {useState, useRef, useEffect} from 'react';
import FlashMessage, {showMessage} from 'react-native-flash-message';
import {
  View,
  Text,
  FlatList,
  TextInput,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import moment from 'moment';
import GradientWrapper from './GradientWrapper';
import {moderateScaleVertical, moderateScale} from '../styles/responsiveSize';
import imagePath from '../constants/imagePath';
import commonStyles, {hitSlopProp} from '../styles/commonStyles';
import colors from '../styles/colors';
import actions from '../redux/actions';
import CoachCard from './CoachCard';
import Card from './Card';
import { getSelectedDateTime } from '../utils/helperFunctions';
let firsTime = true;
export default function SearhScreen({
  onClose,
  children,
  isClassActive,
  activeTab,
}) {
  const [state, setState] = useState({
    searchText: '',
    isLoading: false,
    data: [],
  });
  let timeoutRef = useRef();
  const flashRef = useRef();

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    if (!searchText.trim()) {
      return;
    }
    timeoutRef.current = setTimeout(getApiHit, 500);
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [state.searchText]);

  const onChangeText = (searchText) => {
    setState({...state, searchText});
  };

  const getApiHit = () => {
    let query = '';
    if (activeTab == 0) {
      query = `?type=fitness`;
    } else if (activeTab == 1) {
      query = `?type=wellness`;
    } else {
      query = `?type=one_on_one`;
    }
    query = query + `&search_term=${state.searchText}`;
    setState((state) => ({...state, isLoading: true}));
    if (isClassActive) {
      actions
        .getClassesList(query)
        .then((res) => {
          console.log(res, 'the repos');
          setState((state) => ({
            ...state,
            isLoading: false,
            data: res.data?.classes || [],
          }));
        })
        .catch(errorMethod);

      return;
    }
    actions
      .getCoaches(query)
      .then((res) => {
        setState((state) => ({
          ...state,
          isLoading: false,
          data: res.data.coaches,
        }));
      })
      .catch(errorMethod);
  };

  const errorMethod = (error) => {
    setState((state) => ({...state, isLoading: false}));
    if (flashRef.current) {
      flashRef.current.showMessage({
        type: 'danger',
        icon: 'danger',
        message: error.message,
      });
    } else {
      alert(error.message);
    }
  };
  const _renderItem = ({item, index}) => {
    console.log(item);
    console.log(item.timings, 'the iajdsfojojosjaji');
    let startDateTimeForApi;
    if (isClassActive) {
      let timingObj;
      if (item.type === 'recurring') {
        startDateTimeForApi=getSelectedDateTime(item);
      }
      return (
        <View style={{marginHorizontal: moderateScale(16)}}>
          <Card
            data={item}
            shouldBothPress
            onPress={onClose}
            btnFilled={false}
            subText={item.activity}
            hideBtn
            selectedDateUTC={startDateTimeForApi}
            width="100%"
          />
        </View>
      );
    }
    return <CoachCard onPress={onClose} data={item} />;
  };

  const {searchText} = state;


  return (
    <GradientWrapper start={{x:0,y:1}} end={{x:1,y:1}}>
      <View style={{paddingHorizontal: moderateScale(16)}}>
        <View
          style={{
            alignItems: 'flex-end',
            marginVertical: moderateScaleVertical(14),
          }}>
          <TouchableOpacity hitSlop={hitSlopProp} onPress={onClose}>
            <Image source={imagePath.crossWhite} />
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: moderateScaleVertical(23),
          }}>
          <Image
            style={{tintColor: colors.white}}
            source={imagePath.searchWhite}
          />
          <TextInput
            value={searchText}
            onChangeText={onChangeText}
            style={{
              ...commonStyles.fontSize18,
              color: colors.white,
              flex: 1,
              marginLeft: 10,
              borderBottomColor: colors.white,
              borderBottomWidth: 1,
              height: moderateScaleVertical(48),
            }}
          />
          <View
            style={{
              borderBottomColor: colors.white,
              justifyContent: 'center',
              borderBottomWidth: 1,
              height: moderateScaleVertical(48),
            }}>
            <ActivityIndicator
              animating={state.isLoading}
              color={colors.white}
            />
          </View>
        </View>
      </View>
      <View style={{flex: 1, backgroundColor: colors.white}}>
        {/* {!children ? (
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingHorizontal: moderateScale(16),
              marginVertical: moderateScaleVertical(24),
            }}>
            <Text
              style={{
                ...commonStyles.headingText,
                color: colors.blackOpacity40,
              }}>
              RECENT
            </Text>
            <Text style={commonStyles.fontSize14}>Clear all</Text>
          </View>
        ) : (
          {children}
        )} */}
        <FlatList
          data={state.data}
          renderItem={_renderItem}
          keyboardShouldPersistTaps="always"
          ItemSeparatorComponent={() => <View style={{height: 6}} />}
          ListHeaderComponent={() => <View style={{height: 20}} />}
          keyExtractor={(item, index) => String(index)}
          ListFooterComponent={() => <View style={{height: 20}} />}
        />
      </View>
      <FlashMessage ref={flashRef} position="top" />
    </GradientWrapper>
  );
}
