import React from 'react'
import { View, Text,StatusBar } from 'react-native'
import {SafeAreaView,useSafeAreaInsets} from 'react-native-safe-area-context'
import LinearGradient from 'react-native-linear-gradient';
import colors from '../styles/colors';
import Loader from './Loader';
export default function GradientWrapper({isLoading=false,children,start={ x: 1, y: 0 },  end={ x: 1, y: 1 },colorsBg=[colors.gradientB,colors.gradientA]}) {
  const insets=useSafeAreaInsets();
    return (
        <LinearGradient start={start} end={end} style={{flex: 1}} colors={colorsBg}>
              <StatusBar
                backgroundColor={colors.transparent}
                translucent
                barStyle="light-content"
              />
              <View style={{height:insets.top}} />
              <SafeAreaView edges={['right', 'left']} style={{flex:1}}>
                  {children}
              </SafeAreaView>
              <Loader isLoading={isLoading}/>
            </LinearGradient>
    )
}
