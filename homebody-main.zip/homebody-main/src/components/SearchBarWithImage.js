import React from 'react';
import { View, Text, TextInput, StyleSheet, Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import { textScale, moderateScale } from '../styles/responsiveSize';
import { spacing } from '../styles/spacing';
import { fontFamily } from '../styles/fontFamily';
import ImagePath from '../constants/ImagePath';
import colors from '../styles/colors';

export const SearchBarWithImage
    = ({
        placeholder,
        onSearch,
        value,
        searchLoading,

    }) => {
        return (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={styles.searchBoxStyle}>

                    <Image
                        source={ImagePath.searchIcon}
                        style={{ marginRight: spacing.MARGIN_8 }}
                    />
                    <TextInput
                        placeholder={placeholder}
                        value={value}
                        style={styles.textInputStyle}
                        onChangeText={onSearch}
                    />
                    {
                        searchLoading ?
                            <ActivityIndicator size="small" color={colors.themeColor} />
                            : null
                    }
                </View>
                <Image source={ImagePath.searchIcon} />
            </View>
        )
    }
const styles = StyleSheet.create({


    textInputStyle: {
        fontFamily: fontFamily.REGULAR,
        fontSize: textScale(16),
        color: colors.blackOpacity90,
        flex: 1
    },

    searchBoxStyle: {
        flex: 1,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,

        height: spacing.HEIGHT_48,
        borderColor: 'rgba(0,0,0,0.1)',
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        borderRadius: spacing.RADIUS_4,
        backgroundColor: colors.whiteColor,
        marginRight: spacing.MARGIN_12
    }

});




