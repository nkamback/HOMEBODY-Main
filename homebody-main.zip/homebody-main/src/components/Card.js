import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import ProgressiveImage from './ProgressiveImage';
import {exerciseImg} from '../constants/constants';
import {moderateScaleVertical, moderateScale} from '../styles/responsiveSize';
import commonStyles from '../styles/commonStyles';
import fontFamily from '../styles/fontFamily';
import colors from '../styles/colors';
import ButtonWithLoader from './ButtonWithLoader';

const Card = ({
  btnFilled = true,
  btnText = 'Join live',
  hideBtn = false,
  width = moderateScale(264),
  height = moderateScale(152),
  onPress,
  subText = 'w/ Samara Williams',
  startDateText,
  shouldBothPress,
  selectedDateUTC = null,
  data = {},
}) => {
  const navigation = useNavigation();
  console.log(data, 'the data value');

  const cardPress = () => {
    if (shouldBothPress) {
      if (onPress) {
        onPress();
      }
      if (!!data.name) {
        navigation.navigate('classDetails', {data, selectedDateUTC});
      }
    }
    if (onPress) {
      onPress();
      return;
    }
    if (!!data.name) {
      navigation.navigate('classDetails', {data, selectedDateUTC});
    }
  };
  return (
    <TouchableOpacity activeOpacity={0.7} onPress={cardPress} style={{width}}>
      <ProgressiveImage
        source={{uri: data?.image?.thumb_path || exerciseImg}}
        containerStyle={{height, width}}
        style={{height, width}}
      />
      <View
        style={{
          marginTop: moderateScaleVertical(8),
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <View style={{flex: hideBtn ? 1 : 0.6}}>
          <Text
            numberOfLines={1}
            style={{
              ...commonStyles.fontSize14,
              fontFamily: fontFamily.medium,
              color: colors.black,
            }}>
            {data.name}
          </Text>
          <Text style={{...commonStyles.fontSize14, color: colors.textGrey}}>
            {subText}
          </Text>
          {!!startDateText && (
            <Text style={{...commonStyles.fontSize14, color: colors.textGrey}}>
              {startDateText}
            </Text>
          )}
        </View>

        {!hideBtn && (
          <View style={{flex: 0.3}}>
            <ButtonWithLoader
              btnStyle={{
                marginTop: 0,
                height: undefined,
                paddingVertical: 1.5,
                backgroundColor: btnFilled ? colors.themeMain : colors.white,
              }}
              btnTextStyle={btnFilled ? {} : {color: colors.themeMain}}
              btnText={btnText}
              onPress={cardPress}
            />
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

export default Card;
