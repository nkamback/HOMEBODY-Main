import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import ProgressiveImage from './ProgressiveImage';
import {exerciseImg} from '../constants/constants';
import {moderateScaleVertical, moderateScale} from '../styles/responsiveSize';
import commonStyles from '../styles/commonStyles';
import fontFamily from '../styles/fontFamily';
import colors from '../styles/colors';
import ButtonWithLoader from './ButtonWithLoader';

const CirularImageWithLabel = ({
  btnFilled = true,
  img,
  label = 'Join live',
  onPress = () => {},
}) => {
  return (
    <TouchableOpacity onPress={onPress} style={{alignSelf: 'flex-start'}}>
      <ProgressiveImage
        source={{uri: img||exerciseImg}}
        isCircular
        containerStyle={{height: moderateScale(72), width: moderateScale(72)}}
        style={{height: moderateScale(72), width: moderateScale(72)}}
      />

      <Text
        style={{
          ...commonStyles.fontSize14,
          color: colors.textGrey,
          textAlign: 'center',
        }}>
        {label}
      </Text>
    </TouchableOpacity>
  );
};

export default CirularImageWithLabel;
