import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  BackHandler,
} from 'react-native';
import {exerciseImg} from '../constants/constants';
import moment from 'moment';
import colors from '../styles/colors';
import commonStyles from '../styles/commonStyles';
import {moderateScale, moderateScaleVertical} from '../styles/responsiveSize';
import GradientWrapper from './GradientWrapper';
import HeaderWithCenterTextBack from './HeaderWithCenterTextBack';
import ListItemHorizontal from './ListItemHorizontal';
import WrapperContainer from './WrapperContainer';
import VideoPlayer from './VideoPlayer';
import { fmtMSS } from '../utils/helperFunctions';

export default function WaitingRoom(props) {
  const [playVideo, tooglePlayVideo] = useState(false);
  const backHandler = useCallback(() => {
    if (playVideo) {
      tooglePlayVideo(false);
      return true;
    }
  }, [playVideo]);
  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', backHandler);
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', backHandler);
    };
  }, [playVideo]);
  const onPressStartVideo = () => {
    tooglePlayVideo(true);
  };

  const onPressCloseVideo = () => {
    tooglePlayVideo(false);
  };
  const {data = {}} = props;
  
  if (playVideo) {
    return <VideoPlayer url={data?.coach?.video} onPress={onPressCloseVideo} />;
  }
let dateTimeObj=null;
    if(data.start_date){
    var stillUtc = moment(
      `${data?.start_date} ${data.start_time}`,
      'YYYY-MM-DD hh:mm A',
    ).format('YYYY-MM-DD HH:mm:ss');
    dateTimeObj = moment.utc(stillUtc).toDate();
    }
    // alert(stillUtc)
  return (
    <GradientWrapper start={{ x: 0, y: 1 }} end={{ x: 1, y: 1 }}>
      <HeaderWithCenterTextBack centerText="My Waiting Room" />
      <ScrollView style={{flex: 1, backgroundColor: colors.white}}>
        <Text
          style={{
            ...commonStyles.fontSize16,
            color: colors.blackOpacity40,
            textAlign: 'center',
            paddingHorizontal: moderateScale(50),
            lineHeight: 21,
            marginTop: moderateScaleVertical(32),
            marginBottom: moderateScaleVertical(24),
          }}>
          Please wait, the meeting host will let you in soon…
        </Text>
        <Text
            numberOfLines={1}
            style={{
              marginTop:16,
              marginBottom:5,
              ...commonStyles.fontSize18,
              marginHorizontal:moderateScale(16),
              color: colors.black,
            }}>
            {data.name}
          </Text>
        <TouchableOpacity
          onPress={onPressStartVideo}
          style={{marginHorizontal: moderateScale(16)}}>
          <ImageBackground
            source={{uri: data?.image?.thumb_path || exerciseImg}}
            imageStyle={{borderRadius: 5}}
            style={{
              width: '100%',
              height: moderateScaleVertical(240),
              backgroundColor: colors.black,
              borderRadius: 5,
              justifyContent: 'flex-end',
            }}>
            <View style={{alignItems: 'flex-end', marginBottom: 10}}>
              <View
                style={{
                  marginRight: moderateScale(16),
                }}>
                <Text style={commonStyles.badgeWhite}>{fmtMSS(data.duration_in_seconds||0)} min</Text>
              </View>
            </View>
          </ImageBackground>
        </TouchableOpacity>
        <View style={{marginHorizontal: moderateScale(16), marginTop: 20}}>
          <ListItemHorizontal
            label="Date & Time:"
            value={`${moment(dateTimeObj).format(
              'DD MMM, hh:mm A',
            )}`}
          />
          <ListItemHorizontal
            label="Instructor:"
            value={data?.coach?.name || ''}
          />
          <ListItemHorizontal label="Activity:" value={data?.coach?.name} />

          <ListItemHorizontal
            label="Equipment Needed:"
            value={!!data?.equipment_needed ? data?.equipment_needed : 'No'}
          />
          <ListItemHorizontal label="Body Focus:" value={data?.body_focus} />
        </View>
      </ScrollView>
    </GradientWrapper>
  );
}
