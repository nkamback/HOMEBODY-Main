import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import commonStyles from '../styles/commonStyles';
import {moderateScale, moderateScaleVertical} from '../styles/responsiveSize';
import fontFamily from '../styles/fontFamily';
import colors from '../styles/colors';
import GradientButton from './GradientButton';

function ClassCoachView({isClassActive, updateClassesView = () => {}}) {
  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: moderateScale(20),
        paddingHorizontal: moderateScale(16),
        marginBottom: moderateScaleVertical(24),
      }}>
      <GradientButton
        onPress={updateClassesView(true)}
        btnText="CLASSES"
        colorsArray={
          isClassActive
            ? [colors.scheduleBlue, colors.blueMain]
            : [colors.white, colors.white]
        }
        containerStyle={
          isClassActive
            ? {width: '45%'}
            : {
                width: '45%',
                borderColor: colors.blackOpacity40,
                borderWidth: 1,
                backgroundColor: colors.white,
                borderRadius: 4,
              }
        }
        borderRadius={4}
        textStyle={{
          fontSize: 12,
          fontFamily: fontFamily.bold,
          color: isClassActive ? colors.white : colors.textGrey,
        }}
      />
      <GradientButton
        onPress={updateClassesView(false)}
        btnText="Instructor"
        colorsArray={
          !isClassActive
            ? [colors.scheduleBlue, colors.blueMain]
            : [colors.white, colors.white]
        }
        containerStyle={
          !isClassActive
            ? {width: '45%'}
            : {
                width: '45%',
                borderColor: colors.blackOpacity40,
                borderWidth: 1,
                backgroundColor: colors.white,
                borderRadius: 4,
              }
        }
        borderRadius={4}
        textStyle={{
          fontSize: 12,
          fontFamily: fontFamily.bold,
          textTransform:"uppercase",
          color: !isClassActive ? colors.white : colors.textGrey,
        }}
      />
    </View>
  );
}

export default ClassCoachView;
