import React from 'react';
import {View, Text, TouchableOpacity, Image, TextInput} from 'react-native';
import imagePath from '../constants/imagePath';
import colors from '../styles/colors';
import {moderateScale} from '../styles/responsiveSize';
import commonStyles from '../styles/commonStyles';

export default function SearchBox({onPress,containerStyle,placeholder="Search for anything"}) {
  return (
    <TouchableOpacity
        onPress={onPress}
      style={{
        backgroundColor: colors.white,
        height: moderateScale(48),
        alignItems: 'center',
        paddingHorizontal:moderateScale(10),
        borderRadius:4,
        flexDirection: 'row',
        ...containerStyle
      }}>
      <Image source={imagePath.search} />
      <Text style={{...commonStyles.fontSize14, color: colors.blackOpacity40,marginLeft:10}}>
        {placeholder}
      </Text>
    </TouchableOpacity>
  );
}
