import React, { Component } from 'react';
import { StyleSheet, Text, View, FlatList, Image } from 'react-native';
import { spacing } from '../styles/spacing';
import { textScale, moderateScale } from '../styles/responsiveSize';

import OverflowableView from 'react-native-view-overflow';
import { fontFamily } from '../styles/fontFamily';
import ImagePath from '../constants/ImagePath';
import colors from '../styles/colors';

export default class MemberImages extends Component {
    _imageSlider = ({ item, index }) => {
        if (index < 4) {
            // console.log(item,"asjfoijoijo the itemv image slider falue")
            return (
                <View>
                    {index < 3 ? (
                        !!item.image && (
                            <View>
                                <View style={{ zIndex: 0 }}>
                                    <Image
                                        style={[
                                            styles.membersImage,
                                            { marginLeft: index == 0 ? moderateScale(10) : moderateScale(-15) },
                                        ]}
                                        source={{ uri: item.image }}
                                    />
                                </View>
                                <View style={styles.membersImageStyle}>
                                    <Image
                                        style={[
                                            styles.membersImage,
                                            { marginLeft: index == 0 ? moderateScale(10) : moderateScale(-15) },
                                        ]}
                                        source={
                                            !!item.image === null
                                                ? ImagePath.profilePic
                                                : { uri: item.image }
                                        }
                                    />
                                </View>
                            </View>
                        )
                    ) : (
                            <View
                                style={[
                                    styles.extramembersImage,
                                    { marginLeft: index == 0 ? 0 : moderateScale(-15) },
                                ]}>
                                {!!item.image && (
                                    <Image
                                        source={{ uri: item.image }}
                                        style={[styles.membersImage, { opacity: 1 }]}
                                        blurRadius={3}
                                    />
                                )}
                                <Text
                                    style={{
                                        fontSize: textScale(14),
                                        color: colors.whiteColor,
                                        fontFamily: fontFamily.BOLD,
                                        position: 'absolute',
                                    }}>
                                    +{this.props.membersImageData.length - 3 + 1}
                                </Text>
                            </View>
                        )}
                </View>
            );
        }
    };

    render() {
        const { mainStyle } = this.props;
        return (
            <View style={[styles.container, mainStyle]}>
                <FlatList
                    horizontal={true}
                    bounces={false}
                    keyboardShouldPersistTaps="always"
                    data={this.props.membersImageData}
                    keyExtractor={(item, index) => String(index)}
                    renderItem={this._imageSlider}
                    removeClippedSubviews={true}
                    CellRendererComponent={({ children, index, style, ...props }) => {
                        const cellStyle = [
                            style,

                            { zIndex: this.props.membersImageData.length + index },
                        ];

                        return (
                            <OverflowableView style={[cellStyle]} index={index} {...props}>
                                {children}
                            </OverflowableView>
                        );
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    membersImage: {
        height: moderateScale(38),
        width: moderateScale(38),
        borderRadius: spacing.RADIUS_20,
        borderWidth: spacing.WIDTH_2,
        borderColor: 'white',
    },
    membersImagePoll: {
        height: spacing.HEIGHT_34,
        width: moderateScale(34),
        borderRadius: spacing.RADIUS_16,
        borderWidth: spacing.WIDTH_2,
        borderColor: 'white',
    },
    membersImageStyle: {
        zIndex: 1,
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        position: 'absolute',
    },
    // imageTintStyle: {
    //     // tintColor: '#FFF',
    //      height: 10, width: 10
    // },
    extramembersImage: {
        height: moderateScale(40),
        width: moderateScale(40),
        borderRadius: spacing.RADIUS_24,
        flexDirection: 'row',
        borderWidth: spacing.WIDTH_2,
        borderColor: 'white',
        backgroundColor: colors.themeColor,
        justifyContent: 'center',
        alignItems: 'center',
    },
    extramembersImagePoll: {
        height: spacing.HEIGHT_34,
        width: spacing.WIDTH_34,
        borderRadius: spacing.RADIUS_16,
        flexDirection: 'row',
        borderWidth: spacing.WIDTH_2,
        borderColor: 'white',
        backgroundColor: colors.themeColor,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
