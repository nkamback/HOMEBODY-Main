import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import imagePath from '../constants/imagePath';
import types from '../redux/types';
import actions from '../redux/actions';
import {hitSlopProp} from '../styles/commonStyles';
import colors from '../styles/colors';

export default function ToogleFavCoach({data = {},marginTop=0,isLarge=false}) {
  const likesObj = useSelector((state) => state.coaches.likesObj);
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();

  const onPress = () => {
    if (isLoading) {
      return;
    }
    dispatch({
      type: types.TOGGLE_LIKE_UNLIKE,
      payload: {
        ...likesObj,
        [`${data.id}`]:
          likesObj[`${data.id}`] !== undefined
            ? !likesObj[`${data.id}`]
            : !data.added_to_favourites,
      },
    });
    setIsLoading(true);
    actions
      .setUnsetFavCoach({coach_id: data.id})
      .then((res) => {
        console.log(res);
        setIsLoading(false);
      })
      .catch((error) => {
        setIsLoading(false);
        dispatch({
          type: types.TOGGLE_LIKE_UNLIKE,
          payload: {...likesObj, [`${data.id}`]: !likesObj[`${data.id}`]},
        });
      });
  };

  console.log(likesObj, 'the likes obje');
  const imgEndText=isLarge?"Large":"Small"

  return (
    <TouchableOpacity
      activeOpacity={0.7}
    
      style={{marginTop}}
      hitSlop={hitSlopProp}
      onPress={onPress}>
      <Image
        style={{tintColor:(
          likesObj[`${data.id}`] !== undefined
            ? likesObj[`${data.id}`]
            : data.added_to_favourites
        )?colors.blueMain:colors.textGrey}}
        source={
          (
            likesObj[`${data.id}`] !== undefined
              ? likesObj[`${data.id}`]
              : data.added_to_favourites
          )
            ? imagePath[`like${imgEndText}`]
            : imagePath[`unlike${imgEndText}`]
        }
      />
    </TouchableOpacity>
  );
}
