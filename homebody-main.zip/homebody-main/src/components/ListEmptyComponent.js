import React, {Component} from 'react';
import {Text, View,StyleSheet,Image} from 'react-native';
import commonStyles from '../styles/commonStyles';
import colors from '../styles/colors';
import imagePath from '../constants/imagePath';

const ListEmptyComponent = ({empytText = 'No data found',isCenter=true,isLoading=false,txtStyle={},withEmogi=false}) => {
  if(isLoading){
    return (<View />)
  }
    
  return (
    <View style={{justifyContent:isCenter?'center':'flex-start',alignItems:isCenter?'center':'flex-start',width:"100%",flex:1}}>
       {withEmogi&& <Image style={{marginBottom:5}} source={imagePath.noData} />}
      <Text
        style={{
          ...commonStyles.fontBold16,
          color: colors.blackOpacity35,
          textAlign: isCenter?'center':'left',
          ...txtStyle
        }}>
        {empytText}
      </Text>
    </View>
  );
};

export default ListEmptyComponent;


const styles=StyleSheet.create({
})
