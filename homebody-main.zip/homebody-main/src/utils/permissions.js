import { Platform,PermissionsAndroid } from "react-native";

export  async function requestCameraAndAudioPermission() {
    return new Promise(async(resolve,reject)=>{
        if(Platform.OS=="ios"){
            resolve(true);
            return;
        }
    
    try {
        const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.CAMERA,
            PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        ])
        if (
            granted['android.permission.RECORD_AUDIO'] === PermissionsAndroid.RESULTS.GRANTED
            && granted['android.permission.CAMERA'] === PermissionsAndroid.RESULTS.GRANTED
        ) {
            resolve(true)
        } else {
            resolve(false);
        }
    } catch (err) {
        resolve(false)
    }
})
}


export const androidCameraPermission = () => new Promise(async (resolve, reject) => {
	try {
		if (Platform.OS === 'android' && Platform.Version > 22) {
			const granted = await PermissionsAndroid.requestMultiple([
				PermissionsAndroid.PERMISSIONS.CAMERA,
				PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
				PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE
			]);

			if (
				granted['android.permission.CAMERA'] !== 'granted' ||
				granted['android.permission.WRITE_EXTERNAL_STORAGE'] !== 'granted' ||
				granted['android.permission.READ_EXTERNAL_STORAGE'] !== 'granted'
			) {
				Alert.alert(
					strings.ALERT,
					strings.DO_NOT_HAVE_PERMISSIONS_TO_SELECT_IMAGE,
					[
						{ text: strings.OKAY },
					],
					{ cancelable: true }
				);
				return resolve(false);
				// alert(strings.DO_NOT_HAVE_PERMISSIONS_TO_SELECT_IMAGE);
			}
			return resolve(true);
		}

		return resolve(true);
	} catch (error) {
		return resolve(false);
	}
});