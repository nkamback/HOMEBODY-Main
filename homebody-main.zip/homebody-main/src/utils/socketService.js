import io from 'socket.io-client';

// import logger from './logger';
import {SOCKET_URL} from '../config/urls';

class WSService {
  initializeSocket = (userToken) => {
    try {
      console.log('initializing socket');

      if (!userToken) {
        console.log('Skipping socket initialization.', 'userToken not found');
        return;
      }

      this.socket = io(SOCKET_URL, {
        transports: ['websocket'],
        query: {
          token: userToken,
        },
        reconnection: true,
        reconnectionDelay: 500,
        reconnectionAttempts: Infinity,
        transports: ['websocket'],
      });

      this.socket.on('connect', (data) => {
        
        console.log('===== socket connected =====');
        
        this.socket.emit("authentication",{token:`Bearer ${userToken}`},(data)=>{
          console.log('sockeddata',data);
          alert(JSON.stringify(data));
        });
        console.log(data,"Asdf");
      });

      this.socket.on('disconnect', () => {
        
        console.log('socket disconnected');
      });

      this.socket.on('socketError', (err) => {});
      this.socket.on('parameterError', () => {
        console.log('socket connection error: ', err);
      });
      // this.socket.on('startClass',()=>{
      //   alert('madjoijj')
      // })

      this.socket.on('error', (error) => {
        console.log(error, 'thea data');
      });
      this.socket.on('connect_error', (err) => {
        alert('connecton errror');
        // console.log('socket connection error: ', err);
        // logger.data('socket connection error: ', err);
      });
      // this.socket('reconnect_attempt', () => {
      //   alert('shohs');
      // });

      this.socket.on('reconnect_attempt', () => {
        // alert('ahsodh')
          // console.log('reconnecting');
          // socket.io.opts.transports = ['polling', 'websocket'];
      });

      this.socket.on('connection-Response', (data) => {
        alert('bingo mad');
        console.log('data received from server is: ', data);
      });
    } catch (error) {
      // logger.error('initialize token error: ', error);
      console.log(error, 'hter tereo');
    }
  };

  emit(event, data = {},cb) {
    // logger.log('event to be emitted is: ', event);
    // logger.data('data to be emitted is: ', data);
    this.socket.emit(event, data,(data)=>{

      alert(JSON.stringify(data))
      console.log(data,'hte emit data');
      
    });
  }

  on(event, cb) {
    this.socket.on(event, cb);
  }

  sendChatMessage(
    event,
    chatId,
    text,
    userId,
    receiverId,
    type,
    mediaName,
    tempId,
  ) {
    console.log(
      'emitting message: ',
      event,
      chatId,
      text,
      userId,
      receiverId,
      type,
      mediaName,
      tempId,
    );
    this.socket.emit(
      event,
      chatId,
      text,
      userId,
      receiverId,
      type,
      mediaName,
      tempId,
    );
  }

  isUserTyping(event, userID, chatID) {
    this.socket.emit(event, userID, chatID);
  }

  viewChat(event, userID, chatID) {
    console.log('view chat data is: ', event, userID, chatID);
    this.socket.emit(event, userID, chatID);
  }

  removeListener(listenerName) {
    this.socket.removeListener(listenerName);
  }
}

const socketServices = new WSService();

export default socketServices;
