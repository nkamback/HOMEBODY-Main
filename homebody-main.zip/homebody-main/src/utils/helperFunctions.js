import {showMessage} from 'react-native-flash-message';
import moment from 'moment';
const showError = (message) => {
  showMessage({
    type: 'danger',
    icon: 'danger',
    message,
  });
};

const showSuccess = (message) => {
  showMessage({
    type: 'success',
    icon: 'success',
    message,
  });
};

export function getMinimalisticRelativeTime(dateTime) {
  if (!dateTime) {
    return null;
  }

  const today = moment();

  const time = moment(dateTime);

  const diff = today.diff(time);

  const duration = moment.duration(diff);
  if (duration.years() > 0) {
    return duration.years() + 'y';
  } else if (duration.weeks() > 0) {
    return duration.weeks() + 'w';
  } else if (duration.days() > 0) {
    return duration.days() + 'd';
  } else if (duration.hours() > 0) {
    return duration.hours() + 'h';
  } else if (duration.minutes() > 0) {
    return duration.minutes() + 'm';
  } else if (duration.minutes() < 1) {
    return '1s';
  }
}

export function fmtMSS(s) {
  return (s - (s %= 60)) / 60 + (9 < s ? ':' : ':0') + s;
}

export function otpTimerCounter(seconds) {
  // alert(seconds)
  let m = Math.floor(seconds / 60);
  let s = seconds % 60;
  m = m < 10 ? '0' + m : m;
  s = s < 10 ? '0' + s : s;
  return `${m}:${s}`;
}

export const getNextDates = (count) => {
  const datesArray = [];

  for (let day = 0; day < count; day++) {
    const nextDate = moment().add(day, 'd');
    const dateObj = {
      apiDate: nextDate.format('DD-MM-YYYY'),
      dayText: nextDate.format('dd').substr(0, 1),
      dayMonthText: nextDate.format('DD MMM'),
      obj: nextDate,
    };

    datesArray.push(dateObj);
  }
  return datesArray;
};

export const checkDataIfFuture = (momentDateObj) => {
  const momentDateToCheck = momentDateObj;
  const currentDate = moment();
  if (currentDate.isAfter(momentDateToCheck)) {
    return 'futureDay';
  } else if (currentDate.isSame(momentDateToCheck)) {
    return 'today';
  } else {
    return 'beforeDay';
  }
};

export const checkCurrentDateDiffFromMinMaxTime = (
  momentDateObj,
  minTime = 10,
  maxTime = 100,
) => {
  const timeDiff = moment().diff(momentDateObj, 'minutes');
  console.log(timeDiff);
  if (timeDiff >= -minTime && timeDiff < maxTime) {
    return 'start';
  } else if (timeDiff < -minTime) {
    return 'yetToStart';
  } else {
    return 'over';
  }
};

//PARTICULARLY FOR THIS RECURRING CLASS SCENARIO
export const getSelectedDateTime = (classData) => {
  //PARTICULARLY FOR THIS RECURRING CLASS SCENARIO
  if (!classData.type == 'recurring') {
    return;
  }
  let timingObj, startDateTimeForApi;
  //THE DATE COMING FROM API IS UTC SO FIRST NEED TO BE CONVERTED TO UTC
  var utcToLocal = moment(`${classData.start_time}`, 'hh:mm A').format(
    'YYYY-MM-DD HH:mm:ss',
  );
  var utcToLocalTimeObj = moment.utc(utcToLocal).toDate();
  classData.timings?.days?.some((element) => {
    //NEXT DATE AND CLASS'S LOCAL TIME IS COMBINED SO THAT FOR SAME DAY
    // (IF ELEMENT DAY IS TUESDAY AND CURRENT DAY IS ALSO TUESDAY) THEN IT SHOULD ONLY SHOW THE SLOT IF TIME OF CLASS IS IN FUTUR
    let elementDate = moment(
      `${element.day} ${moment(utcToLocalTimeObj).format('HH:mm')}`,
      'ddd HH:mm',
    );
    let diffFromToday = elementDate.diff(moment());
    // console.log(element.day, 'the dya');
    // console.log(diffFromToday);
    if (diffFromToday >= 0) {
      timingObj = elementDate;
      return true;
    }
  });
  //LOCAL DATE BASED ON DAY AND LOCALLY CONVERTED TIMES IS COMBINED TO SHOW THE NEXT BOOKING DATE TIME
  // AND TO SEND TO API CONVERTED TO UTC
  startDateTimeForApi =
    !!timingObj &&
    moment(
      `${timingObj.format('DD-MM-YYYY')} ${moment(utcToLocalTimeObj).format(
        'HH:mm',
      )}`,
      'DD-MM-YYYY HH:mm',
    ).utc();
  return startDateTimeForApi;
};

export {showError, showSuccess};
