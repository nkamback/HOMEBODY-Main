export const API_BASE_URL = "https://dev.homebodylivefitness.com/api";
export const SOCKET_URL="https://devsockets.homebodylivefitness.com/";

export const getApiUrl = (endpoint) => API_BASE_URL + endpoint;


export const SIGNUP_API = getApiUrl("/register");
export const VERIFY_OTP = getApiUrl("/verify-user-by-otp");
export const LOGIN_API = getApiUrl("/login");
export const GET_COACHES = getApiUrl("/coaches");
export const SOCAIL_LOGIN=getApiUrl("/login/social");
export const HOME_API = getApiUrl("/home");
export const FAVORITE_COACHES_LIST= getApiUrl("/favorites/coaches");
export const CLASS_DETAILS=getApiUrl("/classes");
export const BOOKING_DETAILS=getApiUrl("/bookings/details");
export const BOOK_CLASS=getApiUrl("/bookings");
export const CLASSES_LIST=getApiUrl("/classes");
export const SET_UNSET_FAV_COACH=getApiUrl("/favorites/coaches");
export const STREAM_JOIN=getApiUrl("/stream/join");
export const SAVE_CARD=getApiUrl("/payments/cards");
export const FORGOT_PASSWORD=getApiUrl("/forgot-password");
export const GET_NOTIFICATIONS=getApiUrl("/notifications");
export const CHANGE_PASSWORD=getApiUrl("/profile/change-password");
export const CONTACT_US=getApiUrl("/contact-us");
export const UPDATE_PROFILE=getApiUrl("/profile/update");
export const UPLOAD_IMAGE=getApiUrl("/upload/image");
export const RATINGS=getApiUrl("/ratings");
export const COACH_SCHEDULE=getApiUrl("/coaches/classes");
export const UPCOMING_CLASSES=getApiUrl("/upcoming_classes");
export const TRANSACTIONS_LIST=getApiUrl("/transactions");
export const UPDATE_API_TOKEN=getApiUrl("/user/token/update")
export const LOGOUT=getApiUrl("/logout")