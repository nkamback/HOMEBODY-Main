import React, {Component} from 'react';
import {Text, View} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import {Provider} from 'react-redux';
import messaging from '@react-native-firebase/messaging';
import Orientation from 'react-native-orientation';
import FlashMessage from 'react-native-flash-message';
import {SafeAreaProvider,useSafeAreaInsets} from 'react-native-safe-area-context';
import Routes from './src/navigation/Routes';
import store from './src/redux/store';
import {getUserData,getToken} from './src/utils/utils';
import types from './src/redux/types';
import AsyncStorage from '@react-native-community/async-storage';

const FlashMessageComponent=()=>{
  const insets=useSafeAreaInsets();
  return(
    <FlashMessage style={{marginTop:insets.top||24}} position={'top'} />
  )
}

export default class App extends Component {
  async componentDidMount() {
    this.requestUserPermission();
    const {dispatch} = store;
    const isUserExist= await AsyncStorage.getItem("isUserExist");
    if(isUserExist=="Yes"){
      dispatch({
        type:types.IS_USER_EXIST
      })
    }
    const userData = await getUserData();
    if (userData) {

      dispatch({
        type: types.LOGIN,
        payload: userData,
      });
    }
    setTimeout(()=>{
      SplashScreen.hide();
    },500)
    
    Orientation.lockToPortrait();
  }
  requestUserPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      getToken();
    }
  };
  render() {
    
    return (
      <SafeAreaProvider>
        <Provider store={store}>
          <Routes />
        </Provider>
        <FlashMessageComponent />
      </SafeAreaProvider>
    );
  }
}


